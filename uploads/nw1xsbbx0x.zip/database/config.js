module.exports = {
  tokens: "8334156143:AAHoiBT0-kEKgluzPjr7OP0IPeFIxNxAOPY",  // Masukin Bot token kamu
  owners: "8226268341", // Masukin ID Telegram kamu
  port: "2114", // Masukin Port panel kamu 
  ipvps: "https://panel.privatte.my.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};