
import 'package:flutter/material.dart';

void main() {
  runApp(const TopUpMLApp());
}

class TopUpMLApp extends StatelessWidget {
  const TopUpMLApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Top Up Mobile Legends',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Top Up Mobile Legends')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const TextField(decoration: InputDecoration(labelText: 'User ID')),
            const TextField(decoration: InputDecoration(labelText: 'Server ID')),
            const SizedBox(height: 20),
            const Text('Pilih Diamond:'),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              children: const [
                Chip(label: Text('70 💎 - Rp10.000')),
                Chip(label: Text('140 💎 - Rp20.000')),
                Chip(label: Text('210 💎 - Rp30.000')),
              ],
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: null,
                child: const Text('Bayar (Demo)'),
              ),
            )
          ],
        ),
      ),
    );
  }
}
