export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { username, email, ram } = req.body;

    // Buat password random
    const password = Math.random().toString(36).slice(-8);

    // 1. Buat User di Pterodactyl
    const userResponse = await fetch(`${process.env.PANEL_URL}/api/application/users`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.API_KEY}`,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        username: username.toLowerCase(),
        email,
        first_name: username,
        last_name: "Reseller",
        password
      })
    });

    const userData = await userResponse.json();
    if (!userData.attributes) {
      return res.status(400).json({ error: "Gagal membuat user", details: userData });
    }

    const userId = userData.attributes.id;

    // 2. Buat Server di Pterodactyl
    const serverResponse = await fetch(`${process.env.PANEL_URL}/api/application/servers`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.API_KEY}`,
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        name: `${username}-server`,
        user: userId,
        nest: parseInt(process.env.NEST_ID),
        egg: parseInt(process.env.EGG_ID),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: "npm start",
        environment: {},
        limits: {
          memory: parseInt(ram),
          swap: 0,
          disk: 0,
          io: 500,
          cpu: 0
        },
        feature_limits: {
          databases: 1,
          backups: 1
        },
        allocation: {
          default: parseInt(process.env.ALLOC_ID)
        }
      })
    });

    const serverData = await serverResponse.json();
    if (!serverData.attributes) {
      return res.status(400).json({ error: "Gagal membuat server", details: serverData });
    }

    return res.status(200).json({
      message: "User & Server berhasil dibuat!",
      user: userData.attributes,
      server: serverData.attributes,
      password
    });

  } catch (err) {
    return res.status(500).json({ error: "Terjadi kesalahan", details: err.message });
  }
}