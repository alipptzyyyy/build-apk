module.exports = {
  BOT_TOKEN: "TOKEN_BOT",
  OWNER_ID: ["ID_TELE"],
};

/*/━━━━━━━━━━━━━━━━━━━━━━  
 O S C A R - I N V I C T U S
━━━━━━━━━━━━━━━━━━━━━━  

🚀 Developer  : @VallOffcial
📢 Info       : @OscarInvictus
🛠️ Version    : 3.1 Vip!!

⚠️ **警告!** ⚠️  
📌 此机器人使用数据库。  
📌 如果您的令牌 **未在数据库中注册**，  
📌 机器人将 **无法运行**！  
📌 请确保您的令牌已注册后再使用本机器人。  

⚠️ **PERINGATAN!** ⚠️  
📌 Bot ini menggunakan database.  
📌 Jika token Anda **tidak terdaftar di database**,  
📌 bot **tidak akan berjalan**!  
📌 Pastikan token Anda sudah terdaftar sebelum menggunakan bot ini.  

━━━━━━━━━━━━━━━━━━━━━━/*/