module.exports = {
  BOT_TOKEN: "TOKET_MAKLO_DECK",
  OWNER_ID: ["8244638110"],
};