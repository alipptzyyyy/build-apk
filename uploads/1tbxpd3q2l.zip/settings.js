// untuk mengaktifkan access bot nya
// password : KingGanteng
// biar apa? biar bisa jalan botnya

const settings = {
  token: '8324623630:AAHNOKNDxV_H_ums59VWjTGtbzQIMNEKqrw', // token dari @BotFather
  apikey: 'ptlc_6eZQXSHYvee1qGh6gO0HB2yyuWOkrSTxwdhCcvHFWoS', // ini gausa di isi, diabaikan saja
  vercelToken: '9c0laRcYJhT7wW6OHWvigJwk', // token vercel
  ownerId: 7723806969, // user id
  dev: '@yanzkacung', // wajib username tele lu tanpa tanda "@"
  dana: '083162158782', // nomer dana
  namaDana: 'yanzz', // nama
  chUsn: 'https://t.me/GB_PUBLIIKK', // ch tele
  exPGroupid: -1003797854572, // id group
  exGroupId: -1003581553668, // id group
  
//============= SETTINGS VPS ===============\\
  vpsPublic: "", // ip vps
  pwPublic: "", // pw vps
  vpsPrivate: "", // ip vps
  pwPrivate: "", // pw vps

//============= SETTINGS APIKEY DO ===============\\
  apiDigitalOcean: "APIKEY_DO", // apikey do
  apiDigitalOcean2: "APIKEY_DO2", // apikey do 2
  apiDigitalOcean3: "APIKEY_DO3", // apikey do 3
  
//============= SETTINGS FOTO ===============\\
  pp: 'https://files.catbox.moe/nl0pwr.jpg', // file catbox foto
  ppVid: 'https://files.catbox.moe/2zdg8d.mp4', // file catbox video
  panel: 'https://files.catbox.moe/a7ljii.jpeg', // foto panel
  qris: 'https://files.catbox.moe/vfw5fr.jpg', // qris
  
//============= SETTINGS CPANEL V1 ===============\\
  domain: '', // https://pii.piinotdev.my.id
  plta: '', // ptla_KDXM5fDwEnZSr4qYjeaajfZ1Shsggn43jRhy8I7jNvI
  pltc: '', // ptlc_6eZQXSHYvee1qGh6gO0HB2yyuWOkrSTxwdhCcvHFWoS
  
//============= SETTINGS CPANEL V2 ===============\\
    // PANEL SERVER 2
  domainV2: 'ISI_LINK_DOMAIN', // domain v2
  pltaV2: 'ISI_TOKEN_PLTA', // plta v2
  pltcV2: 'ISI_TOKEN_PLTC', // ptlc v2

//============= SETTINGS CPANEL V3 ===============\\
    // PANEL SERVER 3
  domainV3: 'ISI_LINK_DOMAIN', // domain v3 
  pltaV3: 'ISI_TOKEN_PLTA', // ptla v3
  pltcV3: 'ISI_TOKEN_PLTC', // ptlc v3
  
//============= SETTINGS CPANEL V4 ===============\\
    // PANEL SERVER 4
  domainV4: 'ISI_LINK_DOMAIN', // domain v4
  pltaV4: 'ISI_TOKEN_PLTA', // ptla v4
  pltcV4: 'ISI_TOKEN_PLTC', // ptlc v4

//============= SETTINGS CPANEL V5 ===============\\
    // PANEL SERVER 5
  domainV5: 'ISI_LINK_DOMAININ', // domain v5
  pltaV5: 'ISI_TOKEN_PLTA', // ptla v5
  pltcV5: 'ISI_TOKEN_PLTC', // ptlc v5
  
//============= SETTINGS LAINNYA ===============\\
  PATH: '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',
  RAW: 'https://raw.githubusercontent.com/liaacans/MyDatabase/refs/heads/main/DB.json',
  API: 'https://api.github.com/repos/liaacans/MyDatabase/contents/DB.json',
  loc: '1',
  eggs: '15',
};

module.exports = settings;