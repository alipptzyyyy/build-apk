module.exports = {
  tokens: "8283173179:AAGwP1PYJFoGrGk9Zuk5DqvkRZUDZqE7Mbs",  // Masukin Bot token kamu
  owners: "8270020269", // Masukin ID Telegram kamu
  port: "3508", // Masukin Port panel kamu 
  ipvps: "shin-kacung.panel-prvt.web.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1995-1996 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/