module.exports = {
  tokens: "8111927403:AAGUg_SY5RN65-BJOPGWEbjr6YPTXtmxhP4",  // Ubah Jadi Token Bot Mu !!!
  owner: "7216344886", // Ubah Jadi Id Mu !!!
  port: "3056", // Ubah Jadi Port Panel Mu !!!
  ipvps: "http://kanayaazprivate.badol-official.my.id" // Ubah Jadi Ip Vps Mu !!!
};