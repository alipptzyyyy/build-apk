module.exports = {
  tokens: "8209243589:AAHWH-l64WirKXch72JnYlsuNWhV5JYqPSs",  // Ubah Jadi Token Bot Mu !!!
  owner: "8529935797", // Ubah Jadi Id Mu !!!
  port: "4461", // Ubah Jadi Port Panel Mu !!!
  ipvps: "http://dianaxyz-offc.hostingercloud.web.id" // Ubah Jadi Ip Vps Mu !!!
};