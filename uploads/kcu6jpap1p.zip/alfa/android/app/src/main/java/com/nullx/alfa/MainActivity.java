package com.nullx.alfa;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
