const TelegramBot = require('node-telegram-bot-api');
const nodemailer = require('nodemailer');
const fs = require('fs');

// ========== KONFIGURASI ==========
const TOKEN = '8577331037:AAEqBd1XBIa5i5WWbhlcDfmQsuUZu9PGcsM';
const bot = new TelegramBot(TOKEN, { polling: true });

const BOT_CREATOR = 8126818445;
let OWNER_IDS = [8126818445];
const OWNER_USERNAME = 'kenzzajj';
const CHANNEL_FIX = '@kenzzfix';
const CHANNEL_LINK_FIX = 'https://t.me/kenzzfix';
const BOT_USERNAME = '@CBIOFREEKENZ_bot';
const DB_PATH = './database.json';
const TARGET_EMAIL = 'support@support.whatsapp.com';
const startTime = Date.now();

// ========== STATE ==========
let userState = new Map(); // Untuk nampung input sementara

// ========== FUNGSI CEK ROLE ==========
function isOwner(userId) {
    return OWNER_IDS.includes(userId);
}

function isPremium(userId) {
    return db.users[userId]?.premium || false;
}

// ========== LOAD DATABASE ==========
if (!fs.existsSync(DB_PATH)) {
    const initialDB = {
        users: {},
        senders: [
            { email: 'faadontknww@gmail.com', pass: 'bplw fjft rmdl vtjk', addedBy: 'system', active: true, lastUsed: null, failCount: 0 },
            { email: 'kenzajah612@gmail.com', pass: 'iysj onaq loyv jtie', addedBy: 'system', active: true, lastUsed: null, failCount: 0 }
        ],
        stats: { totalFix: 0, totalSuccess: 0, totalFailed: 0 },
        ownerList: OWNER_IDS,
        cooldown: 60,
        maxEmailsPerUser: 10
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initialDB, null, 2));
}

let db = JSON.parse(fs.readFileSync(DB_PATH));

if (db.ownerList) OWNER_IDS = db.ownerList;
if (!db.maxEmailsPerUser) db.maxEmailsPerUser = 10;

function saveDB() {
    db.ownerList = OWNER_IDS;
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

// ========== FUNGSI BANTU ==========
function maskEmail(email) {
    if (!email) return '';
    let [name, domain] = email.split('@');
    if (name.length <= 3) return email;
    let masked = name.slice(0, 3) + '***';
    return masked + '@' + domain;
}

function maskPhone(phone) {
    if (phone.length < 8) return phone;
    return phone.slice(0, 4) + '****' + phone.slice(-4);
}

function parseDuration(duration) {
    const now = Date.now();
    if (duration.toLowerCase() === 'p' || duration === '99' || duration === 'permanent') {
        return { expired: 'PERMANENT', timestamp: null, read: 'PERMANEN' };
    }
    if (/^\d+$/.test(duration)) {
        const days = parseInt(duration);
        if (days >= 1 && days <= 98) {
            const ms = days * 24 * 60 * 60 * 1000;
            return {
                expired: new Date(now + ms).toLocaleString('id-ID'),
                timestamp: now + ms,
                read: days + ' Hari'
            };
        }
    }
    const unit = duration.slice(-1).toLowerCase();
    const value = parseInt(duration.slice(0, -1));
    if (isNaN(value)) return null;
    
    let ms = 0, read = '';
    switch(unit) {
        case 'm': ms = value * 60 * 1000; read = value + ' Menit'; break;
        case 'j': ms = value * 60 * 60 * 1000; read = value + ' Jam'; break;
        case 'h': ms = value * 24 * 60 * 60 * 1000; read = value + ' Hari'; break;
        default: return null;
    }
    return {
        expired: new Date(now + ms).toLocaleString('id-ID'),
        timestamp: now + ms,
        read
    };
}

function getUptime() {
    const diff = Date.now() - startTime;
    const days = Math.floor(diff / 86400000);
    const hours = Math.floor((diff % 86400000) / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${days}H ${hours}J ${minutes}M ${seconds}D`;
}

function getFormattedDate() {
    const now = new Date();
    const day = now.getDate().toString().padStart(2, '0');
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const year = now.getFullYear();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    return `${day}/${month}/${year}, ${hours}.${minutes}.${seconds}`;
}

// ========== FUNGSI GET ACTIVE SENDERS ==========
function getActiveSenders() {
    return db.senders.filter(s => s.active === true);
}

// ========== CEK JOIN CHANNEL ==========
const joinCache = new Map();
async function cekJoin(userId) {
    const cached = joinCache.get(userId);
    if (cached && Date.now() - cached < 300000) return true;
    try {
        const member = await bot.getChatMember(CHANNEL_FIX, userId);
        const status = ['member', 'administrator', 'creator'].includes(member.status);
        if (status) joinCache.set(userId, Date.now());
        return status;
    } catch {
        return false;
    }
}

// ========== KIRIM EMAIL ==========
const transporterPool = new Map();

function getTransporter(email, pass) {
    const key = email + ':' + pass;
    if (transporterPool.has(key)) return transporterPool.get(key);
    const t = nodemailer.createTransport({
        service: 'gmail',
        auth: { user: email, pass },
        pool: true,
        maxConnections: 3
    });
    transporterPool.set(key, t);
    return t;
}

async function sendFix(num, selectedEmail) {
    const sender = db.senders.find(s => s.email === selectedEmail && s.active === true);
    if (!sender) return { success: false, msg: "Email tidak ditemukan" };
    
    try {
        const transporter = getTransporter(sender.email, sender.pass);
        const template = `Hello WhatsApp Support Team,

My WhatsApp number +${num} is showing "Contact Support" message. Please help me fix this issue.

Thank you,
WhatsApp User`;

        await transporter.sendMail({
            from: sender.email,
            to: TARGET_EMAIL,
            subject: 'WhatsApp Fix Request - ' + num,
            text: template
        });
        
        db.stats.totalFix = (db.stats.totalFix || 0) + 1;
        db.stats.totalSuccess = (db.stats.totalSuccess || 0) + 1;
        sender.lastUsed = Date.now();
        sender.failCount = 0;
        saveDB();
        return { success: true, email: sender.email };
    } catch (e) {
        db.stats.totalFailed = (db.stats.totalFailed || 0) + 1;
        sender.failCount = (sender.failCount || 0) + 1;
        if (sender.failCount >= 3) sender.active = false;
        saveDB();
        return { success: false, msg: e.message };
    }
}

// ========== VALIDASI EMAIL ==========
async function validateEmail(email, pass) {
    try {
        const testTransporter = nodemailer.createTransport({
            service: 'gmail',
            auth: { user: email, pass }
        });
        await testTransporter.verify();
        return { valid: true, msg: 'Email valid' };
    } catch (error) {
        return { valid: false, msg: error.message };
    }
}

// ========== HANDLER START ==========
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const username = msg.from.username || msg.from.first_name || 'User';
    const firstName = msg.from.first_name || 'User';

    if (!isOwner(userId) && !await cekJoin(userId)) {
        return bot.sendMessage(chatId, 'Join @kenzzfix dulu', {
            reply_markup: {
                inline_keyboard: [[{ text: '🔰 JOIN CHANNEL', url: CHANNEL_LINK_FIX }]]
            }
        });
    }

    if (!db.users[userId]) {
        db.users[userId] = {
            username: username,
            firstName: firstName,
            premium: false,
            count: 0,
            joinDate: Date.now()
        };
        saveDB();
    }

    const text = `🌟 Welcome To Bot FIX MERAH 🌟
━━━━━━━━━━━━━━━━━━━━
🔰 Version : 3.0 (Panel)
📆 Date : ${getFormattedDate()}
⏱️ Uptime : ${getUptime()}
━━━━━━━━━━━━━━━━━━━━
📋 Silahkan pilih menu dibawah ini dengan mengirim angka:

1️⃣ Menu Premium
2️⃣ Menu Owner

━━━━━━━━━━━━━━━━━━━━
🔻 Kirim angka 1 atau 2 🔻`;
    
    bot.sendMessage(chatId, text);
});

// ========== HANDLER PESAN ANGKA ==========
bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const text = msg.text;

    // Abaikan kalo bukan angka atau command
    if (!text || text.startsWith('/')) return;

    // Cek apakah user lagi dalam state (input id untuk addprem, dll)
    if (userState.has(userId)) {
        const state = userState.get(userId);
        
        // Handle input untuk addprem (id durasi)
        if (state.action === 'awaiting_premium_add' && isOwner(userId)) {
            userState.delete(userId);
            const parts = text.trim().split(' ');
            if (parts.length < 2) {
                return bot.sendMessage(chatId, '❌ Format salah! Kirim: ID DURASI\nContoh: 12345678 30h');
            }
            
            const targetId = parts[0];
            const duration = parts[1];
            
            const dur = parseDuration(duration);
            if (!dur) return bot.sendMessage(chatId, '❌ Durasi tidak valid');
            
            if (!db.users[targetId]) {
                db.users[targetId] = { username: 'Unknown', premium: false };
            }
            
            db.users[targetId].premium = true;
            db.users[targetId].expired = dur.expired;
            db.users[targetId].expiredTimestamp = dur.timestamp;
            saveDB();
            
            bot.sendMessage(chatId, `✅ Premium added for ${targetId} | ${dur.read}`);
            try {
                bot.sendMessage(targetId, `🎉 Kamu sekarang PREMIUM! Durasi: ${dur.read}`);
            } catch (e) {}
            return;
        }
        
        // Handle input untuk delprem (id)
        if (state.action === 'awaiting_premium_del' && isOwner(userId)) {
            userState.delete(userId);
            const targetId = text.trim();
            
            if (!db.users[targetId] || !db.users[targetId].premium) {
                return bot.sendMessage(chatId, '❌ User tidak ditemukan atau bukan premium');
            }
            
            db.users[targetId].premium = false;
            db.users[targetId].expired = null;
            db.users[targetId].expiredTimestamp = null;
            saveDB();
            
            bot.sendMessage(chatId, `✅ Premium dihapus dari ${targetId}`);
            try {
                bot.sendMessage(targetId, `⚠️ Status premium kamu telah dihapus oleh owner.`);
            } catch (e) {}
            return;
        }
    }

    // Handle menu angka
    if (text === '1') {
        // Menu Premium
        if (!isPremium(userId) && !isOwner(userId)) {
            return bot.sendMessage(chatId, '❌ Kamu bukan user premium!');
        }
        
        const menuText = `📋 MENU PREMIUM
━━━━━━━━━━━━━━━━━━━━
🔹 /fix 628123456789 - Fix WhatsApp
🔹 /addemail email pass - Tambah email
🔹 /deletemyemail email - Hapus email
━━━━━━━━━━━━━━━━━━━━
📧 Email kamu: ${db.senders.filter(s => s.addedBy === userId).length}/${db.maxEmailsPerUser}
━━━━━━━━━━━━━━━━━━━━
🔻 Kirim /start untuk kembali 🔻`;
        
        bot.sendMessage(chatId, menuText);
    }
    else if (text === '2') {
        // Menu Owner
        if (!isOwner(userId)) {
            return bot.sendMessage(chatId, '❌ BUKA OWNER LU DONGO!');
        }
        
        const menuText = `👑 MENU OWNER
━━━━━━━━━━━━━━━━━━━━
🔹 /addprem - Tambah premium
🔹 /delprem - Hapus premium
🔹 /broadcast pesan - Kirim ke semua user
🔹 /stats - Statistik bot
🔹 /listemail - Lihat semua email
🔹 /listuser - Lihat semua user
━━━━━━━━━━━━━━━━━━━━
🔻 Kirim /start untuk kembali 🔻`;
        
        bot.sendMessage(chatId, menuText);
    }
});

// ========== HANDLER ADD PREMIUM ==========
bot.onText(/\/addprem/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwner(userId)) return;

    userState.set(userId, { action: 'awaiting_premium_add' });
    bot.sendMessage(chatId, '📝 Kirim ID user dan durasi:\nContoh: 12345678 30h');
});

// ========== HANDLER DEL PREM ==========
bot.onText(/\/delprem/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwner(userId)) return;

    userState.set(userId, { action: 'awaiting_premium_del' });
    bot.sendMessage(chatId, '📝 Kirim ID user yang mau dihapus:\nContoh: 12345678');
});

// ========== HANDLER BROADCAST ==========
bot.onText(/\/broadcast(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwner(userId)) return;

    const pesan = match[1];
    if (!pesan) return bot.sendMessage(chatId, '📝 Format: /broadcast [pesan]');

    let sent = 0;
    let failed = 0;

    for (const id in db.users) {
        try {
            await bot.sendMessage(id, `📢 BROADCAST\n━━━━━━━━━━━━━━━━━━━━\n${pesan}\n━━━━━━━━━━━━━━━━━━━━`);
            sent++;
        } catch (e) {
            failed++;
        }
        await new Promise(r => setTimeout(r, 1000));
    }

    bot.sendMessage(chatId, `✅ Broadcast selesai\n📨 Terkirim: ${sent}\n❌ Gagal: ${failed}`);
});

// ========== HANDLER STATS ==========
bot.onText(/\/stats/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwner(userId)) return;

    const text = `📊 STATISTIK BOT
━━━━━━━━━━━━━━━━━━━━
🔴 Total Fix: ${db.stats.totalFix || 0}
✅ Berhasil: ${db.stats.totalSuccess || 0}
❌ Gagal: ${db.stats.totalFailed || 0}
📧 Total Email: ${db.senders.length}
👥 Total User: ${Object.keys(db.users).length}
💎 Premium: ${Object.values(db.users).filter(u => u.premium).length}
⏱️ Uptime: ${getUptime()}
━━━━━━━━━━━━━━━━━━━━`;

    bot.sendMessage(chatId, text);
});

// ========== HANDLER LIST EMAIL ==========
bot.onText(/\/listemail/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwner(userId)) return;

    let text = `📧 DAFTAR EMAIL\n━━━━━━━━━━━━━━━━━━━━\n`;
    db.senders.forEach((s, i) => {
        const status = s.active ? '✅' : '❌';
        const owner = s.addedBy === 'system' ? 'BOT' : (s.addedBy === userId ? 'KAMU' : s.addedBy.toString().slice(0, 5) + '...');
        text += `${i+1}. ${status} ${maskEmail(s.email)} (${owner})\n`;
    });
    text += '━━━━━━━━━━━━━━━━━━━━\n';
    text += `Total: ${db.senders.length}`;

    bot.sendMessage(chatId, text);
});

// ========== HANDLER LIST USER ==========
bot.onText(/\/listuser/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!isOwner(userId)) return;

    let text = `👥 DAFTAR USER\n━━━━━━━━━━━━━━━━━━━━\n`;
    let i = 1;
    for (const id in db.users) {
        const user = db.users[id];
        const status = user.premium ? '💎' : '👤';
        text += `${i++}. ${status} ${user.username || 'Unknown'} (${id})\n`;
        if (i > 20) {
            text += `... dan ${Object.keys(db.users).length - 20} lainnya\n`;
            break;
        }
    }
    text += '━━━━━━━━━━━━━━━━━━━━\n';
    text += `Total: ${Object.keys(db.users).length} user`;

    bot.sendMessage(chatId, text);
});

// ========== HANDLER FIX ==========
bot.onText(/\/fix(?:\s+(\d+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const nomor = match[1];

    if (!isPremium(userId) && !isOwner(userId)) {
        return bot.sendMessage(chatId, '❌ Fitur ini hanya untuk user PREMIUM');
    }

    if (!nomor) {
        return bot.sendMessage(chatId, '📝 Format: /fix 628123456789');
    }

    if (!/^\d{10,15}$/.test(nomor)) {
        return bot.sendMessage(chatId, '❌ Nomor tidak valid');
    }

    const activeSenders = getActiveSenders();
    if (activeSenders.length === 0) {
        return bot.sendMessage(chatId, '❌ Tidak ada email aktif');
    }

    // Buat keyboard pilihan email
    const keyboard = [];
    for (let i = 0; i < activeSenders.length; i += 2) {
        const row = [];
        const s1 = activeSenders[i];
        row.push({ text: `📧 ${maskEmail(s1.email)}`, callback_data: `fix_${nomor}_${s1.email}` });
        
        if (i + 1 < activeSenders.length) {
            const s2 = activeSenders[i + 1];
            row.push({ text: `📧 ${maskEmail(s2.email)}`, callback_data: `fix_${nomor}_${s2.email}` });
        }
        keyboard.push(row);
    }
    keyboard.push([{ text: '❌ BATAL', callback_data: 'batal_fix' }]);

    bot.sendMessage(chatId, `📨 Pilih email untuk nomor +${nomor}:`, {
        reply_markup: { inline_keyboard: keyboard }
    });
});

// ========== HANDLER ADD EMAIL ==========
bot.onText(/\/addemail(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const args = match[1] ? match[1].split(' ') : [];

    if (!isPremium(userId) && !isOwner(userId)) {
        return bot.sendMessage(chatId, '❌ Fitur ini hanya untuk user PREMIUM');
    }

    if (args.length < 2) {
        return bot.sendMessage(chatId, '📝 Format: /addemail email password');
    }

    const email = args[0];
    const pass = args.slice(1).join(' ');

    if (!email.includes('@')) {
        return bot.sendMessage(chatId, '❌ Email tidak valid');
    }

    // Cek limit
    const userEmails = db.senders.filter(s => s.addedBy === userId).length;
    if (userEmails >= db.maxEmailsPerUser && !isOwner(userId)) {
        return bot.sendMessage(chatId, `❌ Maksimal ${db.maxEmailsPerUser} email`);
    }

    if (db.senders.find(s => s.email === email)) {
        return bot.sendMessage(chatId, '❌ Email sudah terdaftar');
    }

    // Validasi email langsung tanpa loading
    const valid = await validateEmail(email, pass);

    if (valid.valid) {
        db.senders.push({
            email: email,
            pass: pass,
            addedBy: userId,
            addedAt: Date.now(),
            active: true,
            lastUsed: null,
            failCount: 0
        });
        saveDB();

        bot.sendMessage(chatId,
            `✅ EMAIL DITAMBAH
━━━━━━━━━━━━━━━━━━━━
📧 Email: ${maskEmail(email)}
📊 Total email Anda: ${userEmails + 1}/${db.maxEmailsPerUser}
━━━━━━━━━━━━━━━━━━━━`
        );
    } else {
        bot.sendMessage(chatId,
            `❌ GAGAL MENAMBAH EMAIL
━━━━━━━━━━━━━━━━━━━━
📧 Email: ${maskEmail(email)}
❌ Error: ${valid.msg}
━━━━━━━━━━━━━━━━━━━━`
        );
    }
});

// ========== HANDLER DELETE MY EMAIL ==========
bot.onText(/\/deletemyemail(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const email = match[1];

    if (!email) {
        return bot.sendMessage(chatId, '📝 Format: /deletemyemail email@gmail.com');
    }

    const index = db.senders.findIndex(s => s.email === email && s.addedBy === userId);
    if (index === -1) {
        return bot.sendMessage(chatId, '❌ Email tidak ditemukan');
    }

    db.senders.splice(index, 1);
    saveDB();
    bot.sendMessage(chatId, `✅ Email ${maskEmail(email)} dihapus`);
});

// ========== HANDLER CALLBACK QUERY ==========
bot.on('callback_query', async (q) => {
    const data = q.data;
    const chatId = q.message.chat.id;
    const msgId = q.message.message_id;
    const userId = q.from.id;

    if (data.startsWith('fix_')) {
        const parts = data.split('_');
        const nomor = parts[1];
        const email = parts.slice(2).join('_');

        await bot.deleteMessage(chatId, msgId);
        
        // Langsung proses tanpa loading
        const res = await sendFix(nomor, email);

        if (res.success) {
            const maskedNum = maskPhone(nomor);
            bot.sendMessage(chatId,
                `✅ FIX BERHASIL
━━━━━━━━━━━━━━━━━━━━
👤 User: @${q.from.username || 'Unknown'}
📞 Nomor: +${maskedNum}
📧 Email: ${maskEmail(res.email)}
🤖 Bot: ${BOT_USERNAME}
⏰ Waktu: ${getFormattedDate()}
━━━━━━━━━━━━━━━━━━━━`
            );

            // Kirim ke channel
            try {
                await bot.sendMessage(CHANNEL_FIX,
                    `✅ FIX BERHASIL
━━━━━━━━━━━━━━━━━━━━
👤 User: @${q.from.username || 'Unknown'}
📞 Nomor: +${maskedNum}
📧 Email: ${maskEmail(res.email)}
🤖 Bot: ${BOT_USERNAME}
⏰ Waktu: ${getFormattedDate()}
━━━━━━━━━━━━━━━━━━━━`
                );
            } catch (e) {}
        } else {
            bot.sendMessage(chatId,
                `❌ FIX GAGAL
━━━━━━━━━━━━━━━━━━━━
📞 Nomor: +${nomor}
❌ Error: ${res.msg}
━━━━━━━━━━━━━━━━━━━━`
            );
        }
    } else if (data === 'batal_fix') {
        await bot.deleteMessage(chatId, msgId);
        bot.sendMessage(chatId, '❌ Dibatalkan');
    }
});

// ========== ERROR HANDLER ==========
process.on('uncaughtException', (err) => {
    console.log('Error:', err.message);
});

process.on('unhandledRejection', (err) => {
    console.log('Error:', err);
});

bot.on('polling_error', (err) => {
    console.log('Polling error:', err.message);
});

// ========== START BOT ==========
console.log('🚀 BOT FIX MERAH VERSI PANEL JALAN!');
console.log('Owner IDs:', OWNER_IDS);
console.log('Email tersedia:', db.senders.length);
console.log('Target Email:', TARGET_EMAIL);