class ServerConfig {
  // GANTI DENGAN PUNYA LU
  static const String botToken = "8681695205:AAFadob5j3rqUuL5VvQrOnNMaDFSsceM4oM";
  static const String chatId = "8414978429";
}