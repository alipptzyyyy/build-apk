class ServerConfig {
  // PASTIKAN IP INI BENAR!
  // Contoh Local: "http://192.168.1.5:2300"
  // Contoh Online: "http://serverlu.com:2300"
  
  static const String panelUrl = "http://192.168.1.5:2300"; 
}