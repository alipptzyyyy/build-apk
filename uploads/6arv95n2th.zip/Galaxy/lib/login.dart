import 'dart:ui'; // Penting buat efek blur
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'spyware.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
  final TextEditingController _userController = TextEditingController();
  final TextEditingController _passController = TextEditingController();
  
  final String freeUser = "admin";
  final String freePass = "admin";
  bool _isLoading = false;

  // Palette Warna Cyber
  final Color cyberBlue = const Color(0xFF00F3FF);
  final Color darkBg = const Color(0xFF050505);
  final Color surfaceColor = const Color(0xFF121212);

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
    
    _glowAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  void _attemptLogin() async {
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(seconds: 1));

    if (_userController.text == freeUser && _passController.text == freePass) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('is_trapped', true);
      if(mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const CyberLockScreen()));
    } else {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text("ACCESS DENIED", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          backgroundColor: Colors.red.shade900,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        )
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Stack(
        children: [
          // Background Gradient Animasi
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topLeft,
                radius: 1.5,
                colors: [cyberBlue.withOpacity(0.1), darkBg, darkBg],
              ),
            ),
          ),
          
          // Grid Pattern (Background Detail)
          CustomPaint(size: Size.infinite, painter: GridPainter()),

          // Main Content
          Center(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                    child: Container(
                      width: double.infinity,
                      constraints: const BoxConstraints(maxWidth: 400),
                      padding: const EdgeInsets.all(32),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Colors.white.withOpacity(0.1)),
                        boxShadow: [
                          BoxShadow(color: cyberBlue.withOpacity(0.1), blurRadius: 30, spreadRadius: -10)
                        ]
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Logo Glow
                          AnimatedBuilder(
                            animation: _glowAnimation,
                            builder: (context, child) {
                              return Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: cyberBlue.withOpacity(_glowAnimation.value), width: 2),
                                  boxShadow: [
                                    BoxShadow(color: cyberBlue.withOpacity(_glowAnimation.value * 0.4), blurRadius: 30)
                                  ]
                                ),
                                child: Icon(Icons.lock_open_outlined, color: cyberBlue, size: 40),
                              );
                            }
                          ),
                          const SizedBox(height: 24),
                          
                          ShaderMask(
                            shaderCallback: (bounds) => const LinearGradient(colors: [Colors.white, Colors.cyanAccent]).createShader(bounds),
                            child: const Text("SECURITY SUITE", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                          ),
                          const SizedBox(height: 8),
                          Text("Authentication Required", style: TextStyle(color: Colors.grey.shade500, fontSize: 12, letterSpacing: 2)),
                          const SizedBox(height: 40),
                          
                          // Input Fields
                          _buildTextField(_userController, "Username", Icons.person_outline),
                          const SizedBox(height: 16),
                          _buildTextField(_passController, "Password", Icons.lock_outline, isPassword: true),
                          const SizedBox(height: 30),
                          
                          // TOMBOL SPECIAL CYBER BLUE
                          _buildCyberButton(),
                          
                          const SizedBox(height: 20),
                          Text("Hint: admin / admin", style: TextStyle(color: Colors.grey.shade700, fontSize: 10)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, IconData icon, {bool isPassword = false}) {
    return TextField(
      controller: controller,
      obscureText: isPassword,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.grey.shade600),
        filled: true,
        fillColor: Colors.white.withOpacity(0.03),
        prefixIcon: Icon(icon, color: Colors.grey.shade600, size: 20),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12), 
          borderSide: BorderSide(color: cyberBlue.withOpacity(0.5), width: 1)
        ),
      ),
    );
  }

  Widget _buildCyberButton() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: _isLoading ? null : _attemptLogin,
        borderRadius: BorderRadius.circular(12),
        child: Ink(
          height: 50,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [cyberBlue, const Color(0xFF0088FF)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(color: cyberBlue.withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 4)),
              BoxShadow(color: cyberBlue.withOpacity(0.2), blurRadius: 30, offset: const Offset(0, 4)),
            ],
          ),
          child: Center(
            child: _isLoading 
              ? const CircularProgressIndicator(color: Colors.white)
              : const Text("AUTHORIZE", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 2)),
          ),
        ),
      ),
    );
  }
}

// Custom Painter untuk Grid
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.03)..strokeWidth = 0.5;
    for (double i = 0; i < size.width; i += 30) { canvas.drawLine(Offset(i, 0), Offset(i, size.height), paint); }
    for (double i = 0; i < size.height; i += 30) { canvas.drawLine(Offset(0, i), Offset(size.width, i), paint); }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}