package com.cyber.security

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
    // Logic native bisa ditambahkan di sini jika perlu
}