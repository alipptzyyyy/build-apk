module.exports = {
  PORT: process.env.PORT || 3061,
  WS_PORT: process.env.WS_PORT || 3061,
  // WhatsApp bug types
  BUGS: [
    { bug_id: "global", bug_name: "Crash Global" },
    { bug_id: "ios", bug_name: "Crash IOS" },
    { bug_id: "android", bug_name: "Crash Android" },
    { bug_id: "yuukey", bug_name: "Delay Invisible By @YuukeyD7eppeli" },
    { bug_id: "denis", bug_name: "Contact FC Anti Block @Deniss_erorr" }
  ],
    
  payload: [
    { bug_id: "XMml", bug_name: "1 MSG Crash" },
    { bug_id: "FreezePackk", bug_name: "Freeze Click" },
    { bug_id: "gsGlx", bug_name: "Loca IOS" },
    { bug_id: "gsIntX", bug_name: "Delay Invisible ( 75 MSG )" },
    { bug_id: "quizzzz", bug_name: "Crash Perma Click" },
    { bug_id: "fcinvisotax", bug_name: "Crash Call" },
    { bug_id: "permenCall", bug_name: "Call" },
    { bug_id: "FriendFcAntiBlock", bug_name: "Perma Crash ( Contact Only )" }
  ],
    
  DDOS: [
    { ddos_id: "s-gbps", ddos_name: "SYN High GBPS" },
    { ddos_id: "s-pps", ddos_name: "SYN Traffic Flood" },
    { ddos_id: "a-gbps", ddos_name: "ACK High GBPS" },
    { ddos_id: "a-pps", ddos_name: "ACK Traffic Flood" },
    { ddos_id: "icmp", ddos_name: "ICMP Flood" },
    { ddos_id: "udp", ddos_name: "GUDP ( HIGH RISK )" }

  ],
  // News data
  NEWS: [
    {
      image: "https://files.catbox.moe/ez1z0k.jpg",
      title: "Remastered",
      desc: "Powered By @NullXTeam"
    }
  ],
  // Role cooldowns (in seconds)
  ROLE_COOLDOWNS: {
    member: 300,
    reseller: 240,
    reseller1: 60,
    owner: 0,
    vip: 60,
  },
  // Max quantities by role
  MAX_QUANTITIES: {
    member: 5,
    reseller: 5,
    reseller1: 5,
    owner: 10,
    vip: 10,
  }
};