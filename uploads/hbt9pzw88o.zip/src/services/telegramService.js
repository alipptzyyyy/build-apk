const TelegramBot = require("node-telegram-bot-api");
const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const fs = require('fs');
const path = require('path');
const { logger } = require('../utils/logger');
const { TOKEN, OWNER_ID } = require('../config/telegram');
const { loadDatabase, saveDatabase } = require('./databaseService');
const { disconnectAllActiveConnections, startUserSessions } = require('./whatsappService');

// --- CONFIG GRAMJS (UNTUK REPORT & SESSIONS NYATA) ---
const API_ID = 20430856; 
const API_HASH = "b9260d00f576395b002062363e0d291e";
const SESSIONS_FILE = path.join(__dirname, '../../data/telegram_sessions.json');

const bot = new TelegramBot(TOKEN, { polling: true });
let tempClients = {}; // Penampung client sementara saat proses login OTP

// Helper: Ambil daftar sesi report
const getSavedSessions = () => {
    if (!fs.existsSync(SESSIONS_FILE)) return [];
    try {
        const data = fs.readFileSync(SESSIONS_FILE, 'utf8');
        return JSON.parse(data);
    } catch (e) { 
        logger.error("Error reading sessions file:", e);
        return []; 
    }
};

// Helper: Simpan sesi report baru
const saveSession = (sessionData) => {
    const sessions = getSavedSessions();
    sessions.push(sessionData);
    const dir = path.dirname(SESSIONS_FILE);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions, null, 2));
};

// Helper: Format User Dashboard
function getFormattedUsers() {
    const db = loadDatabase();
    if (db.length === 0) return "Belum ada pengguna.";
    return db.map(u => `👤 *${u.username}* | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

// --- HANDLERS BOT COMMANDS ---

bot.onText(/^\/?(start|menu)/, (msg) => {
    const id = msg.from.id;
    const isOwner = id === OWNER_ID;

    const options = {
        reply_markup: {
            inline_keyboard: [
                [{ text: "🆕 Buat Akun Member", callback_data: "create_member" }],
                [{ text: "⏳ Set Expired", callback_data: "set_expire" }],
                ...(isOwner ? [
                    [
                        { text: "📋 List User", callback_data: "list_user" },
                        { text: "🗑 Hapus User", callback_data: "delete_user" }
                    ],
                    [
                        { text: "📊 Stats Server", callback_data: "stats" },
                        { text: "🔄 Restart WA", callback_data: "restart_sessions" }
                    ]
                ] : [])
            ]
        }
    };

    bot.sendMessage(id, `👋 Halo *${msg.from.first_name}*,\nSelamat datang di *Dashboard Control*.\n\nPilih menu:`, { 
        parse_mode: "Markdown",
        ...options 
    });
});

bot.on("callback_query", async (query) => {
    const id = query.from.id;
    const data = query.data;
    const isOwner = id === OWNER_ID;

    switch (data) {
        case "create_member":
            bot.sendMessage(id, "📝 Format: `username|password|durasi_hari`", { parse_mode: "Markdown" });
            bot.once("message", (msg) => {
                if (msg.text && msg.text.includes("|")) {
                    const [username, password, day] = msg.text.split("|");
                    const db = loadDatabase();
                    if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
                    const expired = new Date();
                    expired.setDate(expired.getDate() + parseInt(day));
                    db.push({ username, password, role: "member", expiredDate: expired.toISOString().split("T")[0] });
                    saveDatabase(db);
                    bot.sendMessage(id, `✅ Member Created!\nUser: \`${username}\`\nExp: \`${expired.toISOString().split("T")[0]}\``, { parse_mode: "Markdown" });
                }
            });
            break;

        case "list_user":
            if (isOwner) bot.sendMessage(id, `📋 *Daftar Pengguna:*\n\n${getFormattedUsers()}`, { parse_mode: "Markdown" });
            break;

        case "stats":
            const sessions = getSavedSessions();
            const dbStats = loadDatabase();
            bot.sendMessage(id, `📊 *Statistik Miyako*\n\n👥 User Dashboard: ${dbStats.length}\n🔑 Session Report: ${sessions.length} Akun Aktif`, { parse_mode: "Markdown" });
            break;

        case "restart_sessions":
            bot.sendMessage(id, "🔄 Merestart WhatsApp Sesi...");
            try {
                await disconnectAllActiveConnections();
                await startUserSessions();
                bot.sendMessage(id, "✅ Sesi WhatsApp berhasil direstart.");
            } catch (err) {
                bot.sendMessage(id, "❌ Gagal: " + err.message);
            }
            break;
            
        case "delete_user":
            bot.sendMessage(id, "🗑 Masukkan username untuk dihapus:");
            bot.once("message", (msg) => {
                const db = loadDatabase();
                const index = db.findIndex(u => u.username === msg.text.trim());
                if (index !== -1) {
                    db.splice(index, 1);
                    saveDatabase(db);
                    bot.sendMessage(id, "🗑 User berhasil dihapus.");
                } else {
                    bot.sendMessage(id, "❌ User tidak ditemukan.");
                }
            });
            break;
    }
    bot.answerCallbackQuery(query.id);
});

// --- EXPORTS UNTUK CONTROLLER API (DIPANGGIL DARI FLUTTER) ---

exports.sendCode = async (phoneNumber) => {
    // FIX: Tambahkan useWSS dan Device Info untuk mencegah SecurityError Nonce Hash
    const client = new TelegramClient(new StringSession(""), API_ID, API_HASH, { 
        connectionRetries: 5,
        useWSS: true, // Menggunakan WebSocket Secure untuk koneksi lebih stabil
        deviceModel: "Miyako Dashboard Server",
        systemVersion: "Linux Node.js",
        appVersion: "1.0.0"
    });
    
    try {
        await client.connect();
        
        const { phoneCodeHash } = await client.sendCode(
            { apiId: API_ID, apiHash: API_HASH },
            phoneNumber
        );

        tempClients[phoneNumber] = client;
        return { phoneCodeHash };
    } catch (err) {
        logger.error("GramJS SendCode Error:", err);
        // Jika gagal koneksi, pastikan disconnect agar tidak menggantung
        if (client) await client.disconnect();
        throw err;
    }
};

exports.signIn = async (phoneNumber, phoneCodeHash, code) => {
    const client = tempClients[phoneNumber];
    if (!client) throw new Error("Sesi tidak ditemukan atau kadaluarsa. Silakan minta kode lagi.");

    try {
        await client.invoke(
            new Api.auth.SignIn({
                phoneNumber: phoneNumber,
                phoneCodeHash: phoneCodeHash,
                phoneCode: code,
            })
        );

        const sessionString = client.session.save();
        const me = await client.getMe();

        saveSession({ 
            phone: phoneNumber, 
            userId: me.id.toString(), 
            session: sessionString,
            addedAt: new Date().toISOString()
        });

        delete tempClients[phoneNumber]; 
        return { id: me.id.toString(), username: me.username };
    } catch (error) {
        if (client) await client.disconnect();
        throw new Error("Gagal verifikasi kode: " + error.message);
    }
};

exports.getSavedSessions = getSavedSessions;

exports.executeReport = async (target, reasonString, count) => {
    const sessions = getSavedSessions();
    if (sessions.length === 0) throw new Error("Tidak ada sesi akun report yang tersedia.");

    let successCount = 0;
    
    let reasonClass;
    switch (reasonString) {
        case 'spam': reasonClass = new Api.InputReportReasonSpam(); break;
        case 'fake': reasonClass = new Api.InputReportReasonFake(); break;
        case 'pornography': reasonClass = new Api.InputReportReasonPornography(); break;
        case 'illegal': reasonClass = new Api.InputReportReasonChildAbuse(); break;
        default: reasonClass = new Api.InputReportReasonOther({ text: "Violating Terms" });
    }

    await Promise.all(sessions.map(async (sess) => {
        // FIX: Tambahkan useWSS juga pada saat eksekusi report
        const client = new TelegramClient(new StringSession(sess.session), API_ID, API_HASH, { 
            connectionRetries: 1,
            useWSS: true 
        });
        
        try {
            await client.connect();
            const peer = await client.getEntity(target);

            await client.invoke(new Api.account.ReportPeer({ 
                peer: peer, 
                reason: reasonClass, 
                message: "This account violates rules." 
            }));
            
            successCount++;
            await client.disconnect();
        } catch (e) { 
            logger.error(`Reporting failed for ${sess.phone}: ${e.message}`);
        }
    }));

    return { success_count: successCount };
};

exports.startTelegramBot = () => {
    logger.info("Telegram Admin Bot Started Successfully");
    console.log("🚀 Telegram Admin Bot Started");
};

if (require.main === module) {
    exports.startTelegramBot();
}