module.exports = {
  TOKEN: process.env.TELEGRAM_TOKEN || "8355128600:AAHjftEoOWKc0MMjz8kBJwwDXJjJYXvfNzI",
  OWNER_ID: process.env.OWNER_ID || 8435474674,
  ID_GROUP: [
    -1003626626837
  ],
  ID_GROUP_UTAMA: [
    -1003626626837
  ]
};