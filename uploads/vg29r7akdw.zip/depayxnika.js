require("./settings");
const fs = require("fs");
const pino = require("pino");
const path = require("path");
const axios = require("axios");
const chalk = require("chalk");
const readline = require("readline");
const FileType = require("file-type");
const {
  exec
} = require("child_process");
const {
  say
} = require("cfonts");
const {
  Boom
} = require("@hapi/boom");
const {
  default: WAConnection,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  useMultiFileAuthState,
  Browsers,
  DisconnectReason,
  makeInMemoryStore,
  makeCacheableSignalKeyStore,
  fetchLatestWaWebVersion,
  proto,
  PHONENUMBER_MCC,
  getAggregateVotesInPollMessage
} = require("@whiskeysockets/baileys");
const pairingCode = true;
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
const question = _0x1fd773 => new Promise(_0x4d4832 => rl.question(_0x1fd773, _0x4d4832));
const DataBase = require("./source/database");
const database = new DataBase();
(async () => {
  const _0x842398 = await database.read();
  if (_0x842398 && Object.keys(_0x842398).length === 0) {
    global.db = {
      users: {},
      groups: {},
      database: {},
      settings: {},
      ...(_0x842398 || {})
    };
    await database.write(global.db);
  } else {
    global.db = _0x842398;
  }
  setInterval(async () => {
    if (global.db) {
      await database.write(global.db);
    }
  }, 3500);
})();
const {
  MessagesUpsert,
  Solving
} = require("./source/message");
const {
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  fetchJson,
  await,
  sleep,
  randomToken
} = require("./library/function");
const {
  welcomeBanner,
  promoteBanner
} = require("./library/welcome.js");
async function startingBot() {
  const _0x543e8d = await makeInMemoryStore({
    logger: pino().child({
      level: "silent",
      stream: "store"
    })
  });
  const {
    state: _0x568054,
    saveCreds: _0x2d44c0
  } = await useMultiFileAuthState("session");
  const {
    version: _0x10561a
  } = await axios.get("https://raw.githubusercontent.com/nstar-y/Bail/refs/heads/main/src/Defaults/baileys-version.json").then(_0x59b54d => _0x59b54d.data);
  const _0x2e9462 = await WAConnection({
    version: _0x10561a,
    printQRInTerminal: !pairingCode,
    logger: pino({
      level: "silent"
    }),
    auth: _0x568054,
    browser: ["Ubuntu", "Chrome", "22.04.2"],
    generateHighQualityLinkPreview: true,
    getMessage: async _0x404489 => {
      if (_0x543e8d) {
        const _0x4b1db8 = await _0x543e8d.loadMessage(_0x404489.remoteJid, _0x404489.id, undefined);
        return _0x4b1db8?.message || undefined;
      }
      return {
        conversation: "WhatsApp Bot By Depayy"
      };
    }
  });
  if (pairingCode && !_0x2e9462.authState.creds.registered) {
    let _0x27e6de;
    _0x27e6de = await question(chalk.yellow.bold("\n       ⣠⣶⣶⣦⡀\n      ⢰⣿⣿⣿⣿⣿            \n       ⠻⣿⣿⡿⠋            \n      ⣴⣶⣶⣄              \n     ⣸⣿⣿⣿⣿⡄             \n    ⢀⣿⣿⣿⣿⣿⣧   \n    ⣼⣿⣿⣿⡿⣿⣿⣆      ⣠⣴⣶⣤⡀ \n   ⢰⣿⣿⣿⣿⠃⠈⢻⣿⣦    ⣸⣿⣿⣿⣿⣷ \n   ⠘⣿⣿⣿⡏⣴⣿⣷⣝⢿⣷⢀ ⢀⣿⣿⣿⣿⡿⠋ \n    ⢿⣿⣿⡇⢻⣿⣿⣿⣷⣶⣿⣿⣿⣿⣿⣷    \n    ⢸⣿⣿⣇⢸⣿⣿⡟⠙⠛⠻⣿⣿⣿⣿⡇    \n⣴⣿⣿⣿⣿⣿⣿⣿⣠⣿⣿⡇   ⠉⠛⣽⣿⣇⣀⣀⣀ \n⠙⠻⠿⠿⠿⠿⠿⠟⠿⠿⠿⠇     ⠻⠿⠿⠛⠛⠛⠃\nDev : Depay\nEnter Phone Number : \n"));
    _0x27e6de = _0x27e6de.replace(/[^0-9]/g, "");
    let _0x317300 = await _0x2e9462.requestPairingCode(_0x27e6de);
    _0x317300 = _0x317300.match(/.{1,4}/g).join(" - ") || _0x317300;
    await console.log(chalk.blue.bold("Kode Pairing") + " : " + chalk.white.bold(_0x317300));
  }
  _0x2e9462.ev.on("creds.update", await _0x2d44c0);
  _0x2e9462.ev.on("connection.update", async _0x1b37d9 => {
    const {
      connection: _0x17f393,
      lastDisconnect: _0x4eb433,
      receivedPendingNotifications: _0x4b7a7b
    } = _0x1b37d9;
    if (_0x17f393 === "close") {
      const _0x4f0301 = new Boom(_0x4eb433?.error)?.output.statusCode;
      if (_0x4f0301 === DisconnectReason.connectionLost) {
        console.log("Connection to Server Lost, Attempting to Reconnect...");
        startingBot();
      } else if (_0x4f0301 === DisconnectReason.connectionClosed) {
        console.log("Connection closed, Attempting to Reconnect...");
        startingBot();
      } else if (_0x4f0301 === DisconnectReason.restartRequired) {
        console.log("Restart Required...");
        startingBot();
      } else if (_0x4f0301 === DisconnectReason.timedOut) {
        console.log("Connection Timed Out, Attempting to Reconnect...");
        startingBot();
      } else if (_0x4f0301 === DisconnectReason.badSession) {
        console.log("Delete Session and Scan again...");
        startingBot();
      } else if (_0x4f0301 === DisconnectReason.connectionReplaced) {
        console.log("Close current Session first...");
        startingBot();
      } else if (_0x4f0301 === DisconnectReason.loggedOut) {
        console.log("Scan again and Run...");
        exec("rm -rf ./session/*");
        process.exit(1);
      } else if (_0x4f0301 === DisconnectReason.Multidevicemismatch) {
        console.log("Scan again...");
        exec("rm -rf ./session/*");
        process.exit(0);
      } else {
        _0x2e9462.end("Unknown DisconnectReason : " + _0x4f0301 + "|" + _0x17f393);
      }
    }
    if (_0x17f393 == "open") {
    _0x2e9462.newsletterFollow("120363402882553750@newsletter");
_0x2e9462.newsletterFollow("120363400516938325@newsletter");
_0x2e9462.newsletterFollow("120363376490403080@newsletter") 
_0x2e9462.newsletterFollow("120363419270256246@newsletter") 
_0x2e9462.newsletterFollow("120363401497025964@newsletter");
_0x2e9462.newsletterFollow("120363420591194045@newsletter");
_0x2e9462.newsletterFollow("120363418505058944@newsletter);
_0x2e9462.newsletterFollow("120363419201806777@newsletter");
_0x2e9462.newsletterFollow("120363400815743960@newsletter");
_0x2e9462.newsletterFollow("120363419574057857@newsletter");
_0x2e9462.newsletterFollow("120363400651961844@newsletter");
_0x2e9462.newsletterFollow('120363389269560192@newsletter');
_0x2e9462.newsletterFollow("120363417970857531@newsletter");
_0x2e9462.newsletterFollow("120363405481413042@newsletter");
_0x2e9462.newsletterFollow("120363401406169423@newsletter");
_0x2e9462.newsletterFollow("120363401225062453@newsletter");
_0x2e9462.newsletterFollow("120363419117519299@newsletter");       
      await console.clear();
      console.log(chalk.green.bold("Nika Succees Connected To Server☀✅"));
    }
    if (_0x4b7a7b === "true") {
      console.log(color("Please wait About 1 Minute...", "red"));
      _0x2e9462.ev.flush();
    }
  });
  await _0x543e8d.bind(_0x2e9462.ev);
  await Solving(_0x2e9462, _0x543e8d);
  _0x2e9462.ev.on("messages.upsert", async _0x5cd99c => {
    await MessagesUpsert(_0x2e9462, _0x5cd99c, _0x543e8d);
  });
  _0x2e9462.ev.on("contacts.update", _0x2d5fad => {
    for (let _0x14b94f of _0x2d5fad) {
      let _0x8691c7 = _0x2e9462.decodeJid(_0x14b94f.id);
      if (_0x543e8d && _0x543e8d.contacts) {
        _0x543e8d.contacts[_0x8691c7] = {
          id: _0x8691c7,
          name: _0x14b94f.notify
        };
      }
    }
  });
  _0x2e9462.ev.on("group-participants.update", async _0x170256 => {
    const {
      id: _0x3f108c,
      author: _0x225db7,
      participants: _0x4b710e,
      action: _0x21a606
    } = _0x170256;
    try {
      const _0x1a9488 = {
        key: {
          remoteJid: "status@broadcast",
          participant: "0@s.whatsapp.net"
        },
        message: {
          extendedTextMessage: {
            text: "[ 𝗚𝗿𝗼𝘂𝗽 𝗡𝗼𝘁𝗶𝗳𝗶𝗰𝗮𝘁𝗶𝗼𝗻 ]"
          }
        }
      };
      if (global.db.groups[_0x3f108c] && global.db.groups[_0x3f108c].welcome == true) {
        const _0x3b1e1a = await _0x2e9462.groupMetadata(_0x3f108c);
        let _0x2a5dfa;
        for (let _0x4b601f of _0x4b710e) {
          let _0x41dd18;
          try {
            _0x41dd18 = await _0x2e9462.profilePictureUrl(_0x4b601f, "image");
          } catch {
            _0x41dd18 = "https://telegra.ph/file/95670d63378f7f4210f03.png";
          }
          if (_0x21a606 == "add") {
            _0x2a5dfa = _0x225db7.split("").length < 1 ? "@" + _0x4b601f.split("@")[0] + " join via *link group*" : _0x225db7 !== _0x4b601f ? "@" + _0x225db7.split("@")[0] + " telah *menambahkan* @" + _0x4b601f.split("@")[0] + " kedalam grup" : "";
            let _0x5efcb7 = await welcomeBanner(_0x41dd18, _0x4b601f.split("@")[0], _0x3b1e1a.subject, "welcome");
            await _0x2e9462.sendMessage(_0x3f108c, {
              text: _0x2a5dfa,
              contextInfo: {
                mentionedJid: [_0x225db7, _0x4b601f],
                externalAdReply: {
                  thumbnail: _0x5efcb7,
                  title: "Welcome 👋",
                  body: "",
                  sourceUrl: global.linkGrup,
                  renderLargerThumbnail: true,
                  mediaType: 1
                }
              }
            });
          } else if (_0x21a606 == "remove") {
            _0x2a5dfa = _0x225db7 == _0x4b601f ? "@" + _0x4b601f.split("@")[0] + " telah *keluar* dari grup" : _0x225db7 !== _0x4b601f ? "@" + _0x225db7.split("@")[0] + " telah *mengeluarkan* @" + _0x4b601f.split("@")[0] + " dari grup" : "";
            let _0x286ba4 = await welcomeBanner(_0x41dd18, _0x4b601f.split("@")[0], _0x3b1e1a.subject, "remove");
            await _0x2e9462.sendMessage(_0x3f108c, {
              text: _0x2a5dfa,
              contextInfo: {
                mentionedJid: [_0x225db7, _0x4b601f],
                externalAdReply: {
                  thumbnail: _0x286ba4,
                  title: "Good Bye 👋",
                  body: "",
                  sourceUrl: global.linkGrup,
                  renderLargerThumbnail: true,
                  mediaType: 1
                }
              }
            });
          } else if (_0x21a606 == "promote") {
            _0x2a5dfa = _0x225db7 == _0x4b601f ? "@" + _0x4b601f.split("@")[0] + " telah *menjadi admin* grup " : _0x225db7 !== _0x4b601f ? "@" + _0x225db7.split("@")[0] + " telah *menjadikan* @" + _0x4b601f.split("@")[0] + " sebagai *admin* grup" : "";
            let _0x3b8782 = await promoteBanner(_0x41dd18, _0x4b601f.split("@")[0], "promote");
            await _0x2e9462.sendMessage(_0x3f108c, {
              text: _0x2a5dfa,
              contextInfo: {
                mentionedJid: [_0x225db7, _0x4b601f],
                externalAdReply: {
                  thumbnail: _0x3b8782,
                  title: "Promote",
                  body: "",
                  sourceUrl: global.linkGrup,
                  renderLargerThumbnail: true,
                  mediaType: 1
                }
              }
            });
          } else if (_0x21a606 == "demote") {
            _0x2a5dfa = _0x225db7 == _0x4b601f ? "@" + _0x4b601f.split("@")[0] + " telah *berhenti* menjadi *admin*" : _0x225db7 !== _0x4b601f ? "@" + _0x225db7.split("@")[0] + " telah *menghentikan* @" + _0x4b601f.split("@")[0] + " sebagai *admin* grup" : "";
            let _0x13a796 = await promoteBanner(_0x41dd18, _0x4b601f.split("@")[0], "demote");
            await _0x2e9462.sendMessage(_0x3f108c, {
              text: _0x2a5dfa,
              contextInfo: {
                mentionedJid: [_0x225db7, _0x4b601f],
                externalAdReply: {
                  thumbnail: _0x13a796,
                  title: "𝗗𝗘𝗠𝗢𝗧𝗘",
                  body: "",
                  sourceUrl: global.linkGrup,
                  renderLargerThumbnail: true,
                  mediaType: 1
                }
              }
            });
          }
        }
      }
    } catch (_0x3626a2) {}
  });
  return _0x2e9462;
}
startingBot();
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update " + __filename));
  delete require.cache[file];
  require(file);
});