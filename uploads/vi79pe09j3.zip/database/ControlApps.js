module.exports = {
  tokens: "8351220772:AAFz0BIxNWpFXV4DKBwQ-5j8ByAEpP38iJg", 
  owner: "8149953533", 
  port: "3444", // Ini Wajib Jangan Diubah
  ipvps: "https://pterodacly.privateserverr.web.id" // Jangan Diubah Nanti Eror!!
};