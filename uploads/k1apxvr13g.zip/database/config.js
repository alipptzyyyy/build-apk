module.exports = {
  tokens: "7666282979:AAECTUJ52loFk8oq7Rvt1xKv6CHLATSpK88",  // Masukin Bot token kamu
  owners: "7947851766", // Masukin ID Telegram kamu
  port: "4028", // Masukin Port panel kamu 
  ipvps: "http://danzxofficialprivate.cfxcloud.com"  //apa gk ngerti lagi bodoh masukan domain panel ke ipvps, lu jangan masukin kek gini, (https://Gunz) tapi begini (http://Gunz), yng tadinya https, jadi http, paham? kalo gk paham benturkan kepalamu ke aspal
   
};

/* WAJIB BACA !!!
 cari di nailong.js halaman 1710-1711 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/