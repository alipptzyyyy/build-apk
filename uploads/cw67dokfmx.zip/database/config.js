module.exports = {
  tokens: "8505132188:AAHBpUVg7_kM1UBmcrtOMHO5-CIx0XkhvSI",
  owners: ["8474157088"],
  ipvps: "http://panelprivateez.yayz-offline.biz.id", 
  port: 2002
};