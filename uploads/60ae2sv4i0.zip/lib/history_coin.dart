import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

/// =======================
/// MODEL
/// =======================
class CoinHistoryItem {
  final String id;
  final String username;
  final String action; // use | transfer_out | transfer_in | topup
  final String coinType; // bitcoin | lcoin
  final int amount;
  final int balanceAfterBtc;
  final int balanceAfterLtc;
  final int createdAt; // epoch ms
  final String note;

  CoinHistoryItem({
    required this.id,
    required this.username,
    required this.action,
    required this.coinType,
    required this.amount,
    required this.balanceAfterBtc,
    required this.balanceAfterLtc,
    required this.createdAt,
    required this.note,
  });

  static CoinHistoryItem fromJson(Map<String, dynamic> j) => CoinHistoryItem(
        id: (j["id"] ?? "").toString(),
        username: (j["username"] ?? "").toString(),
        action: (j["action"] ?? "").toString(),
        coinType: (j["coinType"] ?? "").toString(),
        amount: (j["amount"] is int) ? j["amount"] : int.tryParse("${j["amount"]}") ?? 0,
        balanceAfterBtc: (j["balanceAfterBtc"] is int)
            ? j["balanceAfterBtc"]
            : int.tryParse("${j["balanceAfterBtc"]}") ?? 0,
        balanceAfterLtc: (j["balanceAfterLtc"] is int)
            ? j["balanceAfterLtc"]
            : int.tryParse("${j["balanceAfterLtc"]}") ?? 0,
        createdAt: (j["createdAt"] is int)
            ? j["createdAt"]
            : int.tryParse("${j["createdAt"]}") ?? DateTime.now().millisecondsSinceEpoch,
        note: (j["note"] ?? "").toString(),
      );
}

/// =======================
/// UI SCREEN
/// =======================
class CoinHistoryPage extends StatefulWidget {
  final String username;
  const CoinHistoryPage({super.key, required this.username});

  @override
  State<CoinHistoryPage> createState() => _CoinHistoryPageState();
}

class _CoinHistoryPageState extends State<CoinHistoryPage> {
  List<CoinHistoryItem> _items = [];
  bool _loading = true;

  String _filterCoin = "all"; // all | bitcoin | lcoin
  String _filterAction = "all"; // all | use | transfer_out | transfer_in | topup

  @override
  void initState() {
    super.initState();
    _fetchHistoryFromServer();
  }

  // 🔥 Fungsi Baru Nembak Ke Server (Bukan Lokal Lagi)
  Future<void> _fetchHistoryFromServer() async {
    setState(() => _loading = true);
    
    try {
      final response = await http.get(
        Uri.parse("http://supermanxnay.xyzraa.biz.id:4136/getHistory?username=${widget.username}")
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final List rawList = data['history'] ?? [];
          final items = rawList
              .map((m) => CoinHistoryItem.fromJson(Map<String, dynamic>.from(m)))
              .toList();
              
          // Urutkan dari yang terbaru
          items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
          
          setState(() {
            _items = items;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching history: $e");
    } finally {
      setState(() => _loading = false);
    }
  }

  String _labelCoin(String coinType) => coinType == "bitcoin" ? "BTC" : "LTC";

  String _labelAction(String action) {
    switch (action) {
      case "use": return "Launch Attack";
      case "transfer_out": return "Transfer Out";
      case "transfer_in": return "Transfer In";
      case "topup": return "Top Up";
      default: return action;
    }
  }

  IconData _iconAction(String action, String coinType) {
    if (coinType == "bitcoin") return Icons.currency_bitcoin;
    return Icons.monetization_on;
  }

  List<CoinHistoryItem> get _filtered {
    return _items.where((e) {
      final okCoin = _filterCoin == "all" || e.coinType == _filterCoin;
      final okAction = _filterAction == "all" || e.action == _filterAction;
      return okCoin && okAction;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F0F0F),
        title: const Text("History Transaction", style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.amber))
          : RefreshIndicator(
              onRefresh: _fetchHistoryFromServer,
              color: Colors.amber,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _buildFilters(),
                  const SizedBox(height: 12),
                  if (_filtered.isEmpty)
                    const Padding(
                      padding: EdgeInsets.only(top: 40),
                      child: Center(
                        child: Text(
                          "No Transaction History",
                          style: TextStyle(color: Colors.white70),
                        ),
                      ),
                    )
                  else
                    ..._filtered.map(_buildItemCard),
                  const SizedBox(height: 30),
                ],
              ),
            ),
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0F0F),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Filter", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          _chipGroup(
            title: "Coin",
            options: const [("all", "ALL"), ("bitcoin", "B-COIN"), ("lcoin", "L-COIN")],
            value: _filterCoin,
            onChanged: (v) => setState(() => _filterCoin = v),
          ),
          const SizedBox(height: 10),
          _chipGroup(
            title: "Action",
            options: const [
              ("all", "ALL"),
              ("use", "ATTACK"),
              ("transfer_out", "OUT"),
              ("transfer_in", "IN"),
              ("topup", "TOPUP"),
            ],
            value: _filterAction,
            onChanged: (v) => setState(() => _filterAction = v),
          ),
        ],
      ),
    );
  }

  Widget _chipGroup({
    required String title,
    required List<(String, String)> options,
    required String value,
    required void Function(String) onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: options.map((opt) {
            final selected = value == opt.$1;
            return ChoiceChip(
              label: Text(opt.$2),
              selected: selected,
              selectedColor: Colors.amber,
              labelStyle: TextStyle(color: selected ? Colors.black : Colors.white70, fontSize: 11, fontWeight: FontWeight.bold),
              backgroundColor: const Color(0xFF1A1A1A),
              onSelected: (_) => onChanged(opt.$1),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildItemCard(CoinHistoryItem item) {
    final dt = DateTime.fromMillisecondsSinceEpoch(item.createdAt);
    final dateStr =
        "${dt.day.toString().padLeft(2, '0')}-${dt.month.toString().padLeft(2, '0')}-${dt.year}  "
        "${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}";

    final coinLabel = _labelCoin(item.coinType);
    final actionLabel = _labelAction(item.action);

    final sign = (item.action == "use" || item.action == "transfer_out") ? "-" : "+";
    final amountText = "$sign${item.amount} $coinLabel";
    final colorStatus = sign == "-" ? Colors.redAccent : Colors.greenAccent;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF151515),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: colorStatus.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(_iconAction(item.action, item.coinType), color: colorStatus),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  actionLabel,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                ),
                if (item.note.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(item.note, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                ],
                const SizedBox(height: 6),
                Text(dateStr, style: const TextStyle(color: Colors.white38, fontSize: 10)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                amountText,
                style: TextStyle(color: colorStatus, fontWeight: FontWeight.w900, fontSize: 16),
              ),
              const SizedBox(height: 4),
              Text(
                "Sisa: ${item.coinType == 'bitcoin' ? item.balanceAfterBtc : item.balanceAfterLtc}",
                style: const TextStyle(color: Colors.white70, fontSize: 11),
              ),
            ],
          ),
        ],
      ),
    );
  }
}