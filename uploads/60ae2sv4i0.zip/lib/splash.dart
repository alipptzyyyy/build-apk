import 'dart:async'; // Impor library untuk Timer
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  bool _fadeOutStarted = false;
  double _videoProgress = 0.0;
  bool _isNavigating = false;
  Timer? _videoTimeoutTimer; // Timer untuk handle video yang tidak berhasil dimuat

  // WARNA TEMA CYBERPUNK (Sama kayak Dashboard)
  final Color neonRed = const Color(0xFFFF1744);
  final Color darkBg = const Color(0xFF050505);

  @override
  void initState() {
    super.initState();

    // 1. Inisialisasi AnimationController di sini agar selalu tersedia
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    // 2. Mulai timer untuk timeout
    _videoTimeoutTimer = Timer(const Duration(seconds: 10), () {
      // Jika setelah 10 detik video belum siap, otomatis skip
      if (!_isNavigating) {
        _skipIntro();
      }
    });

    // 3. Inisialisasi dan coba muat video
    _videoController = VideoPlayerController.asset("assets/videos/banner.mp4")
      ..initialize().then((_) {
        // Jika berhasil diinisialisasi, batalkan timer
        _videoTimeoutTimer?.cancel();
        setState(() {});
        _videoController.setLooping(false);
        _videoController.play();

        _videoController.addListener(() {
          if (_videoController.value.isInitialized) {
            final position = _videoController.value.position;
            final duration = _videoController.value.duration;

            if (duration != null && duration.inMilliseconds > 0) {
              setState(() {
                _videoProgress = position.inMilliseconds / duration.inMilliseconds;
              });
            }

            if (duration != null &&
                position >= duration - const Duration(seconds: 1) &&
                !_fadeOutStarted) {
              _fadeOutStarted = true;
              _fadeController.forward().then((_) {
                _navigateToDashboard();
              });
            }

            if (position >= duration && !_isNavigating) {
              _navigateToDashboard();
            }
          }
        });
      }).catchError((error) {
        // 4. Tangani error jika video gagal dimuat
        print("Error loading video: $error");
        _videoTimeoutTimer?.cancel(); // Batalkan timer juga saat error
        // Langsung lanjutkan ke dashboard setelah delay singkat
        Future.delayed(const Duration(milliseconds: 500), () {
          if (!_isNavigating) {
            _skipIntro();
          }
        });
      });
  }

  // FUNGSI INI 100% AMAN TIDAK ADA PARAMETER YANG DIHAPUS
  void _navigateToDashboard() {
    _isNavigating = true;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  void _skipIntro() {
    if (_isNavigating) return;

    _videoTimeoutTimer?.cancel(); // Batalkan timer saat skip manual
    _isNavigating = true;
    _fadeOutStarted = true;

    // Hentikan video jika sedang diputar
    if (_videoController.value.isInitialized) {
      _videoController.pause();
    }

    _fadeController.forward().then((_) {
      _navigateToDashboard();
    });
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _videoTimeoutTimer?.cancel(); // Penting: batalkan timer untuk mencegah memory leak
    super.dispose();
  }

  // ==========================================
  // UI VISUAL CYBERPUNK (BAJUNYA AJA YANG DIGANTI)
  // ==========================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: GestureDetector(
        onTap: _skipIntro,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // 1. GRID BACKGROUND HACKER STYLE
            Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: GridPainter(color: neonRed)))),
            
            // 2. VIDEO PLAYER DENGAN FRAME CYBERPUNK
            if (_videoController.value.isInitialized)
              Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.85,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    border: Border.all(
                      color: neonRed.withOpacity(0.8),
                      width: 2.0, // Kaku dan tegas
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: neonRed.withOpacity(0.3),
                        blurRadius: 30,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      AspectRatio(
                        aspectRatio: _videoController.value.aspectRatio,
                        child: VideoPlayer(_videoController),
                      ),
                      // Efek Scanline TV di atas video
                      Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: ScanlinePainter()))),
                      // Label status
                      Positioned(
                        top: 8, left: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          color: neonRed.withOpacity(0.9),
                          child: const Text("BY KAELL-XZ //", style: TextStyle(color: Colors.black, fontSize: 10, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                        ),
                      )
                    ],
                  ),
                ),
              )
            else
              Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(neonRed),
                ),
              ),

            // 3. TEKS, LOADING BAR, & TOMBOL SKIP
            Positioned(
              bottom: 80,
              left: 0,
              right: 0,
              child: Column(
                children: [
                  Text(
                    "NATUROM DEMONTO",
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'monospace', // Font hacker
                      color: Colors.white,
                      letterSpacing: 4,
                      shadows: [
                        Shadow(color: neonRed, blurRadius: 15),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "SEDANG MENYIAPKAN ALAT PENYERANG...",
                    style: TextStyle(
                      fontSize: 10,
                      fontFamily: 'monospace',
                      color: Colors.white54,
                      letterSpacing: 2,
                    ),
                  ),
                  
                  const SizedBox(height: 30),
                  
                  // Loading Bar ala Terminal Hacker
                  Container(
                    width: MediaQuery.of(context).size.width * 0.7,
                    height: 6,
                    decoration: BoxDecoration(
                      border: Border.all(color: neonRed.withOpacity(0.5)),
                      color: Colors.black,
                    ),
                    child: LinearProgressIndicator(
                      value: _videoProgress,
                      backgroundColor: Colors.transparent,
                      valueColor: AlwaysStoppedAnimation<Color>(neonRed),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    "LOAD: ${(_videoProgress * 100).toStringAsFixed(0)}%",
                    style: TextStyle(color: neonRed, fontFamily: 'monospace', fontSize: 10, fontWeight: FontWeight.bold),
                  ),

                  const SizedBox(height: 30),
                  
                  // Tombol Skip (Bypass)
                  OutlinedButton(
                    onPressed: _skipIntro,
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: neonRed.withOpacity(0.6), width: 1.5),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)), // Kotak tajam
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      backgroundColor: Colors.black.withOpacity(0.5),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.fast_forward, color: neonRed, size: 16),
                        const SizedBox(width: 8),
                        Text(
                          "SKIP VIDEO INTRO",
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'monospace',
                            color: neonRed,
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Fade out effect
            if (_fadeOutStarted)
              FadeTransition(
                opacity: _fadeController.drive(Tween(begin: 1.0, end: 0.0)),
                child: Container(color: Colors.black),
              ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// CUSTOM PAINTERS (BIAR TAMPILAN MEWAH CYBERPUNK)
// ==========================================

class GridPainter extends CustomPainter {
  final Color color;
  GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.05)
      ..strokeWidth = 1.0;

    const double gridSize = 40.0;

    for (double x = 0; x < size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ScanlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black.withOpacity(0.4)
      ..strokeWidth = 2.0;

    for (double i = 0; i < size.height; i += 4.0) {
      canvas.drawLine(Offset(0, i), Offset(size.width, i), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

