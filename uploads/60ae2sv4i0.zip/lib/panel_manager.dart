import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

class PanelManagerPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const PanelManagerPage({super.key, required this.sessionKey, required this.role});

  @override
  State<PanelManagerPage> createState() => _PanelManagerPageState();
}

class _PanelManagerPageState extends State<PanelManagerPage> with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  
  final Color bloodRed = const Color(0xFFB71C1C);
  final Color neonRed = const Color(0xFFFF1744);
  final Color darkBg = const Color(0xFF050505);
  final Color panelBg = const Color(0xFF111111);

  late bool isOwner;

  @override
  void initState() {
    super.initState();
    isOwner = widget.role.toLowerCase().trim() == 'owner';
  }

  void _switchTab(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Menu items
    final List<Map<String, dynamic>> menuItems = [
      {"icon": Icons.add_to_queue, "label": "NEW SERVER"},
      {"icon": Icons.dns_outlined, "label": "SERVER NODE"},
      if (isOwner) {"icon": Icons.admin_panel_settings, "label": "NEW ADMIN"},
      if (isOwner) {"icon": Icons.people_outline, "label": "ADMIN LIST"},
    ];

    return Scaffold(
      backgroundColor: darkBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("NATUROM // CPANEL", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2, fontFamily: 'monospace')),
            Text("ROOT ACCESS GRANTED", style: TextStyle(color: neonRed, fontSize: 10, letterSpacing: 1.5, fontFamily: 'monospace')),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(border: Border.all(color: neonRed), color: bloodRed.withOpacity(0.2)),
            child: Row(
              children: [
                Icon(Icons.circle, color: neonRed, size: 8),
                const SizedBox(width: 6),
                const Text("LIVE", style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 10, fontWeight: FontWeight.bold)),
              ],
            ),
          )
        ],
      ),
      body: Column(
        children: [
          // --- CUSTOM CYBER NAVIGATION ---
          Container(
            height: 60,
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: menuItems.length,
              itemBuilder: (context, index) {
                bool isActive = _currentIndex == index;
                return GestureDetector(
                  onTap: () => _switchTab(index),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: const EdgeInsets.only(right: 12),
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    decoration: BoxDecoration(
                      color: isActive ? bloodRed.withOpacity(0.3) : panelBg,
                      border: Border.all(color: isActive ? neonRed : Colors.white12, width: isActive ? 1.5 : 1),
                      borderRadius: BorderRadius.circular(4), // Kaku/Cyberpunk style
                    ),
                    child: Row(
                      children: [
                        Icon(menuItems[index]['icon'], color: isActive ? Colors.white : Colors.white54, size: 16),
                        const SizedBox(width: 8),
                        Text(
                          menuItems[index]['label'],
                          style: TextStyle(
                            color: isActive ? Colors.white : Colors.white54,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'monospace',
                            fontSize: 12,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          
          const Divider(color: Colors.white12, height: 1),

          // --- MAIN CONTENT AREA WITH ANIMATION ---
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              transitionBuilder: (Widget child, Animation<double> animation) {
                return FadeTransition(
                  opacity: animation,
                  child: SlideTransition(
                    position: Tween<Offset>(begin: const Offset(0.05, 0), end: Offset.zero).animate(animation),
                    child: child,
                  ),
                );
              },
              child: _buildCurrentView(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentView() {
    switch (_currentIndex) {
      case 0:
        return _TabCreateServer(key: const ValueKey(0), sessionKey: widget.sessionKey, onSuccess: () => _switchTab(1));
      case 1:
        return _TabListServers(key: const ValueKey(1));
      case 2:
        return _TabCreateAdmin(key: const ValueKey(2), sessionKey: widget.sessionKey, onSuccess: () => _switchTab(3));
      case 3:
        return _TabListAdmins(key: const ValueKey(3));
      default:
        return const SizedBox.shrink();
    }
  }
}

// =======================================================
// WIDGET HELPER: DIALOG MEWAH CREATE SUCCESS
// =======================================================
void _showCyberResultDialog(BuildContext context, String title, Map<String, String> dataItems, Color themeColor) {
  showDialog(
    context: context,
    builder: (_) => BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
      child: Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFF0A0A0A),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: themeColor.withOpacity(0.8), width: 2),
            boxShadow: [BoxShadow(color: themeColor.withOpacity(0.3), blurRadius: 30)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.check_box, color: themeColor, size: 24),
                  const SizedBox(width: 12),
                  Text(title, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'monospace', letterSpacing: 1)),
                ],
              ),
              const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Divider(color: Colors.white24)),
              ...dataItems.entries.map((e) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("> ", style: TextStyle(color: themeColor, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                        Expanded(
                          child: RichText(
                            text: TextSpan(
                              style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
                              children: [
                                TextSpan(text: "${e.key}: ", style: const TextStyle(color: Colors.white54)),
                                TextSpan(text: e.value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  )),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 45,
                child: ElevatedButton.icon(
                  onPressed: () {
                    final copyText = dataItems.entries.map((e) => "${e.key}: ${e.value}").join("\n");
                    Clipboard.setData(ClipboardData(text: copyText));
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text("CREDENTIALS COPIED TO CLIPBOARD.", style: TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                      backgroundColor: Colors.green.shade900, behavior: SnackBarBehavior.floating,
                    ));
                  },
                  icon: const Icon(Icons.copy, color: Colors.white, size: 16),
                  label: const Text("COPY DATA", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'monospace', letterSpacing: 2)),
                  style: ElevatedButton.styleFrom(backgroundColor: themeColor.withOpacity(0.8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

// ================= TAB 1: CREATE SERVER =================
class _TabCreateServer extends StatefulWidget {
  final String sessionKey;
  final VoidCallback onSuccess;
  const _TabCreateServer({super.key, required this.sessionKey, required this.onSuccess});
  @override
  State<_TabCreateServer> createState() => _TabCreateServerState();
}

class _TabCreateServerState extends State<_TabCreateServer> {
  final _userCtrl = TextEditingController();
  double _ram = 1;
  bool _unlimited = false;
  bool _loading = false;

  final Color neonRed = const Color(0xFFFF1744);

  Future<void> _deploy() async {
    if (_userCtrl.text.isEmpty) return;
    setState(() => _loading = true);
    try {
      final res = await http.post(
        Uri.parse("http://supermanxnay.xyzraa.biz.id:4136/api/ptero/createServer"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"key": widget.sessionKey, "username": _userCtrl.text, "unlimited": _unlimited, "ram": _ram.toInt()}),
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _showCyberResultDialog(context, "SERVER DEPLOYED", {
          "URL": data['data']['login'],
          "USER": data['data']['username'],
          "PASS": data['data']['password'],
          "RAM": data['data']['ram'].toString(),
          "CPU": data['data']['cpu'].toString(),
        }, Colors.greenAccent);
        _userCtrl.clear();
        widget.onSuccess(); 
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'], style: TextStyle(fontFamily: 'monospace')), backgroundColor: Colors.red));
      }
    } catch (_) {}
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(color: const Color(0xFF0A0A0A), border: Border.all(color: Colors.white12), borderRadius: BorderRadius.circular(8)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("// TARGET USERNAME", style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontWeight: FontWeight.bold, fontSize: 12)),
              const SizedBox(height: 12),
              TextField(
                controller: _userCtrl, style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.terminal, color: neonRed),
                  hintText: "Enter codename...", hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'monospace'),
                  filled: true, fillColor: Colors.black, 
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: Colors.white12)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: Colors.white12)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: neonRed)),
                ),
              ),
              const SizedBox(height: 30),
              
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("// UNLIMITED RESOURCES", style: TextStyle(color: Colors.amber, fontFamily: 'monospace', fontWeight: FontWeight.bold, fontSize: 12)),
                  Switch(value: _unlimited, activeColor: Colors.amber, inactiveTrackColor: Colors.white12, onChanged: (v) => setState(() => _unlimited = v)),
                ],
              ),
              
              if (!_unlimited) ...[
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("// RAM ALLOCATION", style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontSize: 12, fontWeight: FontWeight.bold)),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(color: neonRed.withOpacity(0.2), border: Border.all(color: neonRed)),
                      child: Text("${_ram.toInt()} GB", style: TextStyle(color: neonRed, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    trackHeight: 2,
                    thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                    overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
                  ),
                  child: Slider(value: _ram, min: 1, max: 64, divisions: 63, activeColor: neonRed, inactiveColor: Colors.white12, onChanged: (v) => setState(() => _ram = v)),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 30),
        SizedBox(
          height: 55,
          child: ElevatedButton(
            onPressed: _loading ? null : _deploy,
            style: ElevatedButton.styleFrom(
              backgroundColor: neonRed.withOpacity(0.8), 
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: BorderSide(color: neonRed)),
              shadowColor: neonRed.withOpacity(0.5), elevation: 10,
            ),
            child: _loading 
              ? SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) 
              : const Text("EXECUTE DEPLOYMENT", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2, fontFamily: 'monospace')),
          ),
        )
      ],
    );
  }
}

// ================= TAB 2: LIST SERVERS =================
class _TabListServers extends StatefulWidget {
  const _TabListServers({super.key});
  @override
  State<_TabListServers> createState() => _TabListServersState();
}
class _TabListServersState extends State<_TabListServers> {
  List<dynamic> _servers = [];
  bool _loading = true;
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = "";
  final Color neonRed = const Color(0xFFFF1744);

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() => _loading = true);
    try {
      final res = await http.get(Uri.parse("http://supermanxnay.xyzraa.biz.id:4136/api/ptero/listServers"));
      final data = jsonDecode(res.body);
      if (data['success']) setState(() => _servers = data['data']);
    } catch (_) {}
    setState(() => _loading = false);
  }

  Future<void> _delete(int id) async {
    await http.post(Uri.parse("http://supermanxnay.xyzraa.biz.id:4136/api/ptero/deleteServer"), headers: {"Content-Type": "application/json"}, body: jsonEncode({"id": id}));
    _fetch();
  }

  void _confirmDelete(int id, String name) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF0A0A0A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: BorderSide(color: neonRed)),
        title: Row(
          children: [
            Icon(Icons.warning, color: neonRed),
            const SizedBox(width: 10),
            const Text("SYSTEM WARNING", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
          ],
        ),
        content: Text("CONFIRM DESTRUCTION OF SERVER NODE:\n> $name\n\nTHIS PROCESS IS IRREVERSIBLE.", style: const TextStyle(color: Colors.white70, fontFamily: 'monospace', fontSize: 12)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("ABORT", style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontWeight: FontWeight.bold))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: neonRed, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
            onPressed: () { Navigator.pop(ctx); _delete(id); },
            child: const Text("DESTROY", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
          ),
        ],
      ),
    );
  }

  List<dynamic> get _filteredServers {
    if (_searchQuery.isEmpty) return _servers;
    return _servers.where((srv) => srv['attributes']['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase())).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            controller: _searchCtrl,
            style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
            onChanged: (val) => setState(() => _searchQuery = val),
            decoration: InputDecoration(
              hintText: "SEARCH NODE...", hintStyle: const TextStyle(color: Colors.white38, fontFamily: 'monospace'),
              prefixIcon: const Icon(Icons.search, color: Colors.white54),
              filled: true, fillColor: Colors.black,
              contentPadding: const EdgeInsets.symmetric(vertical: 0),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: Colors.white12)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: neonRed)),
            ),
          ),
        ),
        Expanded(
          child: _loading 
            ? Center(child: CircularProgressIndicator(color: neonRed))
            : RefreshIndicator(
                onRefresh: _fetch, color: neonRed, backgroundColor: Colors.black,
                child: _filteredServers.isEmpty 
                  ? const Center(child: Text("NO NODES FOUND IN DATABASE.", style: TextStyle(color: Colors.white54, fontFamily: 'monospace')))
                  : ListView.builder(
                      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 120),
                      itemCount: _filteredServers.length,
                      itemBuilder: (ctx, i) {
                        final srv = _filteredServers[i]['attributes'];
                        final status = srv['pteroStatus']?.toString().toLowerCase() ?? 'unknown';
                        final Color statusColor = status == 'running' ? Colors.greenAccent : (status == 'starting' ? Colors.amber : Colors.redAccent);
                        
                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(color: const Color(0xFF0A0A0A), borderRadius: BorderRadius.circular(4), border: Border.all(color: Colors.white12)),
                          child: Stack(
                            children: [
                              // Garis status di sebelah kiri
                              Positioned(left: 0, top: 0, bottom: 0, child: Container(width: 4, color: statusColor)),
                              ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                                title: Text(srv['name'].toString().toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'monospace')),
                                subtitle: Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Text("ID:${srv['id']} | NODE:${srv['node']}\nSTATUS: ${status.toUpperCase()}", style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'monospace', height: 1.5)),
                                ),
                                trailing: IconButton(
                                  icon: Icon(Icons.delete_outline, color: neonRed),
                                  onPressed: () => _confirmDelete(srv['id'], srv['name']),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
              ),
        ),
      ],
    );
  }
}

// ================= TAB 3: CREATE ADMIN =================
class _TabCreateAdmin extends StatefulWidget {
  final String sessionKey;
  final VoidCallback onSuccess;
  const _TabCreateAdmin({super.key, required this.sessionKey, required this.onSuccess});
  @override
  State<_TabCreateAdmin> createState() => _TabCreateAdminState();
}
class _TabCreateAdminState extends State<_TabCreateAdmin> {
  final _userCtrl = TextEditingController();
  bool _loading = false;
  final Color neonAmber = Colors.amberAccent;

  Future<void> _deploy() async {
    if (_userCtrl.text.isEmpty) return;
    setState(() => _loading = true);
    try {
      final res = await http.post(
        Uri.parse("http://supermanxnay.xyzraa.biz.id:4136/api/ptero/createAdmin"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"key": widget.sessionKey, "username": _userCtrl.text}),
      );
      final data = jsonDecode(res.body);
      if (data['success']) {
        _showCyberResultDialog(context, "ROOT ADMIN CREATED", {
          "URL": data['data']['login'],
          "USER": data['data']['username'],
          "PASS": data['data']['password'],
        }, neonAmber);
        _userCtrl.clear();
        widget.onSuccess(); 
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'], style: TextStyle(fontFamily: 'monospace')), backgroundColor: Colors.red));
      }
    } catch (_) {}
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(color: const Color(0xFF0A0A0A), border: Border.all(color: Colors.white12), borderRadius: BorderRadius.circular(4)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("// MASTER ADMIN USERNAME", style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontWeight: FontWeight.bold, fontSize: 12)),
              const SizedBox(height: 12),
              TextField(
                controller: _userCtrl, style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.security, color: neonAmber),
                  hintText: "Enter root username...", hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'monospace'),
                  filled: true, fillColor: Colors.black, 
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: Colors.white12)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: Colors.white12)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: neonAmber)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 30),
        SizedBox(
          height: 55,
          child: ElevatedButton(
            onPressed: _loading ? null : _deploy,
            style: ElevatedButton.styleFrom(
              backgroundColor: neonAmber.withOpacity(0.8), 
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: BorderSide(color: neonAmber)),
            ),
            child: _loading 
              ? SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2)) 
              : const Text("ELEVATE PRIVILEGES", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, letterSpacing: 2, fontFamily: 'monospace')),
          ),
        )
      ],
    );
  }
}

// ================= TAB 4: LIST ADMINS =================
class _TabListAdmins extends StatefulWidget {
  const _TabListAdmins({super.key});
  @override
  State<_TabListAdmins> createState() => _TabListAdminsState();
}
class _TabListAdminsState extends State<_TabListAdmins> {
  List<dynamic> _admins = [];
  bool _loading = true;
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = "";
  final Color neonAmber = Colors.amberAccent;

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() => _loading = true);
    try {
      final res = await http.get(Uri.parse("http://supermanxnay.xyzraa.biz.id:4136/api/ptero/listAdmins"));
      final data = jsonDecode(res.body);
      if (data['success']) setState(() => _admins = data['data']);
    } catch (_) {}
    setState(() => _loading = false);
  }

  Future<void> _delete(int id) async {
    await http.post(Uri.parse("http://supermanxnay.xyzraa.biz.id:4136/api/ptero/deleteUser"), headers: {"Content-Type": "application/json"}, body: jsonEncode({"id": id}));
    _fetch();
  }

  void _confirmDelete(int id, String username) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF0A0A0A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: BorderSide(color: neonAmber)),
        title: Row(
          children: [
            Icon(Icons.warning, color: neonAmber),
            const SizedBox(width: 10),
            const Text("REVOKE ACCESS", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
          ],
        ),
        content: Text("CONFIRM PRIVILEGE REVOCATION FOR:\n> $username", style: const TextStyle(color: Colors.white70, fontFamily: 'monospace', fontSize: 12)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("ABORT", style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontWeight: FontWeight.bold))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: neonAmber, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
            onPressed: () { Navigator.pop(ctx); _delete(id); },
            child: const Text("REVOKE", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
          ),
        ],
      ),
    );
  }

  List<dynamic> get _filteredAdmins {
    if (_searchQuery.isEmpty) return _admins;
    return _admins.where((usr) => usr['attributes']['username'].toString().toLowerCase().contains(_searchQuery.toLowerCase())).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            controller: _searchCtrl,
            style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
            onChanged: (val) => setState(() => _searchQuery = val),
            decoration: InputDecoration(
              hintText: "SEARCH ADMIN...", hintStyle: const TextStyle(color: Colors.white38, fontFamily: 'monospace'),
              prefixIcon: const Icon(Icons.search, color: Colors.white54),
              filled: true, fillColor: Colors.black,
              contentPadding: const EdgeInsets.symmetric(vertical: 0),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: Colors.white12)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: neonAmber)),
            ),
          ),
        ),
        Expanded(
          child: _loading 
            ? Center(child: CircularProgressIndicator(color: neonAmber))
            : RefreshIndicator(
                onRefresh: _fetch, color: neonAmber, backgroundColor: Colors.black,
                child: _filteredAdmins.isEmpty 
                  ? const Center(child: Text("NO ROOT ADMINS FOUND.", style: TextStyle(color: Colors.white54, fontFamily: 'monospace')))
                  : ListView.builder(
                      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 120),
                      itemCount: _filteredAdmins.length,
                      itemBuilder: (ctx, i) {
                        final usr = _filteredAdmins[i]['attributes'];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(color: const Color(0xFF0A0A0A), borderRadius: BorderRadius.circular(4), border: Border.all(color: Colors.white12)),
                          child: Stack(
                            children: [
                              Positioned(left: 0, top: 0, bottom: 0, child: Container(width: 4, color: neonAmber)),
                              ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                                title: Text(usr['username'].toString().toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'monospace')),
                                subtitle: Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Text("ID:${usr['id']} | EMAIL:${usr['email']}\nPRIVILEGE: ROOT", style: TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'monospace', height: 1.5)),
                                ),
                                trailing: IconButton(
                                  icon: Icon(Icons.block, color: Colors.redAccent),
                                  onPressed: () => _confirmDelete(usr['id'], usr['username']),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
              ),
        ),
      ],
    );
  }
}

