import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui'; 
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'splash.dart';

const String baseUrl = "http://supermanxnay.xyzraa.biz.id:4136";

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  // Animation Controllers
  late AnimationController _entryController;
  late AnimationController _gridController;
  late AnimationController _pulseController;
  
  // Staggered Animations
  late Animation<double> _fadeAnim;
  late Animation<Offset> _logoSlide;
  late Animation<Offset> _textSlide;
  late Animation<Offset> _formSlide;
  late Animation<Offset> _buttonSlide;

  final Color bloodRed = const Color(0xFFB71C1C); // Merah Gelap Premium
  final Color neonRed = const Color(0xFFFF1744); // Merah Nyala

  @override
  void initState() {
    super.initState();
    _initAnim();
    initLogin();
  }

  void _initAnim() {
    // 1. Controller untuk Intro (Masuk layar)
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..forward();

    // 2. Controller untuk Grid Background gerak terus
    _gridController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();

    // 3. Controller untuk detak Logo (Pulse)
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _fadeAnim = CurvedAnimation(parent: _entryController, curve: Curves.easeOut);

    _logoSlide = Tween<Offset>(begin: const Offset(0, -0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _entryController, curve: const Interval(0.0, 0.5, curve: Curves.easeOutBack)),
    );

    _textSlide = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
      CurvedAnimation(parent: _entryController, curve: const Interval(0.2, 0.7, curve: Curves.easeOutBack)),
    );

    _formSlide = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
      CurvedAnimation(parent: _entryController, curve: const Interval(0.4, 0.8, curve: Curves.easeOutBack)),
    );

    _buttonSlide = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _entryController, curve: const Interval(0.6, 1.0, curve: Curves.easeOutBack)),
    );
  }

  // ==========================================
  // LOGIC TIDAK DIUBAH SAMA SEKALI
  // ==========================================
  Future<void> initLogin() async {
    androidId = await getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: savedUser,
                password: savedPass,
                role: data['role'],
                sessionKey: data['key'],
                expiredDate: data['expiredDate'],
                listBug: (data['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                listDoos: (data['listDDoS'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                news: (data['news'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
              ),
            ),
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;
    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
          "version": "6.0",
        },
      );

      final validData = jsonDecode(validate.body);
      if (validData['oldVer'] == true) {
        _showCyberPopup(
          title: "UPDATE REQUIRED",
          message: "SYSTEM OUTDATED.\nPLEASE UPGRADE TO LATEST BUILD.",
          color: Colors.amber,
          showContact: true,
        );
      } else if (validData['expired'] == true) {
        _showCyberPopup(
          title: "ACCESS DENIED",
          message: "SUBSCRIPTION EXPIRED.\nRENEWAL REQUIRED.",
          color: Colors.amber,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        _showCyberPopup(
          title: "AUTH FAILED",
          message: "INVALID CREDENTIALS DETECTED.",
          color: neonRed,
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => SplashScreen(
              username: username,
              password: password,
              role: validData['role'],
              sessionKey: validData['key'],
              expiredDate: validData['expiredDate'],
              listBug: (validData['listBug'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              listDoos: (validData['listDDoS'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              news: (validData['news'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
            ),
          ),
        );
      }
    } catch (e) {
      _showCyberPopup(
        title: "CONNECTION LOST",
        message: "FAILED TO REACH NEURAL NETWORK.\nCHECK CONNECTION.",
        color: Colors.white54,
      );
    }

    setState(() => isLoading = false);
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  // Pop-up gaya Hacker Alert
  void _showCyberPopup({
    required String title,
    required String message,
    required Color color,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: AlertDialog(
          backgroundColor: const Color(0xFF0A0A0A),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: color.withOpacity(0.5), width: 1.5)),
          title: Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: color, size: 28),
              const SizedBox(width: 12),
              Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontFamily: 'monospace', fontSize: 16)),
            ],
          ),
          content: Text(message, style: const TextStyle(color: Colors.white70, fontFamily: 'monospace', fontSize: 13)),
          actions: [
            if (showContact)
              TextButton(
                onPressed: () async {
                  _openUrl("https://t.me/hamzytzy");
                },
                child: Text("CONTACT ADMIN", style: TextStyle(color: neonRed, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
              ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("DISMISS", style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _entryController.dispose();
    _gridController.dispose();
    _pulseController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final inputWidth = MediaQuery.of(context).size.width * 0.85;

    return Scaffold(
      backgroundColor: const Color(0xFF050505), // Dark mode pekat
      body: Stack(
        children: [
          // 1. ANIMATED GRID BACKGROUND
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _gridController,
              builder: (context, child) {
                return CustomPaint(
                  painter: CyberGridPainter(
                    offset: _gridController.value * 40,
                    color: bloodRed.withOpacity(0.15),
                  ),
                );
              },
            ),
          ),

          // 2. VIGNETTE OVERLAY (Gelap di pinggir)
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 1.2,
                  colors: [
                    Colors.transparent,
                    const Color(0xFF000000).withOpacity(0.7),
                    const Color(0xFF000000),
                  ],
                  stops: const [0.3, 0.8, 1.0],
                ),
              ),
            ),
          ),
          
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // --- LOGO ANIMATION (Pulse + Slide) ---
                    SlideTransition(
                      position: _logoSlide,
                      child: FadeTransition(
                        opacity: _fadeAnim,
                        child: ScaleTransition(
                          scale: Tween<double>(begin: 0.95, end: 1.05).animate(
                            CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
                          ),
                          child: Hero(
                            tag: "logo",
                            child: Container(
                              width: 110,
                              height: 110,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(color: bloodRed.withOpacity(0.8), width: 2),
                                boxShadow: [
                                  BoxShadow(
                                    color: neonRed.withOpacity(0.4),
                                    blurRadius: 30,
                                    spreadRadius: 5,
                                  ),
                                ],
                              ),
                              child: ClipOval(
                                child: Image.asset(
                                  'assets/images/logo.jpg',
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    color: const Color(0xFF111111),
                                    child: Icon(Icons.security, color: neonRed, size: 50),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),

                    // --- TEXT WELCOME HACKER ---
                    SlideTransition(
                      position: _textSlide,
                      child: FadeTransition(
                        opacity: _fadeAnim,
                        child: Column(
                          children: [
                            Text(
                              "SYSTEM ACCESS",
                              style: TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 4.0,
                                fontFamily: 'monospace', // Terminal style
                                color: Colors.white,
                                shadows: [Shadow(color: neonRed, blurRadius: 10)],
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              "AUTHENTICATE IDENTITY TO PROCEED",
                              style: TextStyle(
                                color: Colors.white54, 
                                fontSize: 11,
                                fontFamily: 'monospace',
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),

                    // --- FORM SMOKED GLASS ---
                    SlideTransition(
                      position: _formSlide,
                      child: FadeTransition(
                        opacity: _fadeAnim,
                        child: GlassTerminalCard(
                          width: inputWidth,
                          child: Form(
                            key: _formKey,
                            child: Column(
                              children: [
                                _cyberInput(
                                  controller: userController,
                                  label: "CODENAME",
                                  icon: Icons.terminal_rounded,
                                  validatorMsg: "CODENAME REQUIRED",
                                ),
                                const SizedBox(height: 20),
                                _cyberInput(
                                  controller: passController,
                                  label: "PASSPHRASE",
                                  icon: Icons.fingerprint_rounded,
                                  isPassword: true,
                                  validatorMsg: "PASSPHRASE REQUIRED",
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),

                    // --- LOGIN BUTTON CYBERPUNK ---
                    SlideTransition(
                      position: _buttonSlide,
                      child: FadeTransition(
                        opacity: _fadeAnim,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut,
                          width: isLoading ? 65 : inputWidth,
                          height: 55,
                          child: ElevatedButton(
                            onPressed: isLoading ? null : login,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: isLoading ? Colors.transparent : bloodRed.withOpacity(0.9),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(isLoading ? 30 : 8),
                                side: BorderSide(color: neonRed, width: isLoading ? 2 : 1),
                              ),
                              shadowColor: neonRed.withOpacity(0.5),
                              elevation: 10,
                              padding: EdgeInsets.zero,
                            ),
                            child: isLoading
                                ? SizedBox(
                                    width: 24,
                                    height: 24,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2.5,
                                      valueColor: AlwaysStoppedAnimation(neonRed),
                                    ),
                                  )
                                : const Text(
                                    "INITIALIZE",
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 4.0,
                                      fontFamily: 'monospace',
                                      color: Colors.white,
                                    ),
                                  ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Input Field versi Hacker
  Widget _cyberInput({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    required String validatorMsg,
    bool isPassword = false,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: isPassword ? _obscurePassword : false,
      style: const TextStyle(color: Colors.white, fontSize: 16, fontFamily: 'monospace', fontWeight: FontWeight.bold),
      cursorColor: neonRed,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.white38, fontFamily: 'monospace', letterSpacing: 2),
        prefixIcon: Icon(icon, color: Colors.white54, size: 20),
        suffixIcon: isPassword
            ? IconButton(
                icon: Icon(
                    _obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                    color: Colors.white38, size: 20),
                onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
              )
            : null,
        filled: true,
        fillColor: Colors.black.withOpacity(0.6), // Gelap
        contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: Colors.white.withOpacity(0.1))),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: neonRed, width: 1.5)), // Glow merah saat diketik
        errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: neonRed.withOpacity(0.5), width: 1)),
        focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: neonRed, width: 1.5)),
      ),
      validator: (v) => v == null || v.isEmpty ? validatorMsg : null,
    );
  }
}

// 1. Smoked Glassmorphism Card (Lebih gelap, ada neon border)
class GlassTerminalCard extends StatelessWidget {
  final Widget child;
  final double? width;

  const GlassTerminalCard({super.key, required this.child, this.width});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          width: width,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          decoration: BoxDecoration(
            color: const Color(0xFF0F0F0F).withOpacity(0.6), // Sangat gelap transparan
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: Colors.redAccent.withOpacity(0.3), // Glowing border
              width: 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                blurRadius: 40,
                spreadRadius: 5,
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

// 2. Custom Painter buat Background Cyberpunk Grid yang bergerak
class CyberGridPainter extends CustomPainter {
  final double offset;
  final Color color;

  CyberGridPainter({required this.offset, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.0;

    const double gridSize = 40.0;

    // Gambar Garis Vertikal
    for (double x = 0; x < size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    // Gambar Garis Horizontal (Bergerak ke bawah efek animasi)
    for (double y = offset % gridSize; y < size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CyberGridPainter oldDelegate) {
    return oldDelegate.offset != offset; // Repaint terus selama animasi jalan
  }
}