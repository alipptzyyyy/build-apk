import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class GlobalChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const GlobalChatPage({super.key, required this.sessionKey, required this.username, required this.role});

  @override
  State<GlobalChatPage> createState() => _GlobalChatPageState();
}

class _GlobalChatPageState extends State<GlobalChatPage> {
  late WebSocketChannel _channel;
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<dynamic> _messages = [];
  bool _isUploading = false;

  final Color bloodRed = const Color(0xFF8B0000);
  final Color chatBg = const Color(0xFF0F0F0F);
  final Color myBubble = const Color(0xFF5A0000);
  final Color otherBubble = const Color(0xFF1A1A1A);

  @override
  void initState() {
    super.initState();
    _connectWebSocket();
  }

  void _connectWebSocket() {
    _channel = WebSocketChannel.connect(Uri.parse('ws://jscloud.my.id:2029'));
    
    // 🔥 HAPUS BARIS "auth" BIAR GAK KENA TENDANG SAMA SERVER
    // Langsung tembak minta history aja!
    _channel.sink.add(jsonEncode({"type": "getGlobalChat"}));

    _channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'globalChatHistory') {
        // 🔥 UPDATE LIST LEBIH AMAN BIAR REFRESH
        setState(() => _messages = List.from(data['messages'] ?? []));
        _scrollToBottom();
      } else if (data['type'] == 'newGlobalChat') {
        setState(() => _messages = List.from(_messages)..add(data['message']));
        _scrollToBottom();
      }
    }, onError: (error) {
      print("WebSocket Error: $error");
    }, onDone: () {
      print("WebSocket Closed!");
    });
  }

  void _sendMessage({String? text, String? mediaUrl, String? mediaType, String? fileName}) {
    if ((text == null || text.isEmpty) && mediaUrl == null) return;

    _channel.sink.add(jsonEncode({
      "type": "sendGlobalChat",
      "message": text ?? "",
      "username": widget.username, // 🔥 INI SAFETY FIX NYA BOS!
      "role": widget.role,
      "mediaUrl": mediaUrl,
      "mediaType": mediaType ?? "text",
      "fileName": fileName,
    }));
    _msgCtrl.clear();
    setState(() {}); // Update UI biar icon send balik jadi mic kalau input kosong
  }

  Future<void> _uploadFile(File file, String mediaType, String fileName) async {
    setState(() => _isUploading = true);
    try {
      var request = http.MultipartRequest('POST', Uri.parse('http://supermanxnay.xyzraa.biz.id:4136/api/chat/upload'));
      request.fields['mediaType'] = mediaType;
      request.files.add(await http.MultipartFile.fromPath('file', file.path));

      var response = await request.send();
      if (response.statusCode == 200) {
        var resData = jsonDecode(await response.stream.bytesToString());
        if (resData['success']) {
          _sendMessage(mediaUrl: resData['url'], mediaType: mediaType, fileName: resData['fileName']);
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Gagal upload file!")));
    }
    setState(() => _isUploading = false);
  }

  // ==== WA ATTACHMENT MENU ====
  void _showAttachmentMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: 250,
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: chatBg, borderRadius: BorderRadius.circular(20), border: Border.all(color: bloodRed.withOpacity(0.3))),
        child: GridView.count(
          crossAxisCount: 3,
          children: [
            _attachIcon(Icons.insert_drive_file, Colors.indigo, "Document", () async {
              Navigator.pop(context);
              FilePickerResult? result = await FilePicker.platform.pickFiles();
              if (result != null) _uploadFile(File(result.files.single.path!), "document", result.files.single.name);
            }),
            _attachIcon(Icons.image, Colors.pinkAccent, "Gallery", () async {
              Navigator.pop(context);
              final XFile? image = await ImagePicker().pickImage(source: ImageSource.gallery);
              if (image != null) _uploadFile(File(image.path), "image", image.name);
            }),
            _attachIcon(Icons.videocam, Colors.orangeAccent, "Video", () async {
              Navigator.pop(context);
              final XFile? video = await ImagePicker().pickVideo(source: ImageSource.gallery);
              if (video != null) _uploadFile(File(video.path), "video", video.name);
            }),
          ],
        ),
      ),
    );
  }

  Widget _attachIcon(IconData icon, Color color, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(radius: 28, backgroundColor: color, child: Icon(icon, color: Colors.white, size: 28)),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ],
      ),
    );
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 300), () {
      if (_scrollController.hasClients) _scrollController.animateTo(_scrollController.position.maxScrollExtent, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    });
  }

  Color _getRoleColor(String role) {
    if (role == "owner") return Colors.redAccent;
    if (role == "vip") return Colors.amber;
    if (role == "reseller") return Colors.greenAccent;
    return Colors.white70;
  }

  // ==== RENDER MEDIA DALAM CHAT ====
  Widget _buildMediaWidget(Map<String, dynamic> msg) {
    final type = msg['mediaType'];
    final url = msg['mediaUrl'];
    final name = msg['fileName'] ?? "File";

    if (type == "image") {
      return GestureDetector(
        onTap: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
        child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network(url, height: 200, width: 250, fit: BoxFit.cover)),
      );
    } else if (type == "document" || type == "video") {
      return InkWell(
        onTap: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication), 
        child: Container(
          width: 250,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.black45, borderRadius: BorderRadius.circular(12)),
          child: Row(
            children: [
              Icon(type == "video" ? Icons.play_circle_fill : Icons.insert_drive_file, color: Colors.amber, size: 36),
              const SizedBox(width: 10),
              Expanded(child: Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold), maxLines: 2, overflow: TextOverflow.ellipsis)),
              const Icon(Icons.download, color: Colors.white54),
            ],
          ),
        ),
      );
    }
    return const SizedBox();
  }

  @override
  Widget build(BuildContext context) {
    // 🔥 Tentukan tombol send atau mic secara dinamis
    final bool hasText = _msgCtrl.text.trim().isNotEmpty;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A0A),
        titleSpacing: 0,
        title: Row(
          children: [
            const CircleAvatar(radius: 20, backgroundImage: AssetImage('assets/images/logo.jpg')),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text("Kaell Info Group", style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                Text("Tap here for group info", style: TextStyle(color: Colors.white54, fontSize: 11)),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(icon: const Icon(Icons.videocam, color: Colors.white), onPressed: () {}),
          IconButton(icon: const Icon(Icons.call, color: Colors.white), onPressed: () {}),
          IconButton(icon: const Icon(Icons.more_vert, color: Colors.white), onPressed: () {}),
        ],
      ),
      
      // 🔥 INI DIA OBATNYA: DIBUNGKUS SafeArea BIAR GAK NYUNGSEP DI BAWAH TOMBOL HP
      body: SafeArea(
        child: Column(
          children: [
            // ==== AREA CHAT ====
            Expanded(
              child: Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(image: AssetImage('assets/images/logo.jpg'), opacity: 0.05, fit: BoxFit.cover),
                ),
                child: ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.all(14),
                  itemCount: _messages.length,
                  itemBuilder: (ctx, i) {
                    final msg = _messages[i];
                    final isMe = msg['from'] == widget.username;
                    final roleColor = _getRoleColor(msg['role'] ?? "member");
                    final initial = msg['from'].toString().isNotEmpty ? msg['from'].toString()[0].toUpperCase() : "?";

                    return Align(
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (!isMe) ...[
                              CircleAvatar(
                                radius: 16,
                                backgroundColor: roleColor.withOpacity(0.2),
                                child: Text(initial, style: TextStyle(color: roleColor, fontWeight: FontWeight.bold, fontSize: 14)),
                              ),
                              const SizedBox(width: 8),
                            ],
                            Flexible(
                              child: Container(
                                constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                                decoration: BoxDecoration(
                                  color: isMe ? myBubble : otherBubble,
                                  borderRadius: BorderRadius.only(
                                    topLeft: const Radius.circular(16),
                                    topRight: const Radius.circular(16),
                                    bottomLeft: Radius.circular(isMe ? 16 : 0),
                                    bottomRight: Radius.circular(isMe ? 0 : 16),
                                  ),
                                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 2, offset: Offset(1, 2))],
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      if (!isMe) Text("~ ${msg['from']}", style: TextStyle(color: roleColor, fontSize: 13, fontWeight: FontWeight.bold)),
                                      if (!isMe) const SizedBox(height: 4),
                                      if (msg['mediaUrl'] != null) _buildMediaWidget(msg),
                                      if (msg['mediaUrl'] != null && msg['message'].toString().isNotEmpty) const SizedBox(height: 8),
                                      if (msg['message'].toString().isNotEmpty) Text(msg['message'], style: const TextStyle(color: Colors.white, fontSize: 15)),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

            // ==== INPUT AREA ALA WHATSAPP (UDAH AMAN DARI NAVIGASI HP) ====
            if (_isUploading) const LinearProgressIndicator(color: Colors.redAccent, minHeight: 2),
            Padding(
              padding: const EdgeInsets.fromLTRB(8.0, 10.0, 8.0, 10.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 4.0),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1A1A1A),
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(color: Colors.white.withOpacity(0.05)),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () {}, 
                              borderRadius: BorderRadius.circular(20),
                              child: const Padding(
                                padding: EdgeInsets.all(12.0),
                                child: Icon(Icons.emoji_emotions_outlined, color: Colors.white54, size: 24),
                              ),
                            ),
                          ),
                          Expanded(
                            child: TextField(
                              controller: _msgCtrl,
                              style: const TextStyle(color: Colors.white),
                              maxLines: null, 
                              textCapitalization: TextCapitalization.sentences,
                              onChanged: (text) => setState(() {}), 
                              decoration: const InputDecoration(
                                hintText: "Message",
                                hintStyle: TextStyle(color: Colors.white54, fontSize: 15),
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 14),
                              ),
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: _showAttachmentMenu,
                                  borderRadius: BorderRadius.circular(20),
                                  child: const Padding(
                                    padding: EdgeInsets.all(12.0),
                                    child: Icon(Icons.attach_file, color: Colors.white54, size: 24),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 4),
                              Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: _showAttachmentMenu, // Bisa diganti buka kamera nanti
                                  borderRadius: BorderRadius.circular(20),
                                  child: const Padding(
                                    padding: EdgeInsets.all(12.0),
                                    child: Icon(Icons.camera_alt, color: Colors.white54, size: 24),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 4),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        if (hasText) {
                          _sendMessage(text: _msgCtrl.text.trim());
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Pesan suara belum didukung!")));
                        }
                      },
                      borderRadius: BorderRadius.circular(30),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: bloodRed, shape: BoxShape.circle, border: Border.all(color: Colors.white12)),
                        child: Icon(
                          hasText ? Icons.send : Icons.mic, 
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}