import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';

class GetSourcePage extends StatefulWidget {
  const GetSourcePage({super.key});

  @override
  State<GetSourcePage> createState() => _GetSourcePageState();
}

class _GetSourcePageState extends State<GetSourcePage> {
  final TextEditingController controller = TextEditingController();
  String result = "";
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // HEADER
              Container(
                padding: const EdgeInsets.symmetric(vertical: 18),
                decoration: BoxDecoration(
                  color: const Color(0xFF121212),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFFE53935)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.code, color: Color(0xFFE53935)),
                    SizedBox(width: 10),
                    Text(
                      "GET SOURCE CODE",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        letterSpacing: 2,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 28),

              // INPUT
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF121212),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFFE53935)),
                ),
                child: TextField(
                  controller: controller,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    hintText: "Masukkan URL Website",
                    hintStyle: TextStyle(color: Colors.white38),
                    prefixIcon:
                        Icon(Icons.language, color: Color(0xFFE53935)),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.all(16),
                  ),
                ),
              ),

              const SizedBox(height: 18),

              // BUTTON
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFB71C1C),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: loading
                      ? null
                      : () async {
                          if (!controller.text.startsWith("http")) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("URL tidak valid"),
                                backgroundColor: Colors.red,
                              ),
                            );
                            return;
                          }

                          setState(() => loading = true);

                          try {
                            final res = await http.get(
                              Uri.parse(controller.text),
                              headers: {
                                "User-Agent": "Mozilla/5.0",
                                "Accept": "text/html",
                              },
                            );

                            if (res.statusCode == 200) {
                              result = res.body;

                              // AUTO COPY (JANGAN DIHAPUS)
                              Clipboard.setData(
                                ClipboardData(text: result),
                              );

                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                      "Source code berhasil diambil & disalin"),
                                  backgroundColor: Colors.green,
                                ),
                              );
                            } else {
                              result = "Gagal mengambil source code";
                            }
                          } catch (e) {
                            result = e.toString();
                          }

                          setState(() => loading = false);
                        },
                  child: loading
                      ? const SizedBox(
                          height: 22,
                          width: 22,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text(
                          "GET SOURCE CODE",
                          style: TextStyle(
                            letterSpacing: 1.5,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                ),
              ),

              const SizedBox(height: 20),

              // RESULT (RAPIH & TENGAH)
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF121212),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFE53935)),
                  ),
                  child: SingleChildScrollView(
                    child: SelectableText(
                      result.isEmpty
                          ? "// Source code akan tampil di sini"
                          : result,
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}