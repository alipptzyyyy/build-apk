import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// PASTIKAN SEMUA IMPORT INI BENAR DAN SESUAI NAMA FILE LU
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  // Warna Dasar Tema Cyberpunk
  final Color darkBg = const Color(0xFF050505);
  final Color panelBg = const Color(0xFF0A0A0A);
  
  // Neon Colors (Sesuai request: Warna-warni tapi Hacker Style)
  final Color neonRed = const Color(0xFFFF1744);
  final Color neonBlue = const Color(0xFF2979FF);
  final Color neonGreen = const Color(0xFF00E676);
  final Color neonPurple = const Color(0xFFD500F9);
  final Color neonOrange = const Color(0xFFFF9100);
  final Color neonCyan = const Color(0xFF00E5FF);
  final Color neonYellow = const Color(0xFFFFEA00);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Stack(
        children: [
          // === BACKGROUND CYBERPUNK ===
          Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: GridPainter()))),
          Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: ScanlinePainter()))),

          SafeArea(
            child: Column(
              children: [
                // === HEADER CYBERPUNK ===
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: panelBg.withOpacity(0.8),
                    border: Border(
                      bottom: const BorderSide(color: Colors.white12, width: 1),
                      left: BorderSide(color: neonRed, width: 4), // Garis merah tajam
                    ),
                    boxShadow: [
                      BoxShadow(color: neonRed.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 5)),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.terminal, color: neonRed, size: 28),
                          const SizedBox(width: 12),
                          const Text(
                            "NATUROM // TOOLS",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontFamily: 'monospace',
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2.0,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "ADVANCED SECURITY & OSINT MODULES",
                        style: TextStyle(
                          color: Colors.white54,
                          fontSize: 10,
                          fontFamily: 'monospace',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),

                // === CATEGORY CARDS GRID ===
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                    child: GridView.count(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 1.1, // Disesuaikan biar proporsional
                      physics: const BouncingScrollPhysics(),
                      children: [
                        // DDoS Tools
                        _buildCyberToolCard(
                          icon: Icons.bolt,
                          title: "DDOS MODULE",
                          subtitle: "ATTACK & SERVER",
                          neonColor: neonRed,
                          onTap: () => _showDDoSTools(context),
                        ),

                        // Network Tools
                        _buildCyberToolCard(
                          icon: Icons.wifi_tethering,
                          title: "NETWORK",
                          subtitle: "WIFI & SPAM",
                          neonColor: neonGreen,
                          onTap: () => _showNetworkTools(context),
                        ),

                        // OSINT Tools
                        _buildCyberToolCard(
                          icon: Icons.plagiarism_outlined,
                          title: "OSINT",
                          subtitle: "INVESTIGATION",
                          neonColor: neonPurple,
                          onTap: () => _showOSINTTools(context),
                        ),

                        // Media Downloader
                        _buildCyberToolCard(
                          icon: Icons.download_for_offline_outlined,
                          title: "DOWNLOADER",
                          subtitle: "SOCIAL MEDIA",
                          neonColor: neonOrange,
                          onTap: () => _showDownloaderTools(context),
                        ),

                        // Additional Tools
                        _buildCyberToolCard(
                          icon: Icons.build_circle_outlined,
                          title: "UTILITIES",
                          subtitle: "EXTRA TOOLS",
                          neonColor: neonCyan,
                          onTap: () => _showUtilityTools(context),
                        ),

                        // Quick Access
                        _buildCyberToolCard(
                          icon: Icons.rocket_launch_outlined,
                          title: "QUICK ACCESS",
                          subtitle: "FAVORITES",
                          neonColor: neonYellow,
                          onTap: () => _showQuickAccess(context),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // WIDGET CARD VERSI HACKER TAPI TETEP WARNA WARNI
  Widget _buildCyberToolCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color neonColor,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0.8, end: 1),
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutBack,
      builder: (context, double scale, child) {
        return Transform.scale(
          scale: scale,
          child: child,
        );
      },
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: panelBg,
            borderRadius: BorderRadius.circular(4), // Kaku
            border: Border.all(color: neonColor.withOpacity(0.5), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: neonColor.withOpacity(0.15),
                blurRadius: 15,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Stack(
            children: [
              // Efek garis sudut atas
              Positioned(top: 0, right: 0, child: Container(width: 20, height: 2, color: neonColor)),
              Positioned(top: 0, right: 0, child: Container(width: 2, height: 20, color: neonColor)),
              // Konten
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(icon, color: neonColor, size: 32),
                    const Spacer(),
                    Text(
                      title,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontFamily: 'monospace',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.0,
                        shadows: [Shadow(color: neonColor, blurRadius: 5)],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 9,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ========================================================
  // LOGIC BOTTOM SHEETS (FUNGSI UTUH 100%)
  // ========================================================

  void _showDDoSTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildCyberBottomSheet(
        context: context,
        title: "DDOS MODULES",
        neonColor: neonRed,
        icon: Icons.bolt,
        children: [
          _buildCyberToolOption(
            icon: Icons.crisis_alert,
            label: "ATTACK PANEL",
            color: neonRed,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AttackPanel(
                    sessionKey: sessionKey,
                    listDoos: listDoos,
                  ),
                ),
              );
            },
          ),
          _buildCyberToolOption(
            icon: Icons.dns_outlined,
            label: "MANAGE SERVER",
            color: neonBlue,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ManageServerPage(keyToken: sessionKey),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  void _showNetworkTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildCyberBottomSheet(
        context: context,
        title: "NETWORK TOOLS",
        neonColor: neonGreen,
        icon: Icons.wifi_tethering,
        children: [
          _buildCyberToolOption(
            icon: Icons.chat_bubble_outline,
            label: "SPAM NGL",
            color: neonRed,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => NglPage()));
            },
          ),
          _buildCyberToolOption(
            icon: Icons.wifi_off,
            label: "WIFI KILLER (INTERNAL)",
            color: neonYellow,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => WifiKillerPage()));
            },
          ),
          if (userRole == "vip" || userRole == "owner")
            _buildCyberToolOption(
              icon: Icons.router_outlined,
              label: "WIFI KILLER (EXTERNAL)",
              color: neonOrange,
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: sessionKey)),
                );
              },
            ),
        ],
      ),
    );
  }

  void _showOSINTTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildCyberBottomSheet(
        context: context,
        title: "OSINT INVESTIGATION",
        neonColor: neonPurple,
        icon: Icons.plagiarism_outlined,
        children: [
          _buildCyberToolOption(
            icon: Icons.badge_outlined,
            label: "NIK DETAIL",
            color: neonPurple,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
            },
          ),
          _buildCyberToolOption(
            icon: Icons.language,
            label: "DOMAIN OSINT",
            color: neonPurple,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
            },
          ),
          _buildCyberToolOption(
            icon: Icons.person_search_outlined,
            label: "PHONE LOOKUP",
            color: Colors.purpleAccent,
            onTap: () => _showComingSoon(context),
          ),
          _buildCyberToolOption(
            icon: Icons.alternate_email,
            label: "EMAIL OSINT",
            color: Colors.deepPurpleAccent,
            onTap: () => _showComingSoon(context),
          ),
        ],
      ),
    );
  }

  void _showDownloaderTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildCyberBottomSheet(
        context: context,
        title: "MEDIA DOWNLOADER",
        neonColor: neonOrange,
        icon: Icons.download_for_offline_outlined,
        children: [
          _buildCyberToolOption(
            icon: Icons.tiktok,
            label: "TIKTOK EXTRACTOR",
            color: neonOrange,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
            },
          ),
          _buildCyberToolOption(
            icon: FontAwesomeIcons.instagram,
            label: "INSTAGRAM EXTRACTOR",
            color: Colors.pinkAccent,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
            },
          ),
        ],
      ),
    );
  }

  void _showUtilityTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildCyberBottomSheet(
        context: context,
        title: "UTILITY MODULES",
        neonColor: neonCyan,
        icon: Icons.build_circle_outlined,
        children: [
          _buildCyberToolOption(
            icon: Icons.qr_code_2,
            label: "QR GENERATOR",
            color: neonCyan,
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
            },
          ),
          _buildCyberToolOption(
            icon: Icons.security,
            label: "IP SCANNER",
            color: neonBlue,
            onTap: () => _showComingSoon(context),
          ),
          _buildCyberToolOption(
            icon: Icons.network_check,
            label: "PORT SCANNER",
            color: neonGreen,
            onTap: () => _showComingSoon(context),
          ),
        ],
      ),
    );
  }

  void _showQuickAccess(BuildContext context) {
    _showComingSoon(context);
  }

  // ========================================================
  // REUSABLE UI WIDGETS CYBERPUNK
  // ========================================================

  // Layout untuk Bottom Sheet Cyberpunk
  Widget _buildCyberBottomSheet({required BuildContext context, required String title, required Color neonColor, required IconData icon, required List<Widget> children}) {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.65,
        decoration: BoxDecoration(
          color: panelBg.withOpacity(0.9),
          borderRadius: const BorderRadius.only(topLeft: Radius.circular(16), topRight: Radius.circular(16)),
          border: Border(top: BorderSide(color: neonColor, width: 2), left: BorderSide(color: neonColor, width: 1), right: BorderSide(color: neonColor, width: 1)),
          boxShadow: [BoxShadow(color: neonColor.withOpacity(0.2), blurRadius: 20)],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: neonColor.withOpacity(0.1),
                border: Border(bottom: BorderSide(color: neonColor.withOpacity(0.3), width: 1)),
              ),
              child: Row(
                children: [
                  Icon(icon, color: neonColor, size: 28),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontFamily: 'monospace',
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2.0,
                      shadows: [Shadow(color: neonColor, blurRadius: 10)],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.all(20),
                children: children,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Opsi di dalam Bottom Sheet
  Widget _buildCyberToolOption({required IconData icon, required String label, required Color color, required VoidCallback onTap}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.5),
        border: Border.all(color: color.withOpacity(0.4), width: 1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: color.withOpacity(0.1), border: Border.all(color: color.withOpacity(0.5))),
          child: Icon(icon, color: color, size: 20),
        ),
        title: Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontFamily: 'monospace',
            fontWeight: FontWeight.bold,
            fontSize: 13,
            letterSpacing: 1.0,
          ),
        ),
        trailing: Icon(Icons.arrow_forward_ios, color: color.withOpacity(0.5), size: 14),
        onTap: onTap,
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: const [
            Icon(Icons.lock_clock, color: Colors.black, size: 18),
            SizedBox(width: 10),
            Text(
              'MODULE COMING SOON!',
              style: TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold, color: Colors.black),
            ),
          ],
        ),
        backgroundColor: neonYellow,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)), // Kaku
      ),
    );
  }
}

// ==========================================
// BACKGROUND EFEK TERMINAL (Sama kyk Dashboard)
// ==========================================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.03)
      ..strokeWidth = 1.0;
    const double gridSize = 40.0;
    for (double x = 0; x < size.width; x += gridSize) canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y < size.height; y += gridSize) canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ScanlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black.withOpacity(0.3)
      ..strokeWidth = 2.0;
    for (double i = 0; i < size.height; i += 4.0) canvas.drawLine(Offset(0, i), Offset(size.width, i), paint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

