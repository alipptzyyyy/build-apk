import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart'; // Impor url_launcher

import 'anime_home.dart';
import 'global_chat.dart';
import 'change_password.dart';
import 'panel_manager.dart';
import 'bug_sender.dart';
import 'nik_check.dart';
import 'history_coin.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'chatbot_page.dart';
import 'dashboard_ai.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _slideAnimation;
  late WebSocketChannel channel;
  int bCoin = 0;
  int lCoin = 0;

  // ==== VIP CYBERPUNK THEME COLORS ====
  final Color bloodRed = const Color(0xFFB71C1C);
  final Color neonRed = const Color(0xFFFF1744);
  final Color darkBg = const Color(0xFF050505);
  final Color panelBg = const Color(0xFF0A0A0A);
  final Color neonGreen = const Color(0xFF00E676);
  final Color neonBlue = const Color(0xFF2979FF);
  final Color neonAmber = const Color(0xFFFFC107);
  final Color glassBlack = const Color(0xFF0F0F0F).withOpacity(0.9);
  
  Future<void> loadCoin() async {
    try {
      final res = await http.post(
        Uri.parse("http://supermanxnay.xyzraa.biz.id:4136/profile"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"username": widget.username}), // Fix access username
      );

      final data = jsonDecode(res.body);

      if (mounted) {
        setState(() {
          bCoin = data["bitcoin"] ?? 0;
          lCoin = data["lcoin"] ?? 0;
          if (_bottomNavIndex == 0) {
            _selectedPage = _buildEnhancedNewsPage(); 
          }
        });
      }
    } catch (e) {
      debugPrint("Error loading coin: $e");
    }
  }
  
  List<Map<String, dynamic>> get _dynamicNavItems {
    List<Map<String, dynamic>> items = [
      {"icon": Icons.terminal, "label": "MAIN", "page": _buildEnhancedNewsPage()},
      {"icon": FontAwesomeIcons.whatsapp, "label": "PAYLOAD", "page": HomePage(
          username: widget.username, password: widget.password, listBug: widget.listBug, role: widget.role, expiredDate: widget.expiredDate, sessionKey: widget.sessionKey, onCoinUpdated: loadCoin)},
      {"icon": Icons.memory, "label": "TOOLS", "page": ToolsPage(sessionKey: widget.sessionKey, userRole: widget.role, listDoos: widget.listDoos)},
      {"icon": Icons.smart_toy_outlined, "label": "AI-BOT", "page": const GoToChatBot()},
    ];

    String safeRole = widget.role.toLowerCase().trim();

    // JIKA OWNER ATAU VIP, MUNCULIN MENU C-PANEL
    if (safeRole == 'owner' || safeRole == 'vip') {
      items.insert(2, {
        "icon": Icons.dns_rounded,
        "label": "C-PANEL",
        "page": PanelManagerPage(sessionKey: widget.sessionKey, role: widget.role)
      });
    }

    // Anime selalu di ujung kanan
    items.add({"icon": Icons.movie_filter_rounded, "label": "ANIME", "page": const HomeAnimePage()});
    return items;
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      _selectedPage = _dynamicNavItems[index]["page"]; 
    });
  }

  Widget _buildGlassBottomNavBar() {
    return Container(
      decoration: BoxDecoration(
        color: panelBg,
        border: Border(top: BorderSide(color: neonRed.withOpacity(0.5), width: 1.5)),
        boxShadow: [
          BoxShadow(
            color: bloodRed.withOpacity(0.2),
            blurRadius: 15,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: BottomNavigationBar(
        backgroundColor: panelBg,
        selectedItemColor: neonRed,
        unselectedItemColor: Colors.white54,
        selectedLabelStyle: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1),
        unselectedLabelStyle: const TextStyle(fontFamily: 'monospace', fontSize: 10),
        currentIndex: _bottomNavIndex,
        onTap: _onBottomNavTapped,
        elevation: 0,
        type: BottomNavigationBarType.fixed,
        items: _dynamicNavItems.map((item) {
          return BottomNavigationBarItem(
            icon: Padding(
              padding: const EdgeInsets.only(bottom: 4.0),
              child: Icon(item["icon"]),
            ),
            label: item["label"],
          );
        }).toList(),
      ),
    );
  }

  // Controller untuk video background
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;

  String androidId = "unknown";

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  @override
  void initState() {
    super.initState();

    loadCoin();
    _initializeVideo();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.elasticOut),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _controller.forward();

    _selectedPage = _buildEnhancedNewsPage();
    _initAndroidIdAndConnect();
  }

  void _initializeVideo() async {
    _videoController = VideoPlayerController.asset('assets/videos/bg.mp4')
      ..initialize().then((_) {
        _videoController.setVolume(0.0);
        _videoController.setLooping(true);
        _videoController.play();
        if (mounted) {
          setState(() {
            _isVideoInitialized = true;
          });
        }
      });
  }

  Future<void> _initAndroidIdAndConnect() async {
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      androidId = deviceInfo.id ?? "unknown";
    } catch (_) {
      androidId = "unknown";
    }
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(Uri.parse('ws://jscloud.my.id:2029'));
      channel.sink.add(jsonEncode({
        "type": "validate",
        "key": widget.sessionKey,
        "androidId": androidId,
      }));
      channel.sink.add(jsonEncode({"type": "stats"}));

      channel.stream.listen((event) {
        try {
          final data = jsonDecode(event);
          if (data['type'] == 'myInfo') {
            if (data['valid'] == false) {
              _handleInvalidSession("SESSION COMPROMISED. RE-AUTHENTICATION REQUIRED.");
            }
          }
        } catch (_) {}
      });
    } catch (_) {}
  }

  void _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: panelBg,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(4),
            side: BorderSide(color: neonRed, width: 1.5),
          ),
          title: Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: neonRed, size: 28),
              const SizedBox(width: 10),
              Text("SYSTEM ALERT", style: TextStyle(color: neonRed, fontWeight: FontWeight.bold, fontFamily: 'monospace', letterSpacing: 1)),
            ],
          ),
          content: Text(message, style: const TextStyle(color: Colors.white70, fontFamily: 'monospace')),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: neonRed.withOpacity(0.8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
              onPressed: () {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                  (route) => false,
                );
              },
              child: const Text("ACKNOWLEDGE", style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  void _navigateToAdminPage() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => AdminPage(sessionKey: widget.sessionKey)));
  }

  void _navigateToSellerPage() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => SellerPage(keyToken: widget.sessionKey)));
  }

  int onlineUsers = 0;
  int activeConnections = 0;

  // DIBIARKAN UTUH KARENA REQUEST USER
  Widget _buildCompactInfoItem({required IconData icon, required String label, required String value, Color valueColor = Colors.white}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: panelBg,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: neonRed.withOpacity(0.3)), 
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(color: bloodRed.withOpacity(0.2), shape: BoxShape.rectangle),
            child: Icon(icon, color: neonRed, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'monospace')),
                const SizedBox(height: 2),
                Text(value, style: TextStyle(color: valueColor, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // DIBIARKAN UTUH KARENA REQUEST USER
  Widget _buildQuickStat({required IconData icon, required String label, required String value}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: panelBg,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: Colors.white12),
        ),
        child: Row(
          children: [
            Icon(icon, color: neonRed, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'monospace')),
                  Text(value, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "owner": return neonRed;
      case "vip": return neonAmber;
      case "reseller": return neonGreen;
      case "premium": return neonBlue;
      default: return Colors.white;
    }
  }

  // Widget untuk membangun video background
  Widget _buildVideoBackground() {
    if (_isVideoInitialized) {
      return SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _videoController.value.size.width,
            height: _videoController.value.size.height,
            child: VideoPlayer(_videoController),
          ),
        ),
      );
    } else {
      return Container(color: darkBg);
    }
  }

  // ==========================================
  // WIDGET TAMBAHAN UNTUK MENU BAWAH WALLET
  // ==========================================
  Widget _customMenuTile({required IconData icon, required String text, required Color iconColor, required VoidCallback onTap}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          decoration: BoxDecoration(
            color: panelBg, 
            borderRadius: BorderRadius.circular(4), // Kaku cyberpunk
            border: Border.all(color: Colors.white12, width: 1),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 10, offset: const Offset(0, 4))],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: iconColor.withOpacity(0.1), border: Border.all(color: iconColor.withOpacity(0.5))),
                child: Icon(icon, color: iconColor, size: 20),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold, fontFamily: 'monospace', letterSpacing: 1)),
              ),
              Icon(Icons.keyboard_arrow_right, color: iconColor, size: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEnhancedNewsPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Stack(
        children: [
          // ===== BANNER =====
          SizedBox(
            width: double.infinity,
            height: 240,
            child: PageView.builder(
              controller: PageController(viewportFraction: 1),
              itemCount: widget.news.length,
              itemBuilder: (context, index) {
                final item = widget.news[index];
                return Stack(
                  fit: StackFit.expand,
                  children: [
                    if (item['image'] != null && item['image'].toString().isNotEmpty)
                      NewsMedia(url: item['image']),
                    IgnorePointer(child: CustomPaint(painter: ScanlinePainter())),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [darkBg, Colors.transparent],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                      ),
                    ),
                    Positioned(
                      top: 16, left: 20,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        color: bloodRed.withOpacity(0.8),
                        child: const Text("NATUROM_TRANSMISSION", style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2)),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),

          // ===== CONTENT =====
          Column(
            children: [
              const SizedBox(height: 240), 

              // ===== WALLET TITLE =====
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Icon(Icons.account_balance_wallet_outlined, color: neonAmber, size: 20),
                    const SizedBox(width: 10),
                    const Text("EWALET ANDA", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'monospace', letterSpacing: 2)),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ===== WALLET CARD (DIUBAH TAMPILAN JADI CYBER) =====
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    _AccountTiles(
                      icon: Icons.person_pin,
                      iconColor: Colors.white54,
                      title: "CODENAME",
                      amount: widget.username,
                      badgeColor: Colors.white54,
                    ),
                    const SizedBox(height: 12),
                    _coinTile(
                      icon: Icons.currency_bitcoin,
                      iconColor: neonAmber,
                      title: "B-COIN BALANCE",
                      amount: bCoin.toString(),
                      badgeColor: neonAmber,
                    ),
                    const SizedBox(height: 12),
                    _coinTile(
                      icon: Icons.diamond_outlined,
                      iconColor: neonBlue,
                      title: "L-COIN BALANCE",
                      amount: lCoin.toString(),
                      badgeColor: neonBlue,
                    ),
                    const SizedBox(height: 22),
                    Row(
                      children: [
                        Expanded(
                          child: _actionButton(
                            icon: Icons.add_circle_outline,
                            label: "TOP UP",
                            color: neonAmber,
                            onTap: () {
                              final redeemCtrl = TextEditingController();

                              showDialog(
                                context: context,
                                builder: (_) => BackdropFilter(
                                  filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                                  child: AlertDialog(
                                    backgroundColor: panelBg,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: BorderSide(color: neonAmber, width: 1.5)),
                                    title: Row(
                                      children: [
                                        Icon(Icons.add_box, color: neonAmber),
                                        const SizedBox(width: 10),
                                        const Text("SYSTEM TOP UP", style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold, fontSize: 16)),
                                      ],
                                    ),
                                    content: TextField(
                                      controller: redeemCtrl,
                                      style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                                      decoration: InputDecoration(
                                        hintText: "ENTER REDEEM CODE",
                                        hintStyle: const TextStyle(color: Colors.white38, fontFamily: 'monospace'),
                                        filled: true, fillColor: Colors.black,
                                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: Colors.white12)),
                                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: neonAmber)),
                                      ),
                                    ),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.pop(context),
                                        child: const Text("ABORT", style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                      ),
                                      ElevatedButton(
                                        style: ElevatedButton.styleFrom(backgroundColor: neonAmber.withOpacity(0.8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
                                        onPressed: () async {
                                          Navigator.pop(context); // Tutup pop-up input

                                          // 🔥 FIX ERROR LOADING MUTER:
                                          showDialog(
                                            context: context,
                                            barrierDismissible: false,
                                            builder: (_) => Center(child: CircularProgressIndicator(color: neonAmber)),
                                          );

                                          try {
                                            final res = await http.post(
                                              Uri.parse("http://supermanxnay.xyzraa.biz.id:4136/topup"),
                                              headers: {"Content-Type": "application/json"},
                                              body: jsonEncode({"username": widget.username, "redeem_code": redeemCtrl.text}),
                                            );

                                            Navigator.pop(context); // Tutup loading

                                            final data = jsonDecode(res.body);
                                            if (data["success"] == true) await loadCoin();

                                            showDialog(
                                              context: context,
                                              builder: (_) => AlertDialog(
                                                backgroundColor: panelBg,
                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: BorderSide(color: data["success"] ? neonGreen : neonRed)),
                                                title: Text(data["success"] ? "SUCCESS" : "FAILED", style: TextStyle(color: data["success"] ? neonGreen : neonRed, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                                content: Text(data["message"], style: const TextStyle(color: Colors.white70, fontFamily: 'monospace')),
                                              ),
                                            );
                                          } catch (e) {
                                            Navigator.pop(context); // Tutup loading walau error internet
                                            showDialog(
                                              context: context,
                                              builder: (_) => AlertDialog(
                                                backgroundColor: panelBg,
                                                title: Text("FAILED", style: TextStyle(color: neonRed, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                                content: const Text("CONNECTION ERROR", style: TextStyle(color: Colors.white70, fontFamily: 'monospace')),
                                              ),
                                            );
                                          }
                                        },
                                        child: const Text("EXECUTE", style: TextStyle(color: Colors.black, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 12),

                        Expanded(
                          child: _actionButton(
                            icon: Icons.send,
                            label: "TRANSFER",
                            color: neonBlue,
                            onTap: () {
                              final userCtrl = TextEditingController();
                              final amountCtrl = TextEditingController();
                              String selectedCoin = "bitcoin"; // default

                              showDialog(
                                context: context,
                                builder: (dialogContext) {
                                  return StatefulBuilder(
                                    builder: (context, setState) {
                                      return BackdropFilter(
                                        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                                        child: AlertDialog(
                                          backgroundColor: panelBg,
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: BorderSide(color: neonBlue, width: 1.5)),
                                          title: Row(
                                            children: [
                                              Icon(Icons.send_rounded, color: neonBlue),
                                              const SizedBox(width: 10),
                                              const Text("TRANSFER ASSETS", style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold, fontSize: 16)),
                                            ],
                                          ),
                                          content: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              TextField(
                                                controller: userCtrl,
                                                style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                                                decoration: InputDecoration(
                                                  hintText: "TARGET CODENAME", hintStyle: const TextStyle(color: Colors.white38, fontFamily: 'monospace'),
                                                  filled: true, fillColor: Colors.black,
                                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: Colors.white12)),
                                                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: neonBlue)),
                                                ),
                                              ),
                                              const SizedBox(height: 12),
                                              DropdownButtonFormField<String>(
                                                value: selectedCoin,
                                                dropdownColor: panelBg,
                                                icon: Icon(Icons.arrow_drop_down, color: neonBlue),
                                                decoration: InputDecoration(
                                                  filled: true, fillColor: Colors.black,
                                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: Colors.white12)),
                                                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: neonBlue)),
                                                ),
                                                style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold),
                                                items: const [
                                                  DropdownMenuItem(value: "bitcoin", child: Text("B-COIN")),
                                                  DropdownMenuItem(value: "lcoin", child: Text("L-COIN")),
                                                ],
                                                onChanged: (value) => setState(() => selectedCoin = value!),
                                              ),
                                              const SizedBox(height: 12),
                                              TextField(
                                                controller: amountCtrl,
                                                keyboardType: TextInputType.number,
                                                style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                                                decoration: InputDecoration(
                                                  hintText: "AMOUNT", hintStyle: const TextStyle(color: Colors.white38, fontFamily: 'monospace'),
                                                  filled: true, fillColor: Colors.black,
                                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: Colors.white12)),
                                                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide(color: neonBlue)),
                                                ),
                                              ),
                                            ],
                                          ),
                                          actions: [
                                            TextButton(
                                              onPressed: () => Navigator.pop(dialogContext),
                                              child: const Text("ABORT", style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                            ),
                                            ElevatedButton(
                                              style: ElevatedButton.styleFrom(backgroundColor: neonBlue.withOpacity(0.8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
                                              onPressed: () async {
                                                Navigator.pop(dialogContext); // Tutup pop-up transfer

                                                // 🔥 FIX ERROR LOADING MUTER
                                                showDialog(
                                                  context: context,
                                                  barrierDismissible: false,
                                                  builder: (_) => Center(child: CircularProgressIndicator(color: neonBlue)),
                                                );

                                                try {
                                                  final res = await http.post(
                                                    Uri.parse("http://supermanxnay.xyzraa.biz.id:4136/transfer"),
                                                    headers: {"Content-Type": "application/json"},
                                                    body: jsonEncode({"from": widget.username, "to": userCtrl.text, "amount": amountCtrl.text, "coinType": selectedCoin}),
                                                  );

                                                  Navigator.pop(context); // Tutup loading

                                                  final data = jsonDecode(res.body);
                                                  if (data["success"] == true) await loadCoin();

                                                  showDialog(
                                                    context: context,
                                                    builder: (_) => AlertDialog(
                                                      backgroundColor: panelBg,
                                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: BorderSide(color: data["success"] ? neonGreen : neonRed)),
                                                      title: Text(data["success"] ? "SUCCESS" : "FAILED", style: TextStyle(color: data["success"] ? neonGreen : neonRed, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                                      content: Text(data["message"], style: const TextStyle(color: Colors.white70, fontFamily: 'monospace')),
                                                    ),
                                                  );
                                                } catch (e) {
                                                  Navigator.pop(context); // Tutup loading kalau RTO
                                                  showDialog(
                                                    context: context,
                                                    builder: (_) => AlertDialog(
                                                      backgroundColor: panelBg,
                                                      title: Text("FAILED", style: TextStyle(color: neonRed, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                                      content: const Text("CONNECTION ERROR", style: TextStyle(color: Colors.white70, fontFamily: 'monospace')),
                                                    ),
                                                  );
                                                }
                                              },
                                              child: const Text("EXECUTE", style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  );
                                },
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 14),

                        Expanded(
                          child: _actionButton(
                            icon: Icons.restore,
                            label: "HISTORY",
                            color: neonGreen,
                            onTap: () {
                              Navigator.push(context, MaterialPageRoute(builder: (_) => CoinHistoryPage(username: widget.username)));
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 30),
              const Divider(color: Colors.white12, thickness: 1),
              const SizedBox(height: 20),

              // ==========================================
              // BLOK MENU BARU (TELEGRAM & ADD SENDER)
              // ==========================================
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: const Text("EXTERNAL COMMANDS", style: TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'monospace', fontWeight: FontWeight.bold, letterSpacing: 2)),
              ),
              const SizedBox(height: 8),
              
              _customMenuTile(
                icon: Icons.telegram,
                iconColor: neonBlue,
                text: "JOIN OFFICIAL CHANNEL",
                onTap: () async {
                  final uri = Uri(scheme: 'https', host: 't.me', path: 'MyThe5');
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                },
              ),

              _customMenuTile(
                icon: Icons.bug_report,
                iconColor: neonGreen,
                text: "MANAGE BUG DISPATCHER",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => BugSenderPage(sessionKey: widget.sessionKey, username: widget.username, role: widget.role),
                    ),
                  );
                },
              ),
              // ==========================================

              const SizedBox(height: 120), // Jarak ke paling bawah biar nggak nabrak navbar
            ],
          ),
        ],
      ),
    );
  }

  // ==========================================
  // WIDGET FUNGSI BAWAAN YANG DIKEMBALIKAN
  // ==========================================

  Widget _actionButton({required IconData icon, required String label, required Color color, required VoidCallback onTap}) {
    return InkWell(
      borderRadius: BorderRadius.circular(4),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.05),
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: color.withOpacity(0.5), width: 1.5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 8),
            Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'monospace', letterSpacing: 1)),
          ],
        ),
      ),
    );
  }

  Widget _AccountTiles({required IconData icon, required Color iconColor, required String title, required String amount, required Color badgeColor}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: panelBg,
        border: Border(left: BorderSide(color: badgeColor, width: 4), top: const BorderSide(color: Colors.white12), bottom: const BorderSide(color: Colors.white12), right: const BorderSide(color: Colors.white12)),
      ),
      child: Row(
        children: [
          Icon(icon, color: badgeColor.withOpacity(0.8), size: 24),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'monospace', letterSpacing: 1.5)),
              const SizedBox(height: 4),
              Text(amount, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
            ],
          ),
          const Spacer(),
          Text("[ ACTIVE ]", style: TextStyle(color: badgeColor.withOpacity(0.5), fontSize: 8, fontFamily: 'monospace', letterSpacing: 1)),
        ],
      ),
    );
  }

  Widget _coinTile({required IconData icon, required Color iconColor, required String title, required String amount, required Color badgeColor}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: panelBg,
        border: Border(left: BorderSide(color: badgeColor, width: 4), top: const BorderSide(color: Colors.white12), bottom: const BorderSide(color: Colors.white12), right: const BorderSide(color: Colors.white12)),
      ),
      child: Row(
        children: [
          Icon(icon, color: badgeColor.withOpacity(0.8), size: 24),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'monospace', letterSpacing: 1.5)),
              const SizedBox(height: 4),
              Text(amount, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
            ],
          ),
          const Spacer(),
          Text("[ SYNC ]", style: TextStyle(color: badgeColor.withOpacity(0.5), fontSize: 8, fontFamily: 'monospace', letterSpacing: 1)),
        ],
      ),
    );
  }

  // DIBIARKAN UTUH KARENA REQUEST USER
  Widget _contactActionButton({required IconData icon, required String label, required String url, required Color color}) {
    return GestureDetector(
      onTap: () async {
        final uri = Uri.parse(url);
        if (await canLaunchUrl(uri)) await launchUrl(uri); else await launchUrl(uri);
      },
      child: Column(
        children: [
          Container(
            width: 60, height: 60,
            decoration: BoxDecoration(color: Colors.black.withOpacity(0.5), borderRadius: BorderRadius.circular(4), border: Border.all(color: color.withOpacity(0.5))),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10, fontFamily: 'monospace')),
        ],
      ),
    );
  }

  // DIBIARKAN UTUH KARENA REQUEST USER
  Widget _enhancedGlassCard({required Widget child}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: panelBg, border: Border.all(color: neonRed.withOpacity(0.3), width: 1.5)),
      child: child,
    );
  }

  // DIBIARKAN UTUH KARENA REQUEST USER
  Widget _enhancedInfoRow(IconData icon, String label, String value, {Color valueColor = Colors.white}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.3), border: Border.all(color: bloodRed.withOpacity(0.2))),
      child: Row(
        children: [
          Icon(icon, color: bloodRed, size: 20),
          const SizedBox(width: 12),
          Text("$label: ", style: const TextStyle(color: Colors.white70, fontFamily: 'monospace')),
          Expanded(child: Text(value, textAlign: TextAlign.right, style: TextStyle(color: valueColor, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'monospace'))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: _buildDrawer(),
      backgroundColor: darkBg,
      extendBody: true,

      // APPBAR SELALU ADA
      appBar: AppBar(
        backgroundColor: panelBg.withOpacity(0.9),
        elevation: 0,
        centerTitle: false,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          "NATUROM // CORE",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white, fontFamily: 'monospace', letterSpacing: 2),
        ),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1.0), child: Container(color: bloodRed.withOpacity(0.5), height: 1.0)),
        actions: [
          IconButton(
            icon: Icon(Icons.forum, color: neonRed),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => GlobalChatPage(sessionKey: widget.sessionKey, username: widget.username, role: widget.role)));
            },
          ),
          IconButton(
            icon: const Icon(Icons.notifications_outlined, color: Colors.white54),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("NO NEW TRANSMISSIONS", style: TextStyle(fontFamily: 'monospace')), backgroundColor: Color(0xFF0A0A0A)));
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white),
            onPressed: () async {
              showDialog(
                context: context,
                builder: (_) => BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                  child: AlertDialog(
                    backgroundColor: panelBg,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4), side: BorderSide(color: neonRed, width: 1.5)),
                    title: Row(
                      children: [
                        Icon(Icons.terminal, color: neonRed),
                        const SizedBox(width: 10),
                        const Text("SYSTEM LOGOUT", style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                      ],
                    ),
                    content: const Text("TERMINATE CURRENT SESSION?", style: TextStyle(color: Colors.white70, fontFamily: 'monospace')),
                    actions: [
                      OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.white24), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
                        child: const Text("ABORT", style: TextStyle(color: Colors.white54, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                      ),
                      ElevatedButton(
                        onPressed: () async {
                          Navigator.pop(context);
                          final prefs = await SharedPreferences.getInstance();
                          await prefs.clear();
                          if (!mounted) return;
                          Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: neonRed.withOpacity(0.8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
                        child: const Text("EXECUTE", style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),

      body: Stack(
        children: [
          // Background System
          if (_isVideoInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(width: _videoController.value.size.width, height: _videoController.value.size.height, child: VideoPlayer(_videoController)),
              ),
            ),
          Positioned.fill(child: Container(color: darkBg.withOpacity(0.85))),
          Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: GridPainter()))),

          FadeTransition(
            opacity: _animation,
            child: _selectedPage,
          ),
        ],
      ),

      // BOTTOM NAV SELALU ADA
      bottomNavigationBar: _buildGlassBottomNavBar(),
    );
  }

  Widget _buildDrawer() {
    String safeRole = widget.role.toLowerCase().trim();

    return Drawer(
      backgroundColor: panelBg,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: const Color(0xFF000000),
              border: Border(bottom: BorderSide(color: bloodRed, width: 2)),
              image: const DecorationImage(image: AssetImage('assets/images/logo.jpg'), fit: BoxFit.cover, opacity: 0.2),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  color: bloodRed,
                  child: Text("ACCESS: ${widget.role.toUpperCase()}", style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2)),
                ),
                const SizedBox(height: 8),
                Text('USER // ${widget.username}', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'monospace', letterSpacing: 1)),
                Text('EXPIRES: ${widget.expiredDate}', style: const TextStyle(color: Colors.white54, fontSize: 10, fontFamily: 'monospace')),
              ],
            ),
          ),

          if (safeRole == "owner")
            ListTile(
              leading: Icon(Icons.admin_panel_settings, color: bloodRed),
              title: const Text('ADMIN CONSOLE', style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
              onTap: () {
                Navigator.pop(context);
                _navigateToAdminPage();
              },
            ),

          if (safeRole == "reseller")
            ListTile(
              leading: Icon(Icons.add_shopping_cart, color: neonGreen),
              title: const Text('RESELLER PORTAL', style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
              onTap: () {
                Navigator.pop(context);
                _navigateToSellerPage();
              },
            ),

          if (safeRole == "owner" || safeRole == "vip")
            ListTile(
              leading: Icon(Icons.dns_rounded, color: neonBlue),
              title: const Text('CLOUD PANEL', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
              onTap: () {
                Navigator.pop(context);
                int pIndex = _dynamicNavItems.indexWhere((i) => i["label"] == "C-PANEL");
                if (pIndex != -1) _onBottomNavTapped(pIndex);
              },
            ),

          ListTile(
            leading: const Icon(Icons.lock_clock, color: Colors.white),
            title: const Text('CHANGE PASSPHRASE', style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => ChangePasswordPage(username: widget.username, sessionKey: widget.sessionKey)));
            },
          ),

          ListTile(
            leading: const Icon(Icons.person, color: Colors.white),
            title: const Text('NIK TRACER', style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
            },
          ),

          const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Divider(color: Colors.white12, thickness: 1),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('SYSTEM CREDITS', style: TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'monospace', letterSpacing: 2)),
                const SizedBox(height: 12),
                _creditText("DEVELOPER", "@Kael_Xz"),
                _creditText("MENTOR", "@kyzzexX"),
                _creditText("BACKEND", "@SBErsstore1"),
                _creditText("SUPPORT", "@yuncbb"),
                _creditText("ALLY", "@VinzzXStecVs"),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _creditText(String role, String name) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Text("[$role] ", style: const TextStyle(color: Colors.white38, fontSize: 11, fontFamily: 'monospace')),
          Text(name, style: const TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  // DIBIARKAN UTUH KARENA REQUEST USER
  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: panelBg,
            border: Border.all(color: neonRed.withOpacity(0.5)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text("ACCOUNT INFO", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white, fontFamily: 'monospace')),
                const SizedBox(height: 24),
                _enhancedInfoRow(Icons.person, "USERNAME", widget.username),
                _enhancedInfoRow(Icons.shield, "ACCESS", widget.role),
                _enhancedInfoRow(Icons.calendar_today, "EXPIRES", widget.expiredDate),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    if (_isVideoInitialized) _videoController.dispose();
    if (channel != null) {
      channel.sink.close(status.goingAway);
    }
    _controller.dispose();
    super.dispose();
  }
}

// ==========================================
// MEDIA PLAYER NEWS
// ==========================================
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) {
            setState(() {});
            _controller?.setLooping(true);
            _controller?.setVolume(0.0);
            _controller?.play();
          }
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith(".mp4") ||
          url.endsWith(".webm") ||
          url.endsWith(".mov") ||
          url.endsWith(".mkv");

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return Center(child: CircularProgressIndicator(color: Colors.red));
      }
    } else {
      return Image.network(widget.url, fit: BoxFit.cover);
    }
  }
}

// Custom painter for grid pattern
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.red.withOpacity(0.05)
      ..strokeWidth = 1.0;

    const gridSize = 40.0;

    for (double x = 0; x < size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    for (double y = 0; y < size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class ScanlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black.withOpacity(0.3)..strokeWidth = 2.0;
    for (double i = 0; i < size.height; i += 4.0) canvas.drawLine(Offset(0, i), Offset(size.width, i), paint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}


