import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _animController;
  late AnimationController _pulseController;
  
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  final Color bloodRed = const Color(0xFFB71C1C);
  final Color neonRed = const Color(0xFFFF1744);
  final Color darkBg = const Color(0xFF050505);

  @override
  void initState() {
    super.initState();
    
    // 1. Setup Video Background
    _videoController = VideoPlayerController.asset("assets/videos/landing.mp4")
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(0.0); // Mute video biar elegan
        _videoController.play();
      });

    // 2. Setup Entry Animation
    _animController = AnimationController(
      vsync: this, 
      duration: const Duration(milliseconds: 1500)
    )..forward();

    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeIn);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(
      CurvedAnimation(parent: _animController, curve: Curves.easeOutBack),
    );

    // 3. Setup Pulse Animation (Glow effects)
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _videoController.dispose();
    _animController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  // ==========================================
  // LOGIC AREA (TIDAK DIUBAH SAMA SEKALI)
  // ==========================================
  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  Future<String?> _fetchRegisterCode() async {
    try {
      final res = await http.get(Uri.parse("https://dark.nullxteam.fun/getCode"));
      if (res.statusCode == 200) {
        final jsonData = jsonDecode(res.body);
        return jsonData["code"]?.toString();
      }
    } catch (e) {
      debugPrint("Error fetching code: $e");
    }
    return null;
  }

  Future<void> _signInWith(String type) async {
    final code = await _fetchRegisterCode();
    if (code == null) {
      _showCyberAlert("SYSTEM ERROR", "FAILED TO GET SECURE REGISTRATION CODE.");
      return;
    }

    final message = Uri.encodeComponent("""
{ NaturomDemonto }
Inspired By @Kaell_Xz
Type: Register
Code: $code
Role: Member
""");

    if (type == "whatsapp") {
      final whatsappUrl = "https://wa.me/6283121144219?text=$message";
      await _openUrl(whatsappUrl);
    } else if (type == "telegram") {
      final telegramUrl = "https://t.me/Kaell_Xz"; // Kasih text parameter di URL jika bot support
      await _openUrl(telegramUrl);
    }
  }

  void _showCyberAlert(String title, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.black87,
        content: Container(
          decoration: BoxDecoration(border: Border(left: BorderSide(color: neonRed, width: 4))),
          padding: const EdgeInsets.only(left: 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: TextStyle(color: neonRed, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
              Text(message, style: const TextStyle(color: Colors.white70, fontFamily: 'monospace', fontSize: 12)),
            ],
          ),
        ),
      )
    );
  }

  // ==========================================
  // UI VISUAL CYBERPUNK MEWAH
  // ==========================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Stack(
        children: [
          // 1. VIDEO BACKGROUND
          if (_videoController.value.isInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Positioned.fill(child: Container(color: darkBg)),

          // 2. SMOKED GLASS OVERLAY & SCANLINES
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      darkBg.withOpacity(0.7),
                      bloodRed.withOpacity(0.2),
                      darkBg.withOpacity(0.9),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(painter: ScanlinePainter()),
            ),
          ),

          // 3. MAIN CONTENT
          SafeArea(
            child: Center(
              child: FadeTransition(
                opacity: _fadeAnim,
                child: SlideTransition(
                  position: _slideAnim,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Spacer(),

                        // --- PULSING LOGO ---
                        AnimatedBuilder(
                          animation: _pulseController,
                          builder: (context, child) {
                            return Hero(
                              tag: "logo",
                              child: Container(
                                width: 90,
                                height: 90,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: neonRed.withOpacity(0.5), width: 2),
                                  boxShadow: [
                                    BoxShadow(
                                      color: neonRed.withOpacity(_pulseController.value * 0.5),
                                      blurRadius: 40,
                                      spreadRadius: 5,
                                    ),
                                  ],
                                ),
                                child: ClipOval(
                                  child: Image.asset(
                                    "assets/images/logo.jpg",
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Icon(Icons.security, size: 40, color: neonRed),
                                  ),
                                ),
                              ),
                            );
                          }
                        ),
                        const SizedBox(height: 24),

                        // --- SYSTEM TITLE ---
                        Text(
                          "NATUROM DEMONTO",
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'monospace',
                            letterSpacing: 4,
                            color: Colors.white,
                            shadows: [Shadow(color: neonRed, blurRadius: 15)],
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 6),
                        Text(
                          "SELAMAT DATANG DI APK KAELL-XZ",
                          style: TextStyle(
                            fontSize: 10,
                            fontFamily: 'monospace',
                            letterSpacing: 3,
                            color: Colors.white54,
                          ),
                        ),
                        const SizedBox(height: 40),

                        // --- VIDEO DATA FEED (HUD STYLE) ---
                        Container(
                          width: double.infinity,
                          height: 180,
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.4),
                            border: Border.all(color: Colors.white.withOpacity(0.1)),
                          ),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              if (_videoController.value.isInitialized)
                                Opacity(
                                  opacity: 0.6,
                                  child: VideoPlayer(_videoController),
                                ),
                              // HUD Brackets overlay
                              CustomPaint(painter: HudFramePainter(color: neonRed.withOpacity(0.7))),
                              // Center text
                              Center(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: Colors.black87,
                                    border: Border.all(color: neonRed, width: 0.5),
                                  ),
                                  child: const Text(
                                    "LIVE SECURE FEED",
                                    style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 10, letterSpacing: 2),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 40),

                        // --- CYBER BUTTONS ---
                        _buildCyberButton(
                          label: "LOGIN VIA USERNAME",
                          icon: Icons.terminal,
                          color: bloodRed,
                          onTap: () => Navigator.pushNamed(context, "/login"), // Sesuaikan route lu
                          isPrimary: true,
                        ),
                        const SizedBox(height: 16),
                        _buildCyberButton(
                          label: "KONTAK TELEGRAM",
                          icon: FontAwesomeIcons.telegram,
                          color: Colors.blueAccent.shade700,
                          onTap: () => _signInWith("telegram"),
                          isPrimary: false,
                        ),

                        const Spacer(),

                        // --- FOOTER PANEL ---
                        GlassFooter(
                          onTelegram: () => _openUrl("https://t.me/hamzytzy"),
                          onTiktok: () => _openUrl("https://tiktok.com/@hamzytzy"),
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // WIDGET: Cyber Button (Bentuknya tegas, kotak tumpul, gaya terminal)
  Widget _buildCyberButton({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    required bool isPrimary,
  }) {
    return InkWell(
      onTap: onTap,
      splashColor: color.withOpacity(0.3),
      borderRadius: BorderRadius.circular(4),
      child: Container(
        width: double.infinity,
        height: 55,
        decoration: BoxDecoration(
          color: isPrimary ? color.withOpacity(0.15) : Colors.white.withOpacity(0.03),
          border: Border.all(color: isPrimary ? color : Colors.white.withOpacity(0.2), width: 1.5),
          borderRadius: BorderRadius.circular(4),
          boxShadow: isPrimary
              ? [BoxShadow(color: color.withOpacity(0.2), blurRadius: 15)]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: isPrimary ? neonRed : Colors.white70, size: 20),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: 'monospace',
                letterSpacing: 1.5,
                color: isPrimary ? Colors.white : Colors.white70,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// KUMPULAN CUSTOM PAINTER & WIDGET EFEK
// ==========================================

// 1. Scanline Efek Khas Monitor Hacker
class ScanlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black.withOpacity(0.2)
      ..strokeWidth = 2.0;

    for (double i = 0; i < size.height; i += 4.0) {
      canvas.drawLine(Offset(0, i), Offset(size.width, i), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// 2. HUD Frame buat Video Feed (Sudut Kamera Target)
class HudFramePainter extends CustomPainter {
  final Color color;
  HudFramePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;
    
    const double length = 20.0;

    // Kiri Atas
    canvas.drawLine(const Offset(0, 0), const Offset(length, 0), paint);
    canvas.drawLine(const Offset(0, 0), const Offset(0, length), paint);
    // Kanan Atas
    canvas.drawLine(Offset(size.width, 0), Offset(size.width - length, 0), paint);
    canvas.drawLine(Offset(size.width, 0), Offset(size.width, length), paint);
    // Kiri Bawah
    canvas.drawLine(Offset(0, size.height), Offset(length, size.height), paint);
    canvas.drawLine(Offset(0, size.height), Offset(0, size.height - length), paint);
    // Kanan Bawah
    canvas.drawLine(Offset(size.width, size.height), Offset(size.width - length, size.height), paint);
    canvas.drawLine(Offset(size.width, size.height), Offset(size.width, size.height - length), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// 3. Footer Glassmorphism Cyberpunk
class GlassFooter extends StatelessWidget {
  final VoidCallback onTelegram;
  final VoidCallback onTiktok;

  const GlassFooter({
    super.key,
    required this.onTelegram,
    required this.onTiktok,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        border: Border(
          left: BorderSide(color: Colors.redAccent.withOpacity(0.5), width: 3),
          right: BorderSide(color: Colors.redAccent.withOpacity(0.5), width: 3),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "ENCRYPTED COMM",
                style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 12, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 2),
              Text(
                "SECURE CHANNELS",
                style: TextStyle(color: Colors.white38, fontFamily: 'monospace', fontSize: 10),
              ),
            ],
          ),
          Row(
            children: [
              IconButton(
                icon: const FaIcon(FontAwesomeIcons.telegram, color: Colors.blueAccent, size: 22),
                onPressed: onTelegram,
                splashRadius: 20,
              ),
              IconButton(
                icon: const FaIcon(FontAwesomeIcons.tiktok, color: Colors.white, size: 22),
                onPressed: onTiktok,
                splashRadius: 20,
              ),
            ],
          ),
        ],
      ),
    );
  }
}