module.exports = {
  tokens: "8372313890:AAFosLjfG3d_svFjLOLvEZVkYoXclPhA3fE", 
  owner: "8353486366", 
  port: "4059", // Ini Wajib Jangan Diubah
  ipvps: "https://dikamynotdev.pribadi.walzcfxcloud.web.id" // Jangan Diubah Nanti Eror!!
};