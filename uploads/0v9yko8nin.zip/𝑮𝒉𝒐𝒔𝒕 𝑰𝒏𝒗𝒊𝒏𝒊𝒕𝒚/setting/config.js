const fs = require('fs')

global.owner = "6288980337088" //owner number
global.footer = "𝑿𝒚𝒁𝒆𝒏 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍" //footer section
global.namabot = "𝙶𝚑𝚘𝚜𝚝 𝙸𝚗𝚟𝚒𝚗𝚒𝚝𝚢" //nama bot
global.status = true //"self/public" section of the bot
global.namaowner = "𝑿𝒚𝒁𝒆𝒏 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍"
global.idsaluran = "-"
global.imgmenu = "https://files.catbox.moe/56lsxv.png"

//======[ Setting Event ]======//
global.dana = `088980337088`
global.gopay = `088980337088`
global.ovo = "088980337088"
global.shope = "088980337088"
global.bank = "088980337088"
global.qris = fs.readFileSync("./media/qris.jpg")
global.namastore = "𝑿𝒚𝒁𝒆𝒏 𝑶𝒇𝒇𝒊𝒄𝒊𝒂𝒍"
global.lol = "";
global.msg = {
    owner: "Lu bukan Owner Mbut",
    premium: "Lu ga Ada Di DataBase Premium",
    admin: "Lu bukan Admin tod",
    adminbot: "Jadiin Gw Admin Dulu Dong",
    priv: "khusus Gw",
    bot: "khusus buat bot"
}
global.autoTyping = false // ubah jadi true untuk menyalakan auto typing

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
