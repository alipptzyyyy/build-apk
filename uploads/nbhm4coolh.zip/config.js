module.exports = {
  // Ganti dengan Token Bot Discord Anda
  BOT_TOKEN: "TOKEN_DISCORD_ANDA",
  
  // Ganti dengan ID User Discord Anda (klik kanan pada nama Anda di Discord, lalu "Copy User ID")
  OWNER_ID: ["ID_DISCORD_ANDA"], 
};