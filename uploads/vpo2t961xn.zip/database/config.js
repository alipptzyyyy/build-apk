module.exports = {
  tokens: "8373632360:AAEO1wGpMMje4L5hmHTDiOAWQ5EOJmZAjj0",  // Ubah Jadi Token Bot Mu !!!
  owner: "8222857038", // Ubah Jadi Id Mu !!!
  port: "1202", // Ubah Jadi Port Panel Mu !!!
  ipvps: "159.223.43.210" // Ubah Jadi Ip Vps Mu !!!
};