const { Telegraf, Markup } = require('telegraf');
const fs = require('fs-extra');
const axios = require('axios');
const FormData = require('form-data');
const config = require('./config');

const bot = new Telegraf(config.BOT_TOKEN);
const dbPath = './database.json';

// --- DATABASE LOGIC ---
if (!fs.existsSync(dbPath)) {
    fs.writeJsonSync(dbPath, { users: {}, numbers: [], totalGacha: 0 });
}
const getDB = () => fs.readJsonSync(dbPath);
const saveDB = (data) => fs.writeJsonSync(dbPath, data);

// --- UI CONFIG ---
const dot = "•";

// Fungsi Animasi Loading
async function showLoading(ctx, task, finalCallback) {
    try {
        const frames = ["🟢", "🔴", "🟢", "🔴", "🟢"];
        const msg = await ctx.reply(`<b><blockquote>🔄 ${task}...\n${frames[0]} PROCESSING</blockquote></b>`, { parse_mode: 'HTML' });
        
        for (let i = 1; i < frames.length; i++) {
            await new Promise(r => setTimeout(r, 400));
            await ctx.telegram.editMessageText(ctx.chat.id, msg.message_id, null, `<b><blockquote>🔄 ${task}...\n${frames[i]} PROCESSING</blockquote></b>`, { parse_mode: 'HTML' }).catch(() => {});
        }
        await ctx.telegram.deleteMessage(ctx.chat.id, msg.message_id).catch(() => {});
    } catch (e) {}
    return finalCallback();
}

// Fungsi Cek Keanggotaan di 2 Channel
const isMember = async (ctx) => {
    try {
        // config.CH_JOIN harus berupa array: ['@SekaiPediaa', '@murbug_kyu']
        const channels = Array.isArray(config.CH_JOIN) ? config.CH_JOIN : [config.CH_JOIN];
        for (const ch of channels) {
            const member = await ctx.telegram.getChatMember(ch, ctx.from.id);
            const status = ['member', 'administrator', 'creator'].includes(member.status);
            if (!status) return false;
        }
        return true;
    } catch { return false; }
};

// --- RENDER MAIN MENU ---
const sendMainMenu = (ctx) => {
    const db = getDB();
    const userId = ctx.from.id;
    
    // Inisialisasi User Baru dengan Limit 10
    if (!db.users[userId]) {
        db.users[userId] = { username: ctx.from.username || 'user', limit: 10, invitedBy: null, hasClaimedRef: false };
        saveDB(db);
    }
    
    const user = db.users[userId];
    const caption = `<b><blockquote>🚀 GACHA NOKOS PREMIUM DASHBOARD</blockquote></b>\n\n` +
        `👋 <i>Halo,</i> <b>${ctx.from.first_name}</b>\n\n` +
        `<b>${dot} INFORMASI AKUN</b>\n` +
        `┣ 👤 <b>Nama:</b> <code>${ctx.from.first_name}</code>\n` +
        `┣ 🆔 <b>User ID:</b> <code>${userId}</code>\n` +
        `┗ 🎟 <b>Sisa Limit:</b> <code>${user.limit} Tiket</code>\n\n` +
        `<b>${dot} STATUS SISTEM</b>\n` +
        `┣ 📱 <b>Nokos Ready:</b> <code>${db.numbers.length}</code>\n` +
        `┗ 🎁 <b>Total Gacha:</b> <code>${db.totalGacha}</code>\n\n` +
        `<i>Silahkan pilih menu di bawah untuk mendapatkan nomor WhatsApp.</i>`;

    const keyboard = [
        [Markup.button.callback('🎁 GACHA MENU', 'gacha_menu_tampil'), Markup.button.callback('🛠 TOOLS MENU', 'tools_menu')],
        [Markup.button.callback('🔗 FREE LIMIT', 'refeal_menu'), Markup.button.url('📢 UPDATE', `https://t.me/SekaiPediaa`)],
    ];

    if (userId == config.OWNER_ID) {
        keyboard.push([Markup.button.callback('⚙️ ADMIN DASHBOARD', 'owner_menu')]);
    }

    return ctx.replyWithPhoto(config.IMAGE_URL, {
        caption,
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard(keyboard)
    });
};

// --- HANDLERS ---
bot.start(async (ctx) => {
    const db = getDB();
    const userId = ctx.from.id;
    const refId = ctx.startPayload; // Mengambil ID pengajak dari link start

    if (!db.users[userId]) {
        // Set Limit Awal 10 untuk User Baru
        db.users[userId] = { username: ctx.from.username || 'user', limit: 10, invitedBy: refId || null, hasClaimedRef: false };
        
        // Logika Referral: Berikan +5 limit ke pengajak
        if (refId && db.users[refId] && refId != userId) {
            db.users[refId].limit += 5;
            bot.telegram.sendMessage(refId, `<b>✅ REFERRAL BERHASIL!</b>\nSeseorang bergabung via link Anda. <b>+5 Limit</b> telah ditambahkan!`, { parse_mode: 'HTML' }).catch(()=>{});
        }
        saveDB(db);
    }
    await showLoading(ctx, "BOOTING SYSTEM", () => sendMainMenu(ctx));
});

// --- GACHA CORE (STOK ABADI) ---
const executeGacha = async (ctx) => {
    const db = getDB();
    const user = db.users[ctx.from.id];
    
    // Validasi Wajib Join
    if (!(await isMember(ctx))) {
        return ctx.reply(`<b><blockquote>⚠️ AKSES DIBATASI</blockquote></b>\n\nAnda wajib bergabung di channel berikut:\n1. @SekaiPediaa\n2. @KyzzzO\n\n<i>Silahkan join dan klik tombol gacha lagi.</i>`, { parse_mode: 'HTML' });
    }

    if (user.limit <= 0) return ctx.reply(`<b><blockquote>❌ LIMIT HABIS</blockquote></b>\n\nTiket Anda sudah habis. Gunakan menu <b>FREE LIMIT</b>.`, { parse_mode: 'HTML' });
    if (db.numbers.length === 0) return ctx.reply(`<b><blockquote>📭 STOK KOSONG</blockquote></b>\n\nAdmin belum memasukkan nomor ke database.`, { parse_mode: 'HTML' });

    await showLoading(ctx, "GENERATING NOKOS WA", async () => {
        // Random tanpa menghapus nomor dari array (Stok Abadi)
        const nokos = db.numbers[Math.floor(Math.random() * db.numbers.length)];
        
        user.limit -= 1;
        db.totalGacha++;
        saveDB(db);

        await ctx.reply(`<b><blockquote>🎉 GACHA BERHASIL!</blockquote></b>\n\n` +
            `📱 <b>Nomor WA:</b> <code>${nokos}</code>\n` +
            `🎟 <b>Sisa Tiket:</b> <code>${user.limit}</code>\n\n` +
            `<i>Gunakan tombol di bawah untuk mengambil kode OTP.</i>`, {
            parse_mode: 'HTML',
            ...Markup.inlineKeyboard([[Markup.button.callback('🔑 AMBIL KODE OTP', `get_code_${nokos}`)]])
        });
    });
};

bot.action('run_gacha', (ctx) => executeGacha(ctx));
bot.command('gacha', (ctx) => executeGacha(ctx));

// --- NAVIGATION & MENUS ---
bot.action('gacha_menu_tampil', (ctx) => {
    const db = getDB();
    ctx.editMessageCaption(`<b><blockquote>🎲 MENU GACHA WA</blockquote></b>\n\n` +
        `📦 <b>Stok Tersedia:</b> <code>${db.numbers.length}</code>\n` +
        `🎟 <b>Tiket Kamu:</b> <code>${db.users[ctx.from.id].limit}</code>\n\n` +
        `<i>Satu kali gacha akan memotong 1 tiket limit.</i>`, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('🚀 MULAI GACHA', 'run_gacha')], [Markup.button.callback('⬅️ KEMBALI', 'back_home')]])
    }).catch(() => sendMainMenu(ctx));
});

bot.action('refeal_menu', (ctx) => {
    const link = `https://t.me/${ctx.botInfo.username}?start=${ctx.from.id}`;
    ctx.editMessageCaption(`<b><blockquote>🔗 PROGRAM REFERRAL</blockquote></b>\n\n` +
        `Dapatkan <b>+5 Limit</b> gratis setiap kali teman bergabung melalui link Anda.\n\n` +
        `<b>Link Referral Anda:</b>\n<code>${link}</code>`, { 
        parse_mode: 'HTML', 
        ...Markup.inlineKeyboard([[Markup.button.callback('⬅️ KEMBALI', 'back_home')]]) 
    });
});

bot.action('tools_menu', (ctx) => {
    ctx.editMessageCaption(`<b><blockquote>🛠 PREMIUM TOOLS</blockquote></b>\n\n` +
        `<b>${dot} /tourl</b> - Media ke Link\n` +
        `<b>${dot} /pinterest</b> - Cari Gambar\n` +
        `<b>${dot} /cekid</b> - Cek ID Telegram`, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('⬅️ KEMBALI', 'back_home')]])
    });
});

bot.action('back_home', (ctx) => { ctx.deleteMessage().catch(()=>{}); sendMainMenu(ctx); });

// --- ADMIN LOGIC ---
bot.action('owner_menu', (ctx) => {
    if (ctx.from.id != config.OWNER_ID) return;
    ctx.editMessageCaption(`<b><blockquote>👑 OWNER DASHBOARD</blockquote></b>\n\nKelola stok nomor WhatsApp:`, { 
        parse_mode: 'HTML', 
        ...Markup.inlineKeyboard([[Markup.button.callback('➕ TAMBAH NOMOR', 'add_num'), Markup.button.callback('📢 BROADCAST', 'bc_start')], [Markup.button.callback('⬅️ KELUAR', 'back_home')]]) 
    });
});

bot.action('add_num', (ctx) => ctx.reply("<b>📥 INPUT:</b> Kirim list nomor (format +62/62) di bawah ini:", { parse_mode: 'HTML' }));
bot.action('bc_start', (ctx) => ctx.reply("<b>📢 BROADCAST:</b> Balas pesan ini dengan isi pengumuman:", { parse_mode: 'HTML' }));

bot.on('text', async (ctx) => {
    const db = getDB();
    if (ctx.from.id == config.OWNER_ID) {
        // Menambah nomor ke database
        if (ctx.message.text.startsWith('+') || ctx.message.text.startsWith('62')) {
            const list = ctx.message.text.split('\n');
            db.numbers.push(...list); saveDB(db);
            return ctx.reply(`<b>✅ BERHASIL:</b> ${list.length} Nomor ditambahkan.`, { parse_mode: 'HTML' });
        }
        // Kirim Broadcast
        if (ctx.message.reply_to_message && ctx.message.reply_to_message.text.includes("BROADCAST")) {
            const users = Object.keys(db.users);
            for (const id of users) {
                try { await bot.telegram.sendMessage(id, `<b>📢 PENGUMUMAN:</b>\n\n${ctx.message.text}`, { parse_mode: 'HTML' }); } catch (e) {}
            }
            return ctx.reply("<b>✅ SELESAI.</b>", { parse_mode: 'HTML' });
        }
    }
});

// --- OTP SIMULATION ---
bot.action(/get_code_(.+)/, async (ctx) => {
    const otp = Math.floor(100000 + Math.random() * 899999);
    await showLoading(ctx, "BYPASSING OTP", () => {
        ctx.reply(`<b><blockquote>🔑 KODE OTP WA: <code>${otp}</code></blockquote></b>\n\n<i>Masukkan kode ini di aplikasi WhatsApp Anda.</i>`, { parse_mode: 'HTML' });
    });
});

// --- TOOLS COMMANDS ---
bot.command('pinterest', async (ctx) => {
    const q = ctx.message.text.split(' ').slice(1).join(' ');
    if (!q) return ctx.reply("💡 Contoh: /pinterest cyber-punk");
    try {
        const res = await axios.get(`${config.API_PINTEREST}${encodeURIComponent(q)}`);
        const randomImg = res.data.result[Math.floor(Math.random() * res.data.result.length)];
        ctx.replyWithPhoto(randomImg, { caption: `Hasil cari: ${q}`, parse_mode: 'HTML' });
    } catch (e) { ctx.reply("❌ API Error."); }
});

bot.command('tourl', async (ctx) => {
    const msg = ctx.message.reply_to_message;
    if (!msg || (!msg.photo && !msg.video && !msg.document)) return ctx.reply("❌ Balas foto/video!");
    try {
        const fileId = msg.photo ? msg.photo[msg.photo.length - 1].file_id : (msg.video ? msg.video.file_id : msg.document.file_id);
        const fileLink = await ctx.telegram.getFileLink(fileId);
        const response = await axios.get(fileLink.href, { responseType: 'arraybuffer' });
        const form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('fileToUpload', Buffer.from(response.data), 'file.png');
        const upload = await axios.post('https://catbox.moe/user/api.php', form, { headers: form.getHeaders() });
        ctx.reply(`<b>🔗 URL:</b> <code>${upload.data}</code>`, { parse_mode: 'HTML' });
    } catch (e) { ctx.reply("❌ Gagal upload."); }
});

bot.command('cekid', (ctx) => ctx.reply(`<b>🆔 ID:</b> <code>${ctx.from.id}</code>`, { parse_mode: 'HTML' }));

bot.launch().then(() => console.log(">>> BOT WA NOKOS AKTIF (LIMIT AWAL 10) <<<"));