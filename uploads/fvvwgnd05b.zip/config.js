module.exports = {
    BOT_TOKEN: '8539766755:AAGbd96Ivsw8XH96URHnkHweT2op3I8r_D0', 
    OWNER_ID: 7532729653,        
    // List channel wajib join
    CH_JOIN: ['@SekaiPediaa', '@KyzzzO'], 
    IMAGE_URL: 'https://files.catbox.moe/kkci2x.jpg', 
    API_PINTEREST: 'https://api.vreden.web.id/api/pinterest?q='     
};