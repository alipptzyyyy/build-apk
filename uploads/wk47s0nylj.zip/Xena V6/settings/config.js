module.exports = {
  tokenBot: "TOKENS",
  ownerID: "ID",
};
