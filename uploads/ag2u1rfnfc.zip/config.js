module.exports = {
  BOT_TOKEN: "8394773503:AAGVafv7wdxfoaULjTVOwsrIU2H3qbyMx8Y",
  OWNER_ID: ["1495626702"],
};