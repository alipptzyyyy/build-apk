/*
Create By Ikky 
            Script - Ikoyy Death
            Version - 1.0.0
JANGAN LUPA GANTI TOKEN ID OWNER DI (データベース/owneruser.json)
*/
module.exports = {
  TOKEN_USER: "8524273014:AAEHQoo5o4y6U2UllHeRkU18nEjq-DH1OxI", //Ganti Token Bot
  ModuleApiBot: "ZyZo10688ApiBot", // Api Bot Jangan Ganti 
};