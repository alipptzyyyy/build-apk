module.exports = {
  tokens: "8468078801:AAHao3kiaQuihLu-DzR9JNDmy9XEv1_c190",  // Ubah Jadi Token Bot Mu !!!
  owner: "7767341460", // Ubah Jadi Id Mu !!!
  port: "1204", // Ubah Jadi Port Panel Mu !!!
  ipvps: "http://alzzcpanel.manszyofficial.my.id/" // Ubah Jadi Ip Vps Mu !!!
};