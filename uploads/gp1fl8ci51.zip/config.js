module.exports = {
  TOKEN: "TOKEN BOT LUU",
  OWNER: 1886007660
};