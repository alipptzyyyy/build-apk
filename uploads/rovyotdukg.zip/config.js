module.exports = {
  BOT_TOKEN: "8606538626:AAFEubVJtVyoW95PM5OoWvRij6_ySYN3Ax0",
  OWNER_ID: ["8501697611"],
  
};
