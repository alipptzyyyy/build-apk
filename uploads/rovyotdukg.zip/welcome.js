const premiumUsers = [

  { id: '7982602157', expiry: 1684022400000 }, 
  
];

module.exports = premiumUsers;
