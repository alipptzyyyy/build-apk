const supervipUsers = [

  { id: '1234', expiry: 1684022400000 }, 
  
];

module.exports = supervipUsers;
