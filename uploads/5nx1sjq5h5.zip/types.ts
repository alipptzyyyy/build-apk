
export interface Student {
  id: string;
  name: string;
  studentId: string;
  className: string;
  createdAt: number;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  timestamp: number;
  status: 'present';
}

export type ViewState = 'login' | 'admin_dashboard' | 'scanner' | 'landing';

export interface User {
  email: string;
  role: 'admin';
}
