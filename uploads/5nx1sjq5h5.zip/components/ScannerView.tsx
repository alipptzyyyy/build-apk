
import React, { useState, useEffect, useRef } from 'react';
import { Student, AttendanceRecord } from '../types';

interface ScannerViewProps {
  students: Student[];
  onScanSuccess: (student: Student) => void;
  recentAttendance: AttendanceRecord[];
}

const ScannerView: React.FC<ScannerViewProps> = ({ students, onScanSuccess, recentAttendance }) => {
  const [status, setStatus] = useState<'idle' | 'scanning' | 'success' | 'error'>('idle');
  const [scannedName, setScannedName] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;

    async function startCamera() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setStatus('scanning');
      } catch (err) {
        console.error("Camera access error:", err);
        setErrorMessage("Tidak dapat mengakses kamera. Pastikan izin kamera diberikan.");
        setStatus('error');
      }
    }

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Simulating the scan process since we don't have a full heavy QR library in this snippet
  // In a real app, you would use jsQR or html5-qrcode here inside a loop.
  const simulateScan = () => {
    // For demonstration: Ask the user to input the ID or pick a random student
    const id = prompt("Masukkan ID Siswa atau Scan Berhasil (Simulasi)");
    if (!id) return;

    const student = students.find(s => s.id === id || s.studentId === id);
    if (student) {
      handleValidScan(student);
    } else {
      handleInvalidScan();
    }
  };

  const handleValidScan = (student: Student) => {
    setStatus('success');
    setScannedName(student.name);
    onScanSuccess(student);
    
    setTimeout(() => {
      setStatus('scanning');
      setScannedName('');
    }, 3000);
  };

  const handleInvalidScan = () => {
    setStatus('error');
    setErrorMessage('QR Code tidak valid atau siswa tidak terdaftar.');
    
    setTimeout(() => {
      setStatus('scanning');
      setErrorMessage('');
    }, 3000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
        <div className="lg:grid lg:grid-cols-2">
          
          {/* Scanner Area */}
          <div className="p-8 bg-gray-900 flex flex-col items-center justify-center min-h-[400px] relative">
            <div className="absolute top-6 left-6 flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full animate-pulse ${status === 'scanning' ? 'bg-indigo-500' : 'bg-gray-500'}`} />
              <span className="text-white/70 text-sm font-medium uppercase tracking-wider">
                {status === 'scanning' ? 'Live Camera' : 'Camera Ready'}
              </span>
            </div>

            {/* Camera Viewport */}
            <div className="relative w-full max-w-[280px] aspect-square rounded-3xl border-2 border-white/20 overflow-hidden bg-black">
              <video 
                ref={videoRef} 
                autoPlay 
                muted 
                playsInline 
                className="absolute inset-0 w-full h-full object-cover opacity-60"
              />
              
              {/* Scan Overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                 <div className="w-48 h-48 border-2 border-indigo-500 rounded-2xl relative">
                    <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-indigo-400 -translate-x-1 -translate-y-1 rounded-tl-lg"></div>
                    <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-indigo-400 translate-x-1 -translate-y-1 rounded-tr-lg"></div>
                    <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-indigo-400 -translate-x-1 translate-y-1 rounded-bl-lg"></div>
                    <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-indigo-400 translate-x-1 translate-y-1 rounded-br-lg"></div>
                    <div className="absolute top-0 left-0 w-full h-0.5 bg-indigo-400/50 shadow-[0_0_15px_rgba(129,140,248,0.8)] animate-scan-line"></div>
                 </div>
              </div>

              {/* Feedback Overlay */}
              {status === 'success' && (
                <div className="absolute inset-0 bg-emerald-600/90 flex flex-col items-center justify-center text-white p-4 text-center animate-in fade-in duration-300">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mb-3">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="font-bold text-lg">Berhasil Hadir!</p>
                  <p className="text-sm opacity-90">{scannedName}</p>
                </div>
              )}

              {status === 'error' && errorMessage && (
                <div className="absolute inset-0 bg-red-600/90 flex flex-col items-center justify-center text-white p-4 text-center animate-in fade-in duration-300">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mb-3">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </div>
                  <p className="font-bold text-lg">Gagal!</p>
                  <p className="text-xs opacity-90 leading-tight">{errorMessage}</p>
                </div>
              )}
            </div>

            <button 
              onClick={simulateScan}
              className="mt-8 bg-white/10 hover:bg-white/20 text-white px-6 py-2 rounded-full text-sm font-semibold transition-all backdrop-blur-sm"
            >
              Simulasi Pindai
            </button>
          </div>

          {/* Info Side */}
          <div className="p-8 flex flex-col">
             <h3 className="text-xl font-bold text-gray-900 mb-6">Aktivitas Terbaru</h3>
             
             <div className="flex-grow space-y-4">
               {recentAttendance.length > 0 ? (
                 recentAttendance.map((a, i) => (
                   <div key={a.id} className={`flex items-center gap-4 p-4 rounded-2xl border ${i === 0 ? 'bg-indigo-50 border-indigo-100' : 'bg-gray-50 border-gray-100'}`}>
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${i === 0 ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                        {a.studentName.charAt(0)}
                      </div>
                      <div>
                        <p className={`font-bold text-sm ${i === 0 ? 'text-indigo-900' : 'text-gray-900'}`}>{a.studentName}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(a.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • Hadir
                        </p>
                      </div>
                   </div>
                 ))
               ) : (
                 <div className="h-full flex flex-col items-center justify-center text-gray-400 py-10">
                    <p className="text-sm">Belum ada aktivitas.</p>
                 </div>
               )}
             </div>

             <div className="mt-8 pt-8 border-t">
               <div className="flex items-start gap-3">
                 <div className="w-8 h-8 bg-amber-50 rounded-lg flex items-center justify-center text-amber-600">
                   <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                   </svg>
                 </div>
                 <p className="text-xs text-gray-500 leading-relaxed">
                   Arahkan QR Code siswa ke tengah bingkai kamera. Pastikan pencahayaan cukup untuk proses pemindaian yang optimal.
                 </p>
               </div>
             </div>
          </div>

        </div>
      </div>
      <style>{`
        @keyframes scan-line {
          0% { top: 0; }
          50% { top: 100%; }
          100% { top: 0; }
        }
        .animate-scan-line {
          animation: scan-line 3s infinite ease-in-out;
        }
      `}</style>
    </div>
  );
};

export default ScannerView;
