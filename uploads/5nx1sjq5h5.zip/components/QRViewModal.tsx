
import React from 'react';
import { Student } from '../types';

interface QRViewModalProps {
  student: Student | null;
  onClose: () => void;
}

const QRViewModal: React.FC<QRViewModalProps> = ({ student, onClose }) => {
  if (!student) return null;

  // We'll use a public QR API for simplicity in this demo environment
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${student.id}`;

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head>
          <title>Kartu Absen - ${student.name}</title>
          <style>
            body { font-family: sans-serif; text-align: center; padding-top: 50px; }
            .card { border: 2px solid #ccc; padding: 20px; display: inline-block; border-radius: 10px; }
            img { width: 200px; }
            h2 { margin-bottom: 5px; }
            p { color: #666; margin: 0; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>${student.name}</h2>
            <p>${student.className} | NIS: ${student.studentId}</p>
            <br/>
            <img src="${qrUrl}" />
          </div>
          <script>window.onload = () => { window.print(); window.close(); }</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-8 text-center">
          <div className="mb-6 flex justify-center">
            <div className="p-4 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
              <img src={qrUrl} alt="Student QR Code" className="w-48 h-48" />
            </div>
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-1">{student.name}</h3>
          <p className="text-gray-500 mb-6">{student.className} • {student.studentId}</p>
          
          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={handlePrint}
              className="bg-indigo-600 text-white py-3 rounded-xl font-semibold hover:bg-indigo-700 transition-colors"
            >
              Cetak QR
            </button>
            <button 
              onClick={onClose}
              className="bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QRViewModal;
