
import React, { useState } from 'react';
import { Student, AttendanceRecord } from '../types';
import StudentModal from './StudentModal';
import QRViewModal from './QRViewModal';

interface AdminDashboardProps {
  students: Student[];
  attendance: AttendanceRecord[];
  onAddStudent: (student: Student) => void;
  onDeleteStudent: (id: string) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  students, 
  attendance, 
  onAddStudent,
  onDeleteStudent 
}) => {
  const [tab, setTab] = useState<'students' | 'history'>('students');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedStudentForQR, setSelectedStudentForQR] = useState<Student | null>(null);

  const stats = {
    totalStudents: students.length,
    presentToday: attendance.filter(a => {
      const today = new Date().toDateString();
      return new Date(a.timestamp).toDateString() === today;
    }).length
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Dashboard Admin</h2>
        <p className="text-gray-600">Kelola data siswa dan pantau kehadiran harian.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <p className="text-sm font-medium text-gray-500 mb-1">Total Siswa Terdaftar</p>
          <p className="text-3xl font-bold text-indigo-600">{stats.totalStudents}</p>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <p className="text-sm font-medium text-gray-500 mb-1">Hadir Hari Ini</p>
          <p className="text-3xl font-bold text-emerald-600">{stats.presentToday}</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="flex border-b">
          <button 
            onClick={() => setTab('students')}
            className={`px-6 py-4 text-sm font-semibold transition-colors ${
              tab === 'students' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Daftar Siswa
          </button>
          <button 
            onClick={() => setTab('history')}
            className={`px-6 py-4 text-sm font-semibold transition-colors ${
              tab === 'history' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Riwayat Kehadiran
          </button>
        </div>

        <div className="p-6">
          {tab === 'students' ? (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-gray-800">Manajemen Siswa</h3>
                <button 
                  onClick={() => setIsAddModalOpen(true)}
                  className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-700"
                >
                  + Tambah Siswa
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">NIS</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kelas</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-100">
                    {students.map((student) => (
                      <tr key={student.id} className="hover:bg-gray-50">
                        <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{student.name}</td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">{student.studentId}</td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">{student.className}</td>
                        <td className="px-4 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button 
                            onClick={() => setSelectedStudentForQR(student)}
                            className="text-indigo-600 hover:text-indigo-900 mr-4"
                          >
                            Tampilkan QR
                          </button>
                          <button 
                            onClick={() => onDeleteStudent(student.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            Hapus
                          </button>
                        </td>
                      </tr>
                    ))}
                    {students.length === 0 && (
                      <tr>
                        <td colSpan={4} className="px-4 py-8 text-center text-gray-400">Belum ada data siswa.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div>
              <h3 className="font-bold text-gray-800 mb-6">Riwayat Kehadiran Terkini</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama Siswa</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Waktu</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-100">
                    {attendance.map((record) => (
                      <tr key={record.id}>
                        <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{record.studentName}</td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(record.timestamp).toLocaleString('id-ID')}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className="px-2 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-700">
                            Hadir
                          </span>
                        </td>
                      </tr>
                    ))}
                    {attendance.length === 0 && (
                      <tr>
                        <td colSpan={3} className="px-4 py-8 text-center text-gray-400">Belum ada riwayat absensi.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>

      <StudentModal 
        isOpen={isAddModalOpen} 
        onClose={() => setIsAddModalOpen(false)} 
        onAdd={onAddStudent}
      />

      <QRViewModal 
        student={selectedStudentForQR} 
        onClose={() => setSelectedStudentForQR(null)} 
      />
    </div>
  );
};

export default AdminDashboard;
