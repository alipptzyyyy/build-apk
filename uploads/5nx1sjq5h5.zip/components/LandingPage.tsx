
import React from 'react';
import { ViewState } from '../types';

interface LandingPageProps {
  setView: (view: ViewState) => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ setView }) => {
  return (
    <div className="bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="lg:grid lg:grid-cols-12 lg:gap-8 items-center">
          <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
            <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
              <span className="block">Absensi Siswa Lebih</span>
              <span className="block text-indigo-600">Cepat & Akurat</span>
            </h1>
            <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-xl lg:text-lg xl:text-xl">
              Gantikan sistem absensi kertas tradisional dengan SmartAbsen. Gunakan QR Code unik untuk setiap siswa, pantau kehadiran secara real-time, dan hasilkan laporan dalam hitungan detik.
            </p>
            <div className="mt-8 sm:max-w-lg sm:mx-auto sm:text-center lg:text-left lg:mx-0">
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => setView('scanner')}
                  className="w-full sm:w-auto px-8 py-3 border border-transparent text-base font-medium rounded-xl text-white bg-indigo-600 hover:bg-indigo-700 md:py-4 md:text-lg md:px-10 shadow-lg shadow-indigo-200"
                >
                  Mulai Scan
                </button>
                <button
                  onClick={() => setView('login')}
                  className="w-full sm:w-auto px-8 py-3 border border-gray-200 text-base font-medium rounded-xl text-gray-700 bg-gray-50 hover:bg-gray-100 md:py-4 md:text-lg md:px-10"
                >
                  Login Admin
                </button>
              </div>
            </div>
          </div>
          <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
            <div className="relative mx-auto w-full rounded-3xl shadow-2xl overflow-hidden">
               <img 
                 src="https://picsum.photos/seed/school/800/600" 
                 alt="School Administration" 
                 className="w-full h-full object-cover"
               />
               <div className="absolute inset-0 bg-indigo-600 mix-blend-multiply opacity-20"></div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'QR Code Unik',
                desc: 'Generate QR code otomatis untuk setiap siswa yang terdaftar.',
                icon: 'qr_code_2'
              },
              {
                title: 'Real-time Scan',
                desc: 'Validasi kehadiran instan menggunakan kamera perangkat apa pun.',
                icon: 'camera_alt'
              },
              {
                title: 'Laporan Otomatis',
                desc: 'Simpan riwayat kehadiran dan ekspor data dengan mudah.',
                icon: 'analytics'
              }
            ].map((feature, i) => (
              <div key={i} className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center text-indigo-600 mb-6">
                  <span className="material-icons-outlined text-2xl font-bold">✓</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
