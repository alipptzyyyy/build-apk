
import React from 'react';
import { ViewState, User } from '../types';

interface NavbarProps {
  view: ViewState;
  setView: (view: ViewState) => void;
  currentUser: User | null;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ view, setView, currentUser, onLogout }) => {
  return (
    <nav className="bg-white border-b sticky top-0 z-50 px-4 md:px-8 py-4 flex items-center justify-between">
      <div 
        className="flex items-center gap-2 cursor-pointer" 
        onClick={() => setView('landing')}
      >
        <div className="bg-indigo-600 p-2 rounded-lg">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
        </div>
        <span className="font-bold text-xl tracking-tight text-gray-900">SmartAbsen</span>
      </div>

      <div className="flex items-center gap-4">
        <button 
          onClick={() => setView('scanner')}
          className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors ${
            view === 'scanner' ? 'bg-indigo-600 text-white' : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
          }`}
        >
          Scan QR
        </button>
        
        {currentUser ? (
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setView('admin_dashboard')}
              className={`text-sm font-medium ${view === 'admin_dashboard' ? 'text-indigo-600' : 'text-gray-600 hover:text-gray-900'}`}
            >
              Dashboard
            </button>
            <button 
              onClick={onLogout}
              className="text-sm font-medium text-red-600 hover:text-red-700 border border-red-100 px-4 py-2 rounded-full hover:bg-red-50"
            >
              Keluar
            </button>
          </div>
        ) : (
          <button 
            onClick={() => setView('login')}
            className={`text-sm font-medium ${view === 'login' ? 'text-indigo-600' : 'text-gray-600 hover:text-gray-900'}`}
          >
            Admin Login
          </button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
