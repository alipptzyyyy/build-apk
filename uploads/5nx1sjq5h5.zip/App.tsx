
import React, { useState, useEffect } from 'react';
import { ViewState, Student, AttendanceRecord, User } from './types';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import ScannerView from './components/ScannerView';
import Navbar from './components/Navbar';
import LandingPage from './components/LandingPage';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('landing');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('absen_students');
    return saved ? JSON.parse(saved) : [];
  });
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem('absen_records');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('absen_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('absen_records', JSON.stringify(attendance));
  }, [attendance]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setView('admin_dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setView('landing');
  };

  const addStudent = (student: Student) => {
    setStudents(prev => [...prev, student]);
  };

  const deleteStudent = (id: string) => {
    setStudents(prev => prev.filter(s => s.id !== id));
  };

  const recordAttendance = (student: Student) => {
    const newRecord: AttendanceRecord = {
      id: Math.random().toString(36).substr(2, 9),
      studentId: student.id,
      studentName: student.name,
      timestamp: Date.now(),
      status: 'present',
    };
    setAttendance(prev => [newRecord, ...prev]);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar 
        view={view} 
        setView={setView} 
        currentUser={currentUser} 
        onLogout={handleLogout} 
      />
      
      <main className="flex-grow">
        {view === 'landing' && <LandingPage setView={setView} />}
        
        {view === 'login' && (
          <Login onLogin={handleLogin} />
        )}
        
        {view === 'admin_dashboard' && currentUser && (
          <AdminDashboard 
            students={students} 
            attendance={attendance}
            onAddStudent={addStudent}
            onDeleteStudent={deleteStudent}
          />
        )}
        
        {view === 'scanner' && (
          <ScannerView 
            students={students} 
            onScanSuccess={recordAttendance} 
            recentAttendance={attendance.slice(0, 5)}
          />
        )}
      </main>
      
      <footer className="bg-white border-t py-6 text-center text-gray-500 text-sm">
        &copy; {new Date().getFullYear()} SmartAbsen. Dibuat untuk Efisiensi Sekolah.
      </footer>
    </div>
  );
};

export default App;
