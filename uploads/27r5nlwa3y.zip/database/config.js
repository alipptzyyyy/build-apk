module.exports = {
  tokens: "8465270511:AAGkdEFG3XeOEA6aPcXjAX7abSj-oo_2yyw",  // Masukin Bot token kamu
  owners: "8422521805", // Masukin ID Telegram kamu
  port: "3242", // Masukin Port panel kamu 
  ipvps: "https://privatezarxhost.panel-host.biz.id/" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};