module.exports = {
  tokens: "8459481961:AAH_HON5zqAumV8rU7UyUQbBqBYhXznd2zA",
  owner: "all_AGL",
  port: "all_AGL1",
  ipvps: "1"
};