const axios = require('axios')

async function reactToPost(postUrl, emojis) {
  const API_KEYS = [
    "APIKEY_KAMU",
    "APIKEY_KAMU",
    "APIKEY_KAMU"
  ]

  let currentTokenIndex = 0
  let attempts = 0

  while (attempts < API_KEYS.length) {
    const apiKey = API_KEYS[currentTokenIndex]

    try {
      await axios({
        method: 'POST',
        url: `https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/react-to-post?apiKey=${apiKey}`,
        headers: { 'content-type': 'application/json' },
        data: {
          post_link: postUrl,
          reacts: emojis
        }
      })

      return { success: true }

    } catch (e) {
      const msg = e.response?.data?.message || ""

      if (
        e.response?.status === 402 ||
        msg.toLowerCase().includes("limit")
      ) {
        currentTokenIndex = (currentTokenIndex + 1) % API_KEYS.length
        attempts++
        continue
      }

      return { success: false, error: msg }
    }
  }

  return { success: false, error: "All API keys limit" }
}

module.exports = reactToPost