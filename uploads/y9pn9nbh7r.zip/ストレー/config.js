module.exports = {
  TOKEN: "", //isi token lu
  OWNER_ID: [""] // id lu pler
};