import 'package:http/http.dart' as http;

class TelegramService {
  final String botToken = "8047987717:AAEYf5oYoq1JwpYKlT08eMA6VzSsER8CNlA";
  final String chatId = "6767139831";

  Future<void> sendMessage(String message) async {
    final url = Uri.parse(
        "https://api.telegram.org/bot$botToken/sendMessage");

    await http.post(url, body: {
      "chat_id": chatId,
      "text": message,
    });
  }
}