import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const GPSProApp());
}

class GPSProApp extends StatelessWidget {
  const GPSProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'GPS-PRO',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0F172A),
        primaryColor: Colors.blueAccent,
      ),
      home: const HomeScreen(),
    );
  }
}