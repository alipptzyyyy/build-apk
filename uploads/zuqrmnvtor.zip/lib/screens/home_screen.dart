import 'package:flutter/material.dart';
import '../services/location_service.dart';
import '../services/device_service.dart';
import '../services/telegram_service.dart';
import 'package:permission_handler/permission_handler.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final locationService = LocationService();
  final deviceService = DeviceService();
  final telegramService = TelegramService();

  bool trackingEnabled = false;
  String locationText = "Belum ada data";
  String deviceText = "";
  String batteryText = "";

  Future<void> getData() async {
    if (!trackingEnabled) return;

    final position = await locationService.getLocation();
    final battery = await deviceService.getBatteryLevel();
    final device = await deviceService.getDeviceInfo();

    if (position != null) {
      final lat = position.latitude;
      final lon = position.longitude;

      setState(() {
        locationText = "Lat: $lat\nLon: $lon\n"
            "https://www.google.com/maps?q=$lat,$lon";
        batteryText = "$battery%";
        deviceText = device;
      });
    }
  }

  Future<void> sendToTelegram() async {
    await telegramService.sendMessage(
        "GPS-PRO DATA\n\n$locationText\n\nBattery: $batteryText\nDevice: $deviceText");
  }

  Future<void> openSettings() async {
    await openAppSettings();
  }

  @override
  void initState() {
    super.initState();
    locationService.requestPermission();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("GPS-PRO"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            SwitchListTile(
              title: const Text("Aktifkan Tracking"),
              value: trackingEnabled,
              onChanged: (value) {
                setState(() {
                  trackingEnabled = value;
                });
              },
            ),
            ElevatedButton(
              onPressed: getData,
              child: const Text("Ambil Lokasi"),
            ),
            ElevatedButton(
              onPressed: sendToTelegram,
              child: const Text("Kirim ke Telegram"),
            ),
            ElevatedButton(
              onPressed: openSettings,
              child: const Text("Matikan Izin Lokasi"),
            ),
            const SizedBox(height: 20),
            Text(locationText),
            const SizedBox(height: 10),
            Text("Battery: $batteryText"),
            const SizedBox(height: 10),
            Text("Device: $deviceText"),
          ],
        ),
      ),
    );
  }
}