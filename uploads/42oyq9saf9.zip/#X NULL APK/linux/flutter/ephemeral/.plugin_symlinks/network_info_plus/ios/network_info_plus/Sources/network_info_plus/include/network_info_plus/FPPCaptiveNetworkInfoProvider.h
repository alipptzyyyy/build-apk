#import "FPPNetworkInfoProvider.h"
#import <Foundation/Foundation.h>

@interface FPPCaptiveNetworkInfoProvider : NSObject <FPPNetworkInfoProvider>
@end
