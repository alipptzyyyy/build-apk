/* 
   BASE CREATE BY NTED CRASHER
  - EROR? FIX SENDIRI GAUSA BNYK TANYA
  - FREE RENAME/RECODE
  - FREE SHARE/DLL
  - JANGAN JUAL ANJG
  
  Support By : Allah Swt
               Ortu Gw
               Teddy ( Gw )
               Yuukey ( Friend )
               Faxz ( Friend )
               Rexz ( Friend )
               DaffaDev ( Sensei )
               Dapz ( Sensei )
               Ikky ( Pt Terpenting Gw )
               All Seller Gw ( Best Support )               
NOTE BREE : Kalo Eror Fix Sendiri, Katanya Mau Jadi Dev, Malu Nanya Ke Gw Tpi Sc Nya Di Jual, Mininal Tu Fixx Sendiri Baru Jual Jangan Nanya Ke Gw.

Nted Crasher Real : https://t.me/NtedCrasher
*/
const fs = require("fs")
const path = require("path")
const fetch = require("node-fetch")
const axios = require("axios")
const FormData = require("form-data")
const { Sticker } = require("wa-sticker-formatter")
const JsConfuser = require("js-confuser")
const { default: 
baileys, 
proto, 
generateWAMessage, 
generateWAMessageFromContent, 
getContentType,
prepareWAMessageMedia } = require("@whiskeysockets/baileys");
const { pinterest, pinterest2, mediafire, tiktokDl } = require('../lib/scraper');

async function nted(nted, m, chatUpdate, store) {
const body = (
    // Pesan teks biasa
    m.mtype === "conversation" ? m.message.conversation :
    m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :

    // Pesan media dengan caption
    m.mtype === "imageMessage" ? m.message.imageMessage.caption :
    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
    m.mtype === "documentMessage" ? m.message.documentMessage.caption || "" :
    m.mtype === "audioMessage" ? m.message.audioMessage.caption || "" :
    m.mtype === "stickerMessage" ? m.message.stickerMessage.caption || "" :

    // Pesan interaktif (tombol, list, dll.)
    m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :

    // Pesan khusus
    m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || 
    m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text :
    m.mtype === "reactionMessage" ? m.message.reactionMessage.text :
    m.mtype === "contactMessage" ? m.message.contactMessage.displayName :
    m.mtype === "contactsArrayMessage" ? m.message.contactsArrayMessage.contacts.map(c => c.displayName).join(", ") :
    m.mtype === "locationMessage" ? `${m.message.locationMessage.degreesLatitude}, ${m.message.locationMessage.degreesLongitude}` :
    m.mtype === "liveLocationMessage" ? `${m.message.liveLocationMessage.degreesLatitude}, ${m.message.liveLocationMessage.degreesLongitude}` :
    m.mtype === "pollCreationMessage" ? m.message.pollCreationMessage.name :
    m.mtype === "pollUpdateMessage" ? m.message.pollUpdateMessage.name :
    m.mtype === "groupInviteMessage" ? m.message.groupInviteMessage.groupJid :
    
    // Pesan satu kali lihat (View Once)
    m.mtype === "viewOnceMessage" ? (m.message.viewOnceMessage.message.imageMessage?.caption || 
                                     m.message.viewOnceMessage.message.videoMessage?.caption || 
                                     "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2" ? (m.message.viewOnceMessageV2.message.imageMessage?.caption || 
                                       m.message.viewOnceMessageV2.message.videoMessage?.caption || 
                                       "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2Extension" ? (m.message.viewOnceMessageV2Extension.message.imageMessage?.caption || 
                                                m.message.viewOnceMessageV2Extension.message.videoMessage?.caption || 
                                                "[Pesan sekali lihat]") :

    // Pesan sementara (ephemeralMessage)
    m.mtype === "ephemeralMessage" ? (m.message.ephemeralMessage.message.conversation ||
                                      m.message.ephemeralMessage.message.extendedTextMessage?.text || 
                                      "[Pesan sementara]") :

    // Pesan interaktif lain
    m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :

    // Pesan yang dihapus
    m.mtype === "protocolMessage" ? "[Pesan telah dihapus]" :

    ""
);


const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid

const senderNumber = sender.split("@")[0]; // Nomor polos
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefixMatch = body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\]/);
const prefix = prefixMatch ? prefixMatch[0] : ''; 
const command = body.slice(prefix.length).split(" ")[0].toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

//Const Group
const groupMetadata = m.isGroup ? await nted.groupMetadata(from).catch(e => {}) : ""
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = m.isGroup ? await groupMetadata.participants : ""
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ""
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
}

// My Func
const { 
smsg, 
sendGmail, 
formatSize, 
isUrl, 
generateMessageTag, 
getBuffer, 
getSizeMedia, 
runtime, 
fetchJson, 
sleep  } = require('../lib/myfunc');

const imageList2 = [
"https://files.catbox.moe/dbnlkt.jpg",
"https://files.catbox.moe/lcuzu0.jpg",
"https://files.catbox.moe/r9x45g.jpg"

];

const RandomShort = imageList2[Math.floor(Math.random() * imageList2.length)];


const lol = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnailUrl: RandomShort,
      itemCount: "9999",
      status: "INQUIRY",
      surface: "",
      message: `Nted Made Fake`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}
const ReplyGwe = (teks) => {
nted.sendMessage(from, { text: teks, contextInfo:{"externalAdreply": {"title": `𝐒𝐢𝐦𝐩𝐥𝐞 𝑺𝒄𝒓𝒊𝒑𝒕 𝑩𝒚 𝑵𝒕𝒆𝒅`,"body": `© 𝐍𝐭𝐞𝐝 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐁𝐨𝐭𝐳`, "previewType": "PHOTO","thumbnailUrl": `https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=${command}`}}}, { quoted: lol })} 

module.exports = {
  // === TikTok Downloader ===
  tiktok: async (nted, m, text, ReplyGwe, lol) => {
    try {
      if (!text) return ReplyGwe("❌ Masukkan URL TikTok!")
      if (!text.startsWith("https://")) return ReplyGwe("❌ Link tidak valid!")

      const result = await tiktokDl(text)
      if (!result.status) return ReplyGwe("❌ Error ambil data!")

      // Jika slide foto
      if (result.durations == 0 && result.duration == "0 Seconds") {
        let araara = []
        let urutan = 0

        for (let a of result.data) {
          let image = await prepareWAMessageMedia(
            { image: { url: `${a.url}` } },
            { upload: nted.waUploadToServer }
          )
          araara.push({
            header: proto.Message.InteractiveMessage.Header.fromObject({
              title: `Foto Slide Ke *${urutan += 1}*`,
              hasMediaAttachment: true,
              ...image
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
              buttons: [{
                "name": "cta_url",
                "buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
              }]
            })
          })
        }

        const msgii = await generateWAMessageFromContent(m.chat, {
          viewOnceMessageV2Extension: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2
              },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: "*Slide Foto TikTok*"
                }),
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                  cards: araara
                })
              })
            }
          }
        }, { userJid: m.sender, quoted: m })

        await nted.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
      } else {
        // Jika video
        let urlVid = result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
        await nted.sendMessage(
          m.chat,
          { video: { url: urlVid.url }, mimetype: "video/mp4", caption: `*✅ Done*\nNih` },
          { quoted: lol }
        )
      }
    } catch (e) {
      console.error(e)
      ReplyGwe("❌ Terjadi kesalahan!")
    }
  },

  // === Spam Tag ===
  spamtag: async (nted, m, text, ReplyGwe) => {
    if (!m.mentionedJid[0]) {
      return ReplyGwe('❌ Tag orangnya!\nContoh: .spamtag @Teted|10')
    }

    const [orang, amountStr] = text.split("|").map(item => item.trim())
    const amount = parseInt(amountStr, 10)

    if (isNaN(amount) || amount <= 0) {
      return ReplyGwe('❌ Jumlah harus berupa angka!')
    }

    for (let i = 0; i < amount; i++) {
      nted.sendMessage(m.chat, {
        text: orang,
        mentions: [m.mentionedJid[0]]
      })
      await sleep(500)
    }
  },

  // === To URL ===
  tourl: async (nted, m, text, ReplyGwe, prefix, command) => {
    let q = m.quoted ? m.quoted : m
    if (!q || !q.download) return ReplyGwe(`❌ Reply gambar/video dengan perintah *${prefix + command}*`)

    let mime = q.mimetype || ''
    if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
      return ReplyGwe('❌ Hanya mendukung gambar atau video MP4!')
    }

    let media
    try {
      media = await q.download()
    } catch (error) {
      return ReplyGwe('❌ Gagal mendownload media!')
    }

    let isTele = /image\/(png|jpe?g|gif)/.test(mime)
    let link

    try {
      link = await (isTele ? uploadImage : uploadFile)(media)
    } catch (error) {
      return ReplyGwe('❌ Gagal upload media!')
    }

    ReplyGwe(`*✅ Sukses Upload!*\n${link}`)
  }
}
module.exports.play = async (nted, m, text, ReplyGwe, ftoko) => {
  if (!text) return ReplyGwe("*Nama Lagu Nya?*\n*Nina Feast*");
  await nted.sendMessage(m.chat, { react: { text: "🔎", key: m.key } });

  try {
    const res = await fetch(`https://api.nekorinn.my.id/downloader/ytplay-savetube?q=${encodeURIComponent(text)}`);
    if (!res.ok) return ReplyGwe("*Terjadi Kesalahan Saat Mengambil Data Dari Api Server*");

    const data = await res.json();
    if (!data.status) return ReplyGwe("*Hasil Tidak Ditemukan*");

    const { title, channel, duration, imageUrl, link } = data.result.metadata;
    const downloadUrl = data.result.downloadUrl;

    await nted.sendMessage(m.chat, {
      audio: { url: downloadUrl },
      mimetype: "audio/mpeg",
      fileName: `${title}.mp3`,
      contextInfo: {
        externalAdReply: {
          title,
          body: `${channel} • ${duration}`,
          mediaType: 2,
          thumbnailUrl: imageUrl,
          renderLargerThumbnail: true,
          sourceUrl: link,
          showAdAttribution: false,
        },
      },
    }, { quoted: ftoko });

  } catch (e) {
    console.error(e);
    ReplyGwe("*Terjadi Kesalahan*");
  }
};
module.exports.instagram = async (nted, m, text, ReplyGwe) => {
  if (!text) return ReplyGwe("linknya");
  if (!text.startsWith("https://")) return ReplyGwe("Link tautan tidak valid");

  await nted.sendMessage(m.chat, { react: { text: "🕖", key: m.key } });
  try {
    const res = await fetchJson(`https://api.siputzx.my.id/download/igdl?url=${text}`);
    if (!res.status) return ReplyGwe("Error! Result Not Found");

    await nted.sendMessage(
      m.chat,
      { video: { url: res.result.url }, mimetype: "video/mp4", caption: "*Instagram Downloader ✅*" },
      { quoted: m }
    );
    await nted.sendMessage(m.chat, { react: { text: "", key: m.key } });
  } catch {
    ReplyGwe("Error");
  }
};
// === Cek Ganteng / Cantik ===
module.exports.cekganteng = async (nted, m, text, ReplyGwe, lol, ftoko, command) => {
  const teks = text ? text.trim() : ''
  let targetJid, targetName

  if (m.mentionedJid && m.mentionedJid.length > 0) {
    targetJid = m.mentionedJid[0]
    targetName = await nted.getName(targetJid)
  } else if (/^\d{5,}$/.test(teks)) {
    targetJid = teks.includes('@s.whatsapp.net') ? teks : teks + '@s.whatsapp.net'
    targetName = await nted.getName(targetJid).catch(() => teks)
  } else if (teks) {
    targetJid = m.sender
    targetName = teks
  } else {
    targetJid = m.sender
    targetName = await nted.getName(m.sender)
  }

  const score = Math.floor(Math.random() * 100) + 1
  let komentar, emoji

  if (command === 'cekganteng') {
    if (score >= 90) { komentar = 'Gantengnya overload!'; emoji = '🔥👑💯' }
    else if (score >= 75) { komentar = 'Fix calon idol K-Pop!'; emoji = '✨🧸💘' }
    else if (score >= 60) { komentar = 'Lumayanlah.'; emoji = '😎👍' }
    else if (score >= 40) { komentar = 'Masih bisa ganteng kalau pake filter.'; emoji = '🤔📸' }
    else { komentar = 'Waduh... Gantengnya disembunyiin?'; emoji = '🥲💀' }

    const result = `*Cek Ganteng Untuk:* ${targetName}\n\n*Nilai Ganteng:* *${score}/100* ${emoji}\n\n*Komentar:* ${komentar}`
    nted.sendMessage(m.chat, { text: result, mentions: [targetJid] }, { quoted: lol })
  } else {
    if (score >= 90) { komentar = 'Kecantikannya bikin bunga iri.'; emoji = '🌷✨🌙' }
    else if (score >= 75) { komentar = 'Manis kayak senja.'; emoji = '🌅🍬🌸' }
    else if (score >= 60) { komentar = 'Pesona sederhana tapi ngena.'; emoji = '☕🌼😊' }
    else { komentar = 'Cantiknya masih misteri.'; emoji = '🕵️‍♀️❓🌑' }

    const result = `*Cek Cantik Untuk:* ${targetName}\n\n*Skor Kecantikan:* *${score}/100* ${emoji}\n\n*Komentar:* ${komentar}`
    nted.sendMessage(m.chat, { text: result, mentions: [targetJid] }, { quoted: ftoko })
  }
}

// === Cek Kontol ===
module.exports.cekkontol = async (nted, m, text, lol) => {
  const nama = text ? text : m.pushName
  const score = Math.floor(Math.random() * 101)
  let komentar, emoji

  if (score >= 90) { komentar = 'Panjang Banget Woi'; emoji = '🙀😹' }
  else if (score >= 75) { komentar = 'Segini lumayan yah.'; emoji = '😹' }
  else if (score >= 60) { komentar = 'Lumayanlah.'; emoji = '👍' }
  else { komentar = 'Pendek bet anjg.'; emoji = '😹😹' }

  const result = `*Cek Panjang Kntol:* ${nama}\n\n*Panjang:* *${score}/100 CM* ${emoji}\n\n*Komentar:* ${komentar}`
  nted.sendMessage(m.chat, { text: result }, { quoted: lol })
}

// === HD (Image Upscale) ===
module.exports.hd = async (nted, m, ReplyGwe) => {
  const q = m.quoted ? m.quoted : m
  if (!q || !/image/.test(q.mimetype || '')) return ReplyGwe("❌ Reply foto yang mau di-HD kan!")

  try {
    const media = await q.download()
    const form = new FormData()
    form.append("image", media, { filename: "image.jpg" })

    const res = await axios.post("https://api.itsrose.life/image/upscale?to=2x", form, {
      headers: {
        "Authorization": "itsrose-api-key",
        ...form.getHeaders()
      },
      responseType: "arraybuffer"
    })

    await nted.sendMessage(m.chat, { image: res.data, caption: "✅ Done di-HD kan!" }, { quoted: m })
  } catch (e) {
    console.error(e)
    ReplyGwe("❌ Gagal meng-HD kan gambar")
  }
}