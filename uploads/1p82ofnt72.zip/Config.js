const fs = require('fs')

global.token = "8480585903:AAHJzhZ4xHO_LC3DQRCeGPAlspMrRBhxU5M"
global.botname = "𝑵𝑻𝑬𝑫 𝑪𝑹𝑨𝑺𝑯𝑬𝑹"
global.version = "14 Pro"
global.packname = 'Nted Offical'
global.owner = "6289510019072"
global.footer = "NtedSempak"
global.idch = "120363393940866504@newsletter"
global.packname = "Nted Inflow"
global.welcome = false
global.autoread = false
global.anticall = false
global.autoviewsw = true
global.swreact = ['👍', '❤️', '🔥', '😂', '😮', '😹', '👏', '🗿','😎','🤪']; // Tambahkan ini di atas sebelum event

//=========[ Settings Thumb V1 ]===============//
global.thumb = "https://files.catbox.moe/h6cnl8.mp4"
//==========================================//
global.mess = {
    done: '*Done Gak Bang?\nDone Dong*', 
    owner: '*Lu Siapa? Owner Gw Aja Bukan Sok Ngatur 😹*',
    private: '*Kelaz Anjg, Ini Cuma Private*',
    group: '*Lahk?\nFitur Ini Khusus Group Cuy*',
    botAdmin: '*Aku Blom Admin Cinta 😡*',
    admin: '*Lu Siapa? Minimal Mandi, eh Admin 🗿*',
    wait: '*`[ ◇ ] : 𝚛𝚎𝚚𝚞𝚞𝚎𝚜𝚝 𝚙𝚛𝚘𝚌𝚎𝚜𝚎𝚍𝚍..`*',
    success: '*Success By? Yah Bot Nted Dong*',
    prem: '*Kelaz, Lu Bukan Premium Bre*',
}
//==================================//


let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
