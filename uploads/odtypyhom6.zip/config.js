module.exports = {
  BOT_TOKEN: "TOKEN_BOT_LU",
};
/*/━━━━━━━━━━━━━━━━━━━━━━━━  
   🔥 STELLAR NECROSIS 🔥  
━━━━━━━━━━━━━━━━━━━━━━━━━  
Developer: SerenXyrine || Sonn
Telegram: @SerenXyrine || @SonOffc
Version: 1.8

⚠️ **PERINGATAN!** ⚠️  
Script ini menggunakan database.  
Jika token Anda 
**tidak terdaftar di database**,  
Script **tidak akan berjalan**!  
Pastikan token Anda sudah terdaftar sebelum menggunakan Script ini
*/