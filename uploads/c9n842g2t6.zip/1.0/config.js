module.exports = {
  BOT_TOKEN: "8581413137:AAGSfg_9pFU67dtBGQS0KfCScfXZ_Hps98w",
  OWNER_ID: ["7698051616"],
};

//Thanks For Buy The Last