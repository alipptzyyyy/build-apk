module.exports = {
  tokens: "8341699936:",  // Ubah Jadi Token Bot Mu !!!
  owner: "1309102882", // Ubah Jadi Id Mu !!!
  port: "", // Ubah Jadi Port Panel Mu !!!
  ipvps: "" // Ubah Jadi Ip Vps Mu !!!
};