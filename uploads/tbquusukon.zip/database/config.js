module.exports = {
  tokens: "8646136688:AAGiIOI_HzfO02f4wSxJWbMU0hlAHKwRpzQ",  // Ubah Jadi Token Bot Mu !!!
  owner: "8264058663", // Ubah Jadi Id Mu !!!
  port: "2267", // Ubah Jadi Port Panel Mu !!!
  ipvps: "naelpler.publicserver.my.id" // Ubah Jadi Ip Vps Mu !!!
};