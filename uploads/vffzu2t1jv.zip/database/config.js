module.exports = {
  tokens: "8214347692:AAEjcbbJFg6ABPvV_s2E6T-y7BGmTDwk47k",  // Ubah Jadi Token Bot Mu !!!
  owner: "8061941312", // Ubah Jadi Id Mu !!!
  port: "2267", // Ubah Jadi Port Panel Mu !!!
  ipvps: "naelpler.publicserver.my.id" // Ubah Jadi Ip Vps Mu !!!
};