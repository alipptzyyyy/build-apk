module.exports = {
  BOT_TOKEN: "8608000003:AAFO2umIilLcFZwYYCHpQVBws-lovnAIoPU",
  OWNER_ID: ["8319375463"],
};